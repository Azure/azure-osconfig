// Copyright (c) Microsoft. All rights reserved.
#ifndef COMMANDRUNNER_H
#define COMMANDRUNNER_H

#include "AgentCommon.h"

#define COMMANDRUNNER_MAX_PAYLOAD OSCONFIG_MAX_PAYLOAD

#define COMMANDRUNNER_COMPONENT_NAME "CommandRunner"
#define COMMANDRUNNER_COMMAND_STATUS "CommandStatus"
#define COMMANDRUNNER_RESULT_CODE "ResultCode"
#define COMMANDRUNNER_EXTENDED_RESULT_CODE "ExtendedResultCode"
#define COMMANDRUNNER_TEXT_RESULT "TextResult"
#define COMMANDRUNNER_CURRENT_STATE "CurrentState"
#define COMMANDRUNNER_COMMAND_ARGUMENTS "CommandArguments"
#define COMMANDRUNNER_COMMAND_ID "CommandId"
#define COMMANDRUNNER_ARGUMENTS "Arguments"
#define COMMANDRUNNER_ACTION "Action"

enum CommandArgumentsAction
{
    ActionNone = 0,
    ActionReboot,
    ActionShutdown,
    ActionRunCommand,
    ActionRefreshCommandStatus
};
typedef enum CommandArgumentsAction CommandArgumentsAction;

enum CommandStatusCurrentState
{
    CommandStatusUnknown = 0,
    CommandStatusRunning,
    CommandStatusSucceeded,
    CommandStatusFailed
};
typedef enum CommandStatusCurrentState CommandStatusCurrentState;

#ifdef __cplusplus
extern "C"
{
#endif

void CommandRunnerInitialize(void);
void CommandRunnerDoWork(void);
IOTHUB_CLIENT_RESULT CommandRunnerProcessPropertyUpdateFromIotHub(const char* propertyName, const JSON_Value* propertyValue, int version);
void CommandRunnerReportedStateCallback(int statusCode, void* userContextCallback);
void CommandRunnerDestroy(void);

#ifdef __cplusplus
}
#endif

#endif // COMMANDRUNNER_H