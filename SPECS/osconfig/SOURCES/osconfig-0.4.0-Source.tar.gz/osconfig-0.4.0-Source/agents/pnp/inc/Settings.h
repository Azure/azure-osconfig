// Copyright (c) Microsoft. All rights reserved.
#ifndef SETTINGS_H
#define SETTINGS_H

#include "AgentCommon.h"

#define SETTINGS_COMPONENT_NAME "Settings"
#define SETTINGS_DEVICE_HEALTH_TELEMETRY_CONFIGURATION "DeviceHealthTelemetryConfiguration"
#define SETTINGS_DELIVERY_OPTIMIZATION_POLICIES "DeliveryOptimizationPolicies"

#define DO_PERCENTAGE_DOWNLOAD_THROTTLE "PercentageDownloadThrottle"
#define DO_CACHE_HOST_SOURCE "CacheHostSource"
#define DO_CACHE_HOST "CacheHost"
#define DO_CACHE_HOST_FALLBACK "CacheHostFallback"

enum HealthTelemetry
{
    HealthTelemetryNone = 0,
    HealthTelemetryRequired,
    HealthTelemetryOptional
};
typedef enum HealthTelemetry HealthTelemetry;

enum DoCacheHostSource
{
    CacheHostSourceNone = 0,
    CacheHostSourceAzureDeviceUpdate,
    CacheHostSourceDeviceDiscoveryService,
    CacheHostSourceDhcpServerCustomOptionId235
};
typedef enum DoCacheHostSource DoCacheHostSource;

#ifdef __cplusplus
extern "C"
{
#endif

void SettingsInitialize(void);
IOTHUB_CLIENT_RESULT SettingsProcessPropertyUpdateFromIotHub(const char* propertyName, const JSON_Value* propertyValue, int version);
void SettingsReportedStateCallback(int statusCode, void* userContextCallback);
void SettingsDestroy(void);

#ifdef __cplusplus
}
#endif

#endif // SETTINGS_H