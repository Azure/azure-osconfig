// Copyright (c) Microsoft. All rights reserved.
#ifndef AISUTILS_H
#define AISUTILS_H

#include "AgentCommon.h"

#ifdef __cplusplus
extern "C"
{
#endif

char* RequestConnectionStringFromAis(char** x509Certificate, char** x509PrivateKeyHandle);

#ifdef __cplusplus
}
#endif

#endif // AISUTILS_H