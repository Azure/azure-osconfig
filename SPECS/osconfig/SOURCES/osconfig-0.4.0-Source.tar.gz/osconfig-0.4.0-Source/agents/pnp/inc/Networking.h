// Copyright (c) Microsoft. All rights reserved.
#ifndef NETWORKING_H
#define NETWORKING_H

#include "AgentCommon.h"

#define NETWORKING_MAX_PAYLOAD OSCONFIG_MAX_PAYLOAD

#define NETWORKING_COMPONENT_NAME "Networking"
#define NETWORKING_NETWORK_CONFIGURATION "NetworkConfiguration"
#define NETWORKING_INTERFACETYPES "InterfaceTypes"
#define NETWORKING_MAXADDRESSES "MacAddresses"
#define NETWORKING_IPADDRESSES "IpAddresses"
#define NETWORKING_SUBNETMASKS "SubnetMasks"
#define NETWORKING_DEFAULTGATEWAYS "DefaultGateways"
#define NETWORKING_DNSSERVERS "DnsServers"
#define NETWORKING_DHCPENABLED "DhcpEnabled"
#define NETWORKING_ENABLED "Enabled"
#define NETWORKING_CONNECTED "Connected"

#ifdef __cplusplus
extern "C"
{
#endif

void NetworkingInitialize(void);
void NetworkingDoWork(void);
void NetworkingReportedStateCallback(int statusCode, void* userContextCallback);
void NetworkingDestroy(void);

#ifdef __cplusplus
}
#endif

#endif // NETWORKING_H