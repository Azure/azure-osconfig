// Copyright (c) Microsoft. All rights reserved.
#ifndef PNPAGENT_H
#define PNPAGENT_H

#ifdef __cplusplus
extern "C"
{
#endif

int InitializePnpModule(const char* connectionString);
bool IsComponentSupported(const char* componentName);
bool IsComplexProperty(const char* componentName, const char* propertyName);
IOTHUB_CLIENT_REPORTED_STATE_CALLBACK GetComponentReportedStateCallback(const char* componentName);
void PnpModuleDoWork(void);
void ClosePnpModule(void);
void ScheduleRefreshConnection(void);

#ifdef __cplusplus
}
#endif

#endif // PNPAGENT_H
