// Copyright (c) Microsoft. All rights reserved.
#ifndef MPIPROXY_H
#define MPIPROXY_H

#define MPI_CALL_MESSAGE_LENGTH 256

#ifdef __cplusplus
extern "C"
{
#endif

MPI_HANDLE CallMpiOpen(const char* clientName, const unsigned int maxPayloadSizeBytes);
void CallMpiClose(MPI_HANDLE clientSession);
int CallMpiSet(const char* componentName, const char* propertyName, const char* payload, const int payloadSizeBytes);
int CallMpiGet(const char* componentName, const char* propertyName, char** payload, int* payloadSizeBytes, bool logInfo);
void CallMpiFree(char* payload);
void CallMpiDoWork(void);

// For when logging needs to not happen for all MPI calls call CallMpiGet with logInfo as false and then call this if appropriate
void LogMpiGet(const char* componentName, const char* propertyName, char* payload, int payloadSizeBytes, int result);

#ifdef __cplusplus
}
#endif

#endif // MPIPROXY_H
