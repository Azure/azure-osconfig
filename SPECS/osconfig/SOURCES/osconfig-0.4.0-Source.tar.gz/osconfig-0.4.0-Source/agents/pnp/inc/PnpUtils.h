// Copyright (c) Microsoft. All rights reserved.
#ifndef PNPUTILS_H
#define PNPUTILS_H

#include "AgentCommon.h"

#define DEVICE_PRODUCT_INFO "Azure Device OS Configuration (OSConfig)"
#define DEVICE_MODEL_ID "dtmi:osconfig:deviceosconfiguration;3"

#define PNP_STATUS_SUCCESS 200
#define PNP_STATUS_BAD_DATA 400

#ifdef __cplusplus
extern "C"
{
#endif

typedef void(*IOTHUB_CLIENT_REPORTED_STATE_CALLBACK)(int status_code, void* userContextCallback);
typedef bool(*SHOULD_REPORT_PROPERTY_TO_IOTHUB_CALLBACK)(const char* propertyName, char* payload, int payloadSizeBytes);

IOTHUB_DEVICE_CLIENT_LL_HANDLE IotHubInitialize(const char* connectionString, bool traceOn, const char* x509Certificate, const char* x509PrivateKeyHandle);
void IotHubDeInitialize(void);
void IotHubDoWork(void);

// IOTHUB_CLIENT_RESULT includes values such as:
// - IOTHUB_CLIENT_OK
// - IOTHUB_CLIENT_INVALID_ARG
// - IOTHUB_CLIENT_ERROR
// - IOTHUB_CLIENT_INVALID_SIZE
// - IOTHUB_CLIENT_INDEFINITE_TIME
IOTHUB_CLIENT_RESULT UpdatePropertyFromIotHub(const char* componentName, const char* propertyName, const JSON_Value* propertyValue, int version);
IOTHUB_CLIENT_RESULT ReportPropertyToIotHub(const char* componentName, const char* propertyName, SHOULD_REPORT_PROPERTY_TO_IOTHUB_CALLBACK shouldReportPropertyToTwinCallback, bool mustReport);
IOTHUB_CLIENT_RESULT AckPropertyUpdateToIotHub(const char* componentName, const char* propertyName, char* propertyValue, int valueLength, int version, int propertyUpdateResult);

#ifdef __cplusplus
}
#endif

#endif // PNPUTILS_H
