// Copyright (c) Microsoft. All rights reserved.
#ifndef FIREWALL_H
#define FIREWALL_H

#include "AgentCommon.h"

#define FIREWALL_MAX_PAYLOAD OSCONFIG_MAX_PAYLOAD

#define FIREWALL_COMPONENT_NAME "Firewall"
#define FIREWALL_RULES "FirewallRules"
#define FIREWALL_DIRECTIONS "Directions"
#define FIREWALL_TARGETS "Targets"
#define FIREWALL_PROTOCOLS "Protocols"
#define FIREWALL_IPADDRESSES "IpAddresses"
#define FIREWALL_PORTS "Ports"

#ifdef __cplusplus
extern "C"
{
#endif

void FirewallInitialize(void);
void FirewallDoWork(void);
void FirewallReportedStateCallback(int statusCode, void* userContextCallback);
void FirewallDestroy(void);

#ifdef __cplusplus
}
#endif

#endif // FIREWALL_H