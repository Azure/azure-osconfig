// Copyright (c) Microsoft. All rights reserved.
#include "inc/PnpUtils.h"
#include "inc/MpiProxy.h"
#include "inc/Networking.h"

// In the future when the payload will increase, this payload copy could be replaced by a hash of the same
static char* g_prevNetworkingRules = NULL;
static int g_prevNetworkingRulesSize = 0;

static bool CheckNetworkingReportedPayload(const char* propertyName, char* payload)
{
    bool result = true;
    JSON_Value* propertyValue = NULL;
    JSON_Object* jsonObject = NULL;

    if (0 != strcmp(propertyName, NETWORKING_NETWORK_CONFIGURATION))
    {
        return false;
    }

    if (NULL == (propertyValue = json_parse_string(payload)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: json_parse_string for %s failed", propertyName);
        result = false;
    }

    if (result && (JSONObject != json_value_get_type(propertyValue)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: invalid type for %s, not object", propertyName);
        result = false;
    }

    if (result && (NULL == (jsonObject = json_value_get_object(propertyValue))))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: json_value_get_object for %s failed", propertyName);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, NETWORKING_INTERFACETYPES, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: %s missing required %s as a string", propertyName, NETWORKING_INTERFACETYPES);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, NETWORKING_MAXADDRESSES, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: %s missing required %s as a string", propertyName, NETWORKING_MAXADDRESSES);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, NETWORKING_IPADDRESSES, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: %s missing required %s as a string", propertyName, NETWORKING_IPADDRESSES);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, NETWORKING_SUBNETMASKS, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: %s missing required %s as a string", propertyName, NETWORKING_SUBNETMASKS);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, NETWORKING_DEFAULTGATEWAYS, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: %s missing required %s as a string", propertyName, NETWORKING_DEFAULTGATEWAYS);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, NETWORKING_DNSSERVERS, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: %s missing required %s as a string", propertyName, NETWORKING_DNSSERVERS);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, NETWORKING_DHCPENABLED, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: %s missing required %s as a string", propertyName, NETWORKING_DHCPENABLED);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, NETWORKING_ENABLED, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: %s missing required %s as a string", propertyName, NETWORKING_ENABLED);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, NETWORKING_CONNECTED, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Networking: %s missing required %s as a string", propertyName, NETWORKING_CONNECTED);
        result = false;
    }


    if (propertyValue)
    {
        json_value_free(propertyValue);
    }

    return result;
}

static bool NetworkingShouldReportPropertyToIotHubCallback(const char* propertyName, char* payload, int payloadSizeBytes)
{
    bool reportProperty = true;

    LogAssert(GetLog(), NULL != propertyName);
    LogAssert(GetLog(), NULL != payload);
    
    if (0 != strcmp(propertyName, NETWORKING_NETWORK_CONFIGURATION))
    {
        return false;
    }

    if ((g_prevNetworkingRulesSize == payloadSizeBytes) && (0 == memcmp(payload, g_prevNetworkingRules, payloadSizeBytes)))
    {
        reportProperty = false;
    }
    else
    {
        FREE_MEMORY(g_prevNetworkingRules);
        g_prevNetworkingRulesSize = 0;

        if ((!payload) || (!CheckNetworkingReportedPayload(propertyName, payload)))
        {
            LogErrorWithTelemetry(GetLog(), "Networking: invalid payload for %s, cannot report", propertyName);
            reportProperty = false;
        }
        else
        {
            g_prevNetworkingRules = (char*)malloc(payloadSizeBytes);
            if (NULL != g_prevNetworkingRules)
            {
                memcpy(g_prevNetworkingRules, payload, payloadSizeBytes);
                g_prevNetworkingRulesSize = payloadSizeBytes;

                OsConfigLogInfo(GetLog(), "Networking: %s property value appears new", propertyName);
            }
            else
            {
                LogErrorWithTelemetry(GetLog(), "NetworkingShouldReportPropertyToIotHubCallback: out of memory allocating %u bytes", payloadSizeBytes);
                reportProperty = false;
            }
        }

        if (payloadSizeBytes > NETWORKING_MAX_PAYLOAD)
        {
            LogErrorWithTelemetry(GetLog(), "Networking: payload size for %s is %d bytes, larger than maximum %u bytes, cannot report",
                propertyName, payloadSizeBytes, NETWORKING_MAX_PAYLOAD);
            reportProperty = false;
        }
    }

    return reportProperty;
}

void NetworkingReportedStateCallback(int statusCode, void* userContextCallback)
{
    OsConfigLogInfo(GetLog(), "Networking: ReportedStateCallback called with status code %u", statusCode);
    UNUSED(userContextCallback);
}

static IOTHUB_CLIENT_RESULT NetworkingReportPropertyToIotHub(const char* propertyName)
{
    return ReportPropertyToIotHub(NETWORKING_COMPONENT_NAME, propertyName, NetworkingShouldReportPropertyToIotHubCallback, false);
}

void NetworkingInitialize(void)
{
    OsConfigLogInfo(GetLog(), "Networking PnP component initialized");
}

void NetworkingDoWork(void)
{
    // Invoked every DOWORK_INTERVAL with DOWORK_SLEEP delay (fine tune via these macros):
    NetworkingReportPropertyToIotHub(NETWORKING_NETWORK_CONFIGURATION);
}

void NetworkingDestroy(void)
{
    FREE_MEMORY(g_prevNetworkingRules);
    OsConfigLogInfo(GetLog(), "Networking PnP component terminated");
}