// Copyright (c) Microsoft. All rights reserved.
#include "inc/AgentCommon.h"
#include "inc/PnpUtils.h"
#include "inc/MpiProxy.h"
#include "inc/PnpAgent.h"
#include "inc/AisUtils.h"
#include "inc/CommandRunner.h"
#include "inc/Settings.h"
#include "inc/Firewall.h"
#include "inc/Networking.h"

// TraceLogging Provider UUID: CF452C24-662B-4CC5-9726-5EFE827DB281
TRACELOGGING_DEFINE_PROVIDER(g_providerHandle, "Microsoft.Azure.OsConfigAgent",
    (0xcf452c24, 0x662b, 0x4cc5, 0x97, 0x26, 0x5e, 0xfe, 0x82, 0x7d, 0xb2, 0x81));

// 30 seconds
#define DOWORK_INTERVAL 30000

// 100 milliseconds
#define DOWORK_SLEEP 100

// The log file for the agent
#define LOG_FILE "/var/log/osconfig_pnp_agent.log"
#define ROLLED_LOG_FILE "/var/log/osconfig_pnp_agent.bak"

// The syslog logger name for the agent
#define SYSLOG_NAME "osconfig_pnp_agent"

// The optional second command line argument that when present instructs the agent to run as a traditional daemon
#define FORK_ARG "fork"

// Called at the beginning and end of an agent session to signal components to allocate and free resources
typedef void(*ComponentInitialize)(void);
typedef void(*ComponentDestroy)(void);

// Periodically called to execute actions such as updating mutable read-only properties, telemetry, etc.
typedef void(*ComponentDoWork)(void);

typedef struct COMPONENT_ENTRY_TAG
{
    const char* componentName;
    const ComponentInitialize Initialize;
    const ComponentDoWork DoWork;
    const ComponentDestroy Destroy;
    const IOTHUB_CLIENT_REPORTED_STATE_CALLBACK ReportedStateCallback;
} COMPONENT_ENTRY;

static COMPONENT_ENTRY g_components[] =
{
    {
        COMMANDRUNNER_COMPONENT_NAME,
        CommandRunnerInitialize,
        CommandRunnerDoWork,
        CommandRunnerDestroy,
        CommandRunnerReportedStateCallback
    },
    {
        SETTINGS_COMPONENT_NAME,
        SettingsInitialize,
        NULL,
        SettingsDestroy,
        SettingsReportedStateCallback
    },
    {
        FIREWALL_COMPONENT_NAME,
        FirewallInitialize,
        FirewallDoWork,
        FirewallDestroy,
        FirewallReportedStateCallback
    },
    {
        NETWORKING_COMPONENT_NAME,
        NetworkingInitialize,
        NetworkingDoWork,
        NetworkingDestroy,
        NetworkingReportedStateCallback
    }
};

static unsigned g_componentsListCount = ARRAY_SIZE(g_components);

static TICK_COUNTER_HANDLE g_tickCounter = NULL;
static tickcounter_ms_t g_lastTick = 0;

extern IOTHUB_DEVICE_CLIENT_LL_HANDLE g_deviceHandle;

// All signals on which we want the agent to cleanup before terminating process.
// SIGKILL is omitted to allow a clean and immediate process kill if needed.
static int g_stopSignals[] = {
    0,
    SIGINT,  // 2
    SIGQUIT, // 3
    SIGILL,  // 4
    SIGABRT, // 6
    SIGBUS,  // 7
    SIGFPE,  // 8
    SIGSEGV, //11
    SIGTERM, //15
    SIGSTOP, //19
    SIGTSTP  //20
};

enum AgentExitState
{
    NoError = 0,
    NoConnectionString = 1,
    IotHubInitializationFailure = 2,
    MpiInitializationFailure = 3
};
typedef enum AgentExitState AgentExitState;
static AgentExitState g_exitState = NoError;

static int g_stopSignal = 0;
static int g_refreshSignal = 0;

static char* g_iotHubConnectionString = NULL;
const char* g_iotHubConnectionStringPrefix = "HostName=";
static bool g_iotHubConnectionStringFromAis = false;

// Obtained from AIS alongside the connection string in case of X.509 authentication
static char* g_x509Certificate = NULL;
static char* g_x509PrivateKeyHandle = NULL;

MPI_HANDLE g_mpiHandle = NULL;
static const char g_mpiClientName[] = "osconfig";
static unsigned int g_maxPayloadSizeBytes = COMMANDRUNNER_MAX_PAYLOAD;

static OSCONFIG_LOG_HANDLE g_agentLog = NULL;

extern char g_mpiCall[MPI_CALL_MESSAGE_LENGTH];

OSCONFIG_LOG_HANDLE GetLog()
{
    return g_agentLog;
}

void InitTraceLogging(void)
{
    TraceLoggingRegister(g_providerHandle);
}

void CloseTraceLogging(void)
{
    TraceLoggingUnregister(g_providerHandle);
}

#define ERROR_MESSAGE_CRASH "[ERROR] OSConfig crash due to "
#define ERROR_MESSAGE_SIGSEGV ERROR_MESSAGE_CRASH "segmentation fault (SIGSEGV)"
#define ERROR_MESSAGE_SIGFPE ERROR_MESSAGE_CRASH "fatal arithmetic error (SIGFPE)"
#define ERROR_MESSAGE_SIGILL ERROR_MESSAGE_CRASH "illegal instruction (SIGILL)"
#define ERROR_MESSAGE_SIGABRT ERROR_MESSAGE_CRASH "abnormal termination (SIGABRT)"
#define ERROR_MESSAGE_SIGBUS ERROR_MESSAGE_CRASH "illegal memory access (SIGBUS)"
#define EOL_TERMINATOR "\n"

static void SignalInterrupt(int signal)
{
    int logDescriptor = -1;
    char* errorMessage = NULL;
    size_t errorMessageSize = 0;
    size_t sizeOfMpiMessage = 0;
    ssize_t writeResult = -1;

    if (SIGSEGV == signal)
    {
        errorMessage = ERROR_MESSAGE_SIGSEGV;
    }
    else if (SIGFPE == signal)
    {
        errorMessage = ERROR_MESSAGE_SIGFPE;
    }
    else if (SIGILL == signal)
    {
        errorMessage = ERROR_MESSAGE_SIGILL;
    }
    else if (SIGABRT == signal)
    {
        errorMessage = ERROR_MESSAGE_SIGABRT;
    }
    else if (SIGBUS == signal)
    {
        errorMessage = ERROR_MESSAGE_SIGBUS;
    }
    else
    {
        OsConfigLogInfo(g_agentLog, "Interrupt signal (%d)", signal);
        g_stopSignal = signal; 
    }

    if (NULL != errorMessage)
    {
        errorMessageSize = strlen(errorMessage);

        if (0 < (logDescriptor = open(LOG_FILE, O_APPEND | O_WRONLY | O_NONBLOCK)))
        {
            if (0 < (writeResult = write(logDescriptor, (const void*)errorMessage, errorMessageSize)))
            {
                sizeOfMpiMessage = strlen(g_mpiCall);
                if (sizeOfMpiMessage > 0)
                {
                    writeResult = write(logDescriptor, (const void*)(&g_mpiCall[0]), sizeOfMpiMessage);
                }
                else
                {
                    writeResult = write(logDescriptor, (const void*)EOL_TERMINATOR, sizeof(char));
                }
            }
            close(logDescriptor);
        }

        _exit(signal);
    }
}

static void SignalReloadConfiguration(int signal)
{
    g_refreshSignal = signal;
}

static void SignalDoWork(int signal)
{
    UNUSED(signal);
    IoTHubDeviceClient_LL_DoWork(g_deviceHandle);
}

static void RefreshConnection()
{
    char* connectionString = NULL;

    FREE_MEMORY(g_x509Certificate);
    FREE_MEMORY(g_x509PrivateKeyHandle);

    // If initialized with AIS, try to get a new connection string same way:
    if (g_iotHubConnectionStringFromAis && (NULL != (connectionString = RequestConnectionStringFromAis(&g_x509Certificate, &g_x509PrivateKeyHandle))))
    {
        FREE_MEMORY(g_iotHubConnectionString);
        if (0 != mallocAndStrcpy_s(&g_iotHubConnectionString, connectionString))
        {
            LogErrorWithTelemetry(GetLog(), "RefreshConnection: out of memory making copy of the connection string");
            FREE_MEMORY(connectionString);
        }
    }
    else
    {
        if (g_iotHubConnectionStringFromAis)
        {
            // No new connection string from AIS, try to refresh using the existing connection string before bailing out:
            OsConfigLogError(GetLog(), "RefreshConnection: failed to obtain a new connection string from AIS, trying refresh with existing connection string");
        }
        connectionString = g_iotHubConnectionString;
    }

    if (NULL != connectionString)
    {
        // Reinitialize communication with the IoT Hub:
        IotHubDeInitialize();
        if (NULL == (g_deviceHandle = IotHubInitialize(connectionString, false, g_x509Certificate, g_x509PrivateKeyHandle)))
        {
            LogErrorWithTelemetry(GetLog(), "RefreshConnection: IotHubInitialize failed");
            g_exitState = IotHubInitializationFailure;
            SignalInterrupt(SIGQUIT);
        }

        IotHubDoWork();
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "RefreshConnection: no connection string");
        g_exitState = NoConnectionString;
        SignalInterrupt(SIGQUIT);
    }
}

void ScheduleRefreshConnection(void)
{
    OsConfigLogInfo(GetLog(), "Scheduling refresh connection");
    SignalReloadConfiguration(SIGHUP);
}

static void SignalChild(int signal)
{
    // No-op for this version of the agent
    UNUSED(signal);
}

static void ForkDaemon()
{
    OsConfigLogInfo(GetLog(), "Attempting to fork daemon process");

    int status = 0;

    UNUSED(status);
    
    pid_t pidDaemon = fork();
    if (pidDaemon < 0)
    {
        LogErrorWithTelemetry(GetLog(), "fork() failed, could not fork daemon process");
        exit(EXIT_FAILURE);
    }

    if (pidDaemon > 0)
    {
        // This is in the parent process, terminate it
        OsConfigLogInfo(GetLog(), "fork() succeeded, terminating parent");
        exit(EXIT_SUCCESS);
    }

    // The forked daemon process becomes session leader
    if (setsid() < 0)
    {
        LogErrorWithTelemetry(GetLog(), "setsid() failed, could not fork daemon process");
        exit(EXIT_FAILURE);
    }

    signal(SIGCHLD, SignalChild);
    signal(SIGHUP, SignalReloadConfiguration);

    // Fork off for the second time
    pidDaemon = fork();
    if (pidDaemon < 0)
    {
        LogErrorWithTelemetry(GetLog(), "Second fork() failed, could not fork daemon process");
        exit(EXIT_FAILURE);
    }

    if (pidDaemon > 0)
    {
        OsConfigLogInfo(GetLog(), "Second fork() succeeded, terminating parent");
        exit(EXIT_SUCCESS);
    }

    // Set new file permissions
    umask(0);

    // Change the working directory to the root directory
    status = chdir("/");
    LogAssert(GetLog(), 0 == status);

    // Close all open file descriptors
    for (int x = sysconf(_SC_OPEN_MAX); x >= 0; x--)
    {
        close(x);
    }
}

int main(int argc, char *argv[])
{
    char* connectionString = NULL;
    bool freeConnectionString = false;
    int stopSignalsCount = ARRAY_SIZE(g_stopSignals);
    bool forkDaemon = false;
 
    forkDaemon = (bool)(((3 == argc) && (NULL != argv[2]) && (0 == strcmp(argv[2], FORK_ARG))) || 
        ((2 == argc) && (NULL != argv[1]) && (0 == strcmp(argv[1], FORK_ARG))));

    g_agentLog = OpenLog(LOG_FILE, ROLLED_LOG_FILE, SYSLOG_NAME);
    InitTraceLogging();

    if (forkDaemon)
    {
        ForkDaemon();
    }

    g_iotHubConnectionStringFromAis = false;

    // Re-open the log
    CloseLog(&g_agentLog);
    g_agentLog = OpenLog(LOG_FILE, ROLLED_LOG_FILE, SYSLOG_NAME);

    OsConfigLogInfo(GetLog(), "OSConfig PnP Agent starting (PID: %d)", getpid());
    OsConfigLogInfo(GetLog(), "OSConfig version: %s", OSCONFIG_VERSION);

    TraceLoggingWrite(g_providerHandle, "AgentStart", TraceLoggingString(OSCONFIG_VERSION, "Version"));
    OsConfigLogInfo(GetLog(), "TraceLoggingWrite(AgentStart, Version: %s)", OSCONFIG_VERSION);

    if ((argc < 2) || ((2 == argc) && forkDaemon))
    {
        connectionString = RequestConnectionStringFromAis(&g_x509Certificate, &g_x509PrivateKeyHandle);
        if (NULL != connectionString)
        {
            freeConnectionString = true;
            g_iotHubConnectionStringFromAis = true;
        }
        else
        {
            OsConfigLogError(GetLog(), "Failed to obtain a connection string from AIS");
            g_exitState = NoConnectionString;
            goto done;
        }
    }
    else
    {
        if (0 == strncmp(argv[1], g_iotHubConnectionStringPrefix, strlen(g_iotHubConnectionStringPrefix)))
        {
            connectionString = argv[1];
        }
        else
        {
            connectionString = LoadStringFromFile(argv[1]);
            if (NULL != connectionString)
            {
                freeConnectionString = true;
            }
            else
            {
                LogErrorWithTelemetry(GetLog(), "Failed to load a connection string from %s", argv[1]);
                g_exitState = NoConnectionString;
                goto done;
            }
        }
    }

    if (0 != mallocAndStrcpy_s(&g_iotHubConnectionString, connectionString))
    {
        LogErrorWithTelemetry(GetLog(), "Out of memory making copy of the connection string");
        goto done;
    }

    for (int i = 0; i < stopSignalsCount; i++)
    {
        signal(g_stopSignals[i], SignalInterrupt);
    }
    signal(SIGHUP, SignalReloadConfiguration);
    signal(SIGUSR1, SignalDoWork);

    if (0 != InitializePnpModule(connectionString))
    {
        LogErrorWithTelemetry(GetLog(), "Failed to initialize OSConfig PnP module");
        goto done;
    }

    while (0 == g_stopSignal)
    {
        PnpModuleDoWork();
        ThreadAPI_Sleep(DOWORK_SLEEP);

        if (0 != g_refreshSignal)
        {
            RefreshConnection();
            g_refreshSignal = 0;
        }
    }

done:
    OsConfigLogInfo(GetLog(), "OSConfig PnP Agent exiting with %d", g_stopSignal);
    
    TraceLoggingWrite(g_providerHandle, "AgentShutdown", 
        TraceLoggingString(OSCONFIG_VERSION, "Version"),
        TraceLoggingInt32((int32_t)g_stopSignal, "ExitCode"),
        TraceLoggingInt32((int32_t)g_exitState, "ExitState"));
    OsConfigLogInfo(GetLog(), "TraceLoggingWrite(AgentShutdown, Version: %s, ExitCode: %u, ExitState: %d)", OSCONFIG_VERSION, g_stopSignal, g_exitState);

    FREE_MEMORY(g_x509Certificate);
    FREE_MEMORY(g_x509PrivateKeyHandle);
    FREE_MEMORY(g_iotHubConnectionString);
    if (freeConnectionString)
    {
        FREE_MEMORY(connectionString);
    }

    ClosePnpModule();
    CloseTraceLogging();
    CloseLog(&g_agentLog);

    return 0;
}

bool IsComponentSupported(const char* componentName)
{
    bool isSupported = false;
    
    if (NULL != componentName)
    {
        for (unsigned int i = 0; i < g_componentsListCount; i++)
        {
            if (0 == strcmp(componentName, g_components[i].componentName))
            {
                isSupported = true;
                break;
            }
        }
    }

    return isSupported;
}

bool IsComplexProperty(const char* componentName, const char* propertyName)
{
    bool complexProperty = true;

    if (0 == strcmp(componentName, SETTINGS_COMPONENT_NAME))
    {
        if (0 == strcmp(propertyName, SETTINGS_DEVICE_HEALTH_TELEMETRY_CONFIGURATION))
        {
            complexProperty = false;
        }
    }

    return complexProperty;
}

IOTHUB_CLIENT_REPORTED_STATE_CALLBACK GetComponentReportedStateCallback(const char* componentName)
{
    IOTHUB_CLIENT_REPORTED_STATE_CALLBACK reportedStateCallback = NULL;

    if (NULL != componentName)
    {
        for (unsigned int i = 0; i < g_componentsListCount; i++)
        {
            if (0 == strcmp(componentName, g_components[i].componentName))
            {
                reportedStateCallback = g_components[i].ReportedStateCallback;
                break;
            }
        }
    }

    return reportedStateCallback;
}

int InitializePnpModule(const char* connectionString)
{
    if (NULL == (g_tickCounter = tickcounter_create()))
    {
        LogErrorWithTelemetry(GetLog(), "tickcounter_create failed");
        return -1;
    }

    // Open the MPI session for this PnP Module instance:
    if (NULL == (g_mpiHandle = CallMpiOpen(g_mpiClientName, g_maxPayloadSizeBytes)))
    {
        LogErrorWithTelemetry(GetLog(), "MpiOpen failed");
        g_exitState = MpiInitializationFailure;
        return -1;
    }
    
    // Initialize communication with the IoT Hub:
    if (NULL == (g_deviceHandle = IotHubInitialize(connectionString, false, g_x509Certificate, g_x509PrivateKeyHandle)))
    {
        LogErrorWithTelemetry(GetLog(), "IotHubInitialize failed");
        g_exitState = IotHubInitializationFailure;
        return -1;
    }

    IotHubDoWork();

    // Signal to components beginning of session:
    for (unsigned int i = 0; i < g_componentsListCount; i++)
    {
        if (NULL != g_components[i].Initialize)
        {
            g_components[i].Initialize();
        }
    }

    tickcounter_get_current_ms(g_tickCounter, &g_lastTick);

    OsConfigLogInfo(GetLog(), "OSConfig PnP module initialized");

    return 0;
}

void PnpModuleDoWork(void)
{
    tickcounter_ms_t nowTick;
    tickcounter_get_current_ms(g_tickCounter, &nowTick);

    if (DOWORK_INTERVAL <= (nowTick - g_lastTick))
    {
        for (unsigned int i = 0; i < g_componentsListCount; i++)
        {
            if (NULL != g_components[i].DoWork)
            {
                g_components[i].DoWork();
            }
        }

        CallMpiDoWork();

        tickcounter_get_current_ms(g_tickCounter, &g_lastTick);
    }
    else
    {
        IotHubDoWork();
    }
}

void ClosePnpModule(void)
{
    IotHubDeInitialize();

    // Signal to components end of session:
    for (unsigned int i = 0; i < g_componentsListCount; i++)
    {
        if (NULL != g_components[i].Destroy)
        {
            g_components[i].Destroy();
        }
    }

    if (NULL != g_mpiHandle)
    {
        CallMpiClose(g_mpiHandle);
        g_mpiHandle = NULL;
    }

    OsConfigLogInfo(GetLog(), "OSConfig PnP module terminated");
}