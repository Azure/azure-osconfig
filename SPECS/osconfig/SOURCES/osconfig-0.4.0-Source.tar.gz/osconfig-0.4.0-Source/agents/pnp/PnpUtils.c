// Copyright (c) Microsoft. All rights reserved.
#include "inc/PnpUtils.h"
#include "inc/CommandRunner.h"
#include "inc/Settings.h"
#include "inc/MpiProxy.h"
#include "inc/PnpAgent.h"

#define EXTRA_PROP_PAYLOAD_ESTIMATE 256

static const char g_componentMarker[] = "__t";
static const char g_desiredObjectName[] = "desired";
static const char g_desiredVersion[] = "$version";
static const char g_child[] = "child";
static const char g_children[] = "children";

// The openssl engine from the AIS aziot-identity-service package: 
static const char g_azIotKeys[] = "aziot_keys";
static const OPTION_OPENSSL_KEY_TYPE g_keyTypeEngine = KEY_TYPE_ENGINE;

// The following values need to be filled via these templates, in order: 
// 1. component name
// 2. property name
// 3. property value (simple or complex/object)
// 4. ackowledged code (HTTP result)
// 5. ackowledged description (optional and here fixed to '-')
// 6. ackowledged version
static const char g_simplePropertyReadTemplate[] = "{\"""%s\":{\"__t\":\"c\",\"%s\":%s}}";
static const char g_complexPropertyReadTemplate[] = "{\"""%s\":{\"__t\":\"c\",\"%s\":%.*s}}";
static const char g_simplePropertyAckTemplate[] = "{\"""%s\":{\"__t\":\"c\",\"%s\":{\"value\":%s,\"ac\":%d,\"ad\":\"-\",\"av\":%d}}}";
static const char g_complexPropertyAckTemplate[] = "{\"""%s\":{\"__t\":\"c\",\"%s\":{\"value\":%.*s,\"ac\":%d,\"ad\":\"-\",\"av\":%d}}}";

IOTHUB_DEVICE_CLIENT_LL_HANDLE g_deviceHandle = NULL;

static bool g_lostNetworkConnection = false;

bool g_initializedFromTwin = false;

typedef IOTHUB_CLIENT_RESULT(*PROPERTY_UPDATE_CALLBACK)(const char* componentName, const char* propertyName, JSON_Value* propertyValue, int version);

static const char g_connectionAuthenticated[] = "IOTHUB_CLIENT_CONNECTION_AUTHENTICATED";
static const char g_connectionUnauthenticated[] = "IOTHUB_CLIENT_CONNECTION_UNAUTHENTICATED";

static void IotHubConnectionStatusCallback(IOTHUB_CLIENT_CONNECTION_STATUS result, IOTHUB_CLIENT_CONNECTION_STATUS_REASON reason, void* userContextCallback)
{
    bool authenticated = false;
    const char* connectionAuthentication = NULL;

    switch (result)
    {
        case IOTHUB_CLIENT_CONNECTION_AUTHENTICATED:
            connectionAuthentication = g_connectionAuthenticated;
            authenticated = true;
            break;

        case IOTHUB_CLIENT_CONNECTION_UNAUTHENTICATED:
            connectionAuthentication = g_connectionUnauthenticated;
            break;

        default:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: unknown %d result received", (int)result);
    }
    
    switch (reason)
    {
        case IOTHUB_CLIENT_CONNECTION_EXPIRED_SAS_TOKEN:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: %s, reason: IOTHUB_CLIENT_CONNECTION_EXPIRED_SAS_TOKEN", connectionAuthentication ? connectionAuthentication : "-");
            ScheduleRefreshConnection();
            break;

        case IOTHUB_CLIENT_CONNECTION_RETRY_EXPIRED:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: %s, reason: IOTHUB_CLIENT_CONNECTION_RETRY_EXPIRED", connectionAuthentication ? connectionAuthentication : "-");
            ScheduleRefreshConnection();
            break;

        case IOTHUB_CLIENT_CONNECTION_COMMUNICATION_ERROR:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: %s, reason: IOTHUB_CLIENT_CONNECTION_COMMUNICATION_ERROR", connectionAuthentication ? connectionAuthentication : "-");
            ScheduleRefreshConnection();
            break;

        case IOTHUB_CLIENT_CONNECTION_NO_PING_RESPONSE:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: %s, reason: IOTHUB_CLIENT_CONNECTION_NO_PING_RESPONSE", connectionAuthentication ? connectionAuthentication : "-");
            if (!authenticated)
            {
                g_lostNetworkConnection = true;
                OsConfigLogError(GetLog(), "Lost network connection");
            }
            break;

        case IOTHUB_CLIENT_CONNECTION_NO_NETWORK:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: %s, reason: IOTHUB_CLIENT_CONNECTION_NO_NETWORK", connectionAuthentication ? connectionAuthentication : "-");
            if (!authenticated)
            {
                g_lostNetworkConnection = true;
                OsConfigLogError(GetLog(), "Lost network connection");
            }
            break;

        case IOTHUB_CLIENT_CONNECTION_DEVICE_DISABLED:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: %s, reason: IOTHUB_CLIENT_CONNECTION_DEVICE_DISABLED", connectionAuthentication ? connectionAuthentication : "-");
            break;

        case IOTHUB_CLIENT_CONNECTION_BAD_CREDENTIAL:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: %s, reason: IOTHUB_CLIENT_CONNECTION_BAD_CREDENTIAL", connectionAuthentication ? connectionAuthentication : "-");
            break;

        case IOTHUB_CLIENT_CONNECTION_OK:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: %s, reason: IOTHUB_CLIENT_CONNECTION_OK", connectionAuthentication ? connectionAuthentication : "-");
            if (g_lostNetworkConnection && authenticated)
            {
                g_lostNetworkConnection = false;
                OsConfigLogInfo(GetLog(), "Got network connection");
                ScheduleRefreshConnection();
            }
            break;

        default:
            OsConfigLogInfo(GetLog(), "IotHubConnectionStatusCallback: %s, unknown reason %d received", connectionAuthentication ? connectionAuthentication : "-", (int)reason);
    }

    UNUSED(userContextCallback);
}

static IOTHUB_CLIENT_RESULT PropertyUpdateFromIotHubCallback(const char* componentName, const char* propertyName, JSON_Value* propertyValue, int version)
{
    IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_ERROR;

    if (NULL == componentName)
    {
        LogErrorWithTelemetry(GetLog(), "PropertyUpdateFromIotHubCallback: property %s arrived with a NULL component name, indicating root of device", propertyName);
        return result;
    }

    if (0 == strcmp(componentName, COMMANDRUNNER_COMPONENT_NAME))
    {
        OsConfigLogInfo(GetLog(), "PropertyUpdateFromIotHubCallback: invoking CommandRunner for property %s, version %d", propertyName, version);
        result = CommandRunnerProcessPropertyUpdateFromIotHub(propertyName, propertyValue, version);
    }
    else if (0 == strcmp(componentName, SETTINGS_COMPONENT_NAME))
    {
        OsConfigLogInfo(GetLog(), "PropertyUpdateFromIotHubCallback: invoking Settings for property %s, version %d", propertyName, version);
        result = SettingsProcessPropertyUpdateFromIotHub(propertyName, propertyValue, version);
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "PropertyUpdateFromIotHubCallback: component %s is not implemented", componentName);
    }

    return result;
}

static JSON_Object* GetDesiredJsonFromTwinUpdate(DEVICE_TWIN_UPDATE_STATE updateState, JSON_Value* rootValue)
{
    LogAssert(GetLog(), NULL != rootValue);

    JSON_Object* desiredObject = NULL;

    JSON_Object* rootObject = json_value_get_object(rootValue);
    if (NULL != rootObject)
    {
        if (DEVICE_TWIN_UPDATE_COMPLETE == updateState)
        {
            OsConfigLogInfo(GetLog(), "GetDesiredJsonFromTwinUpdate: DEVICE_TWIN_UPDATE_COMPLETE");

            // For a complete update the JSON from IoT Hub contains both "desired" and "reported" (the full twin):
            desiredObject = json_object_get_object(rootObject, g_desiredObjectName);
        }
        else
        {
            OsConfigLogInfo(GetLog(), "GetDesiredJsonFromTwinUpdate: DEVICE_TWIN_UPDATE_PARTIAL");

            // For a partial update the JSON from IoT Hub skips the "desired" envelope, we need to read from root:
            desiredObject = rootObject;
        }
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "GetDesiredJsonFromTwinUpdate: json_value_get_object(root) failed, cannot get desired object");
    }

    return desiredObject;
}

static IOTHUB_CLIENT_RESULT UpdateComponentProperties(const char* objectName, const JSON_Value* value, PROPERTY_UPDATE_CALLBACK propertyCallback, int version)
{
    IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_OK;

    LogAssert(GetLog(), NULL != propertyCallback);

    JSON_Object* object = json_value_get_object(value);
    size_t numChildren = json_object_get_count(object);

    OsConfigLogInfo(GetLog(), "UpdateComponentProperties: %d %s in component", (int)numChildren, (1 == numChildren) ? g_child : g_children);

    for (size_t i = 0; i < numChildren; i++)
    {
        const char* propertyName = json_object_get_name(object, i);
        JSON_Value* propertyValue = json_object_get_value_at(object, i);

        if ((NULL == propertyName) || (NULL == propertyValue))
        {
            LogErrorWithTelemetry(GetLog(), "UpdateComponentProperties: error retrieving property name and/or value for component %s at index %u", objectName, (int)i);
            continue;
        }

        if (0 == strcmp(propertyName, g_componentMarker))
        {
            // Ignore the marker
            continue;
        }

        OsConfigLogInfo(GetLog(), "UpdateComponentProperties: child[%d] name is %s", (int)i, propertyName);

        // Invoke the application's passed in callback for it to process this property.
        OsConfigLogInfo(GetLog(), "UpdateComponentProperties: child[%d] is a property, process it", (int)i);
        result = propertyCallback(objectName, propertyName, propertyValue, version);
    }

    return result;
}

static int GetVersionFromObject(JSON_Object* desiredObject)
{
    int version = 0;

    JSON_Value* versionValue = json_object_get_value(desiredObject, g_desiredVersion);
    if (NULL != versionValue)
    {
        if (JSONNumber == json_value_get_type(versionValue))
        {
            version = (int)json_value_get_number(versionValue);
            OsConfigLogInfo(GetLog(), "Version (%s): %d", g_desiredVersion, version);
        }
        else
        {
            LogErrorWithTelemetry(GetLog(), "Field %s type is not JSONNumber, cannot read the desired version", g_desiredVersion);
        }
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "json_object_get_value(%s) failed, cannot read the desired version", g_desiredVersion);
    }

    return version;
}

static IOTHUB_CLIENT_RESULT ProcessDesiredJsonFromTwin(JSON_Object* desiredObject, PROPERTY_UPDATE_CALLBACK propertyCallback)
{
    IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_OK;
    int version = 0;
    size_t numChildren = 0;

    LogAssert(GetLog(), NULL != desiredObject);

    version = GetVersionFromObject(desiredObject);
    numChildren = json_object_get_count(desiredObject);

    OsConfigLogInfo(GetLog(), "ProcessDesiredJsonFromTwin: %d %s in desired object, version %d", (int)numChildren, (1 == numChildren) ? g_child : g_children, version);

    for (size_t i = 0; i < numChildren; i++)
    {
        const char* name = json_object_get_name(desiredObject, i);
        JSON_Value* value = json_object_get_value_at(desiredObject, i);

        if (0 == strcmp(name, g_desiredVersion))
        {
            // Ignore, nothing to do here
            continue;
        }

        OsConfigLogInfo(GetLog(), "ProcessDesiredJsonFromTwin: child[%d] name is %s", (int)i, name);

        if ((JSONObject == json_type(value)) && (IsComponentSupported(name)))
        {
            OsConfigLogInfo(GetLog(), "ProcessDesiredJsonFromTwin: child[%d] is a supported component object, process it", (int)i);
            result = UpdateComponentProperties(name, value, propertyCallback, version);
        }
    }

    return result;
}

static char* CopyPayloadToString(const unsigned char* payload, size_t size)
{
    char* jsonStr = NULL;
    size_t sizeToAllocate = size + 1;

    if (NULL != (jsonStr = (char*)malloc(sizeToAllocate)))
    {
        memcpy(jsonStr, payload, size);
        jsonStr[size] = '\0';
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "CopyPayloadToString: out pof memory allocating %d bytes", (int)sizeToAllocate);
    }

    return jsonStr;
}

static IOTHUB_CLIENT_RESULT ProcessJsonFromTwin(DEVICE_TWIN_UPDATE_STATE updateState, const unsigned char* payload, size_t size, PROPERTY_UPDATE_CALLBACK propertyCallback)
{
    IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_OK;

    LogAssert(GetLog(), NULL != payload);

    char* jsonStr = CopyPayloadToString(payload, size);
    if (NULL == jsonStr)
    {
        LogErrorWithTelemetry(GetLog(), "ProcessJsonFromTwin: failed");
        return IOTHUB_CLIENT_ERROR;
    }

    JSON_Value* rootValue = json_parse_string(jsonStr);
    if (NULL != rootValue)
    {
        JSON_Object* desiredObject = GetDesiredJsonFromTwinUpdate(updateState, rootValue);
        if (NULL != desiredObject)
        {
            result = ProcessDesiredJsonFromTwin(desiredObject, propertyCallback);
        }

        json_value_free(rootValue);
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "ProcessJsonFromTwin: json_parse_string failed");
    }

    free(jsonStr);

    UNUSED(propertyCallback);

    return result;
}

static void DeviceTwinCallback(DEVICE_TWIN_UPDATE_STATE updateState, const unsigned char* payload, size_t size, void* userContextCallback)
{
    LogAssert(GetLog(), NULL != payload);
    LogAssert(GetLog(), 0 < size);
    
#ifdef LOG_VALUE_PAYLOAD
    OsConfigLogInfo(GetLog(), "DeviceTwinCallback: received %.*s (%d bytes)", (int)size, payload, (int)size);
#else
    OsConfigLogInfo(GetLog(), "DeviceTwinCallback: received %d bytes", (int)size);
#endif

    IOTHUB_CLIENT_RESULT result = ProcessJsonFromTwin(updateState, payload, size, PropertyUpdateFromIotHubCallback);

    g_initializedFromTwin = true;

    UNUSED(userContextCallback);

    OsConfigLogInfo(GetLog(), "DeviceTwinCallback completed with result %d", (int)result);
}

static bool IotHubSetOption(const char* optionName, const void* value)
{
    if ((NULL == g_deviceHandle) || (NULL == optionName) || (NULL == value))
    {
        LogErrorWithTelemetry(GetLog(), "Invalid argument, IotHubSetOption failed");
        return false;
    }

    IOTHUB_CLIENT_RESULT iothubClientResult = IOTHUB_CLIENT_ERROR;
    if (IOTHUB_CLIENT_OK != (iothubClientResult = IoTHubDeviceClient_LL_SetOption(g_deviceHandle, optionName, value)))
    {
        LogErrorWithTelemetry(GetLog(), "Failed to set option %s, error %d", optionName, iothubClientResult);
        IoTHubDeviceClient_LL_Destroy(g_deviceHandle);
        g_deviceHandle = NULL;

        IoTHub_Deinit();
        return false;
    }
    else
    {
        return true;
    }
}

IOTHUB_DEVICE_CLIENT_LL_HANDLE IotHubInitialize(const char* connectionString, bool traceOn, const char* x509Certificate, const char* x509PrivateKeyHandle)
{
    IOTHUB_CLIENT_RESULT iothubResult = IOTHUB_CLIENT_OK;

    bool urlEncodeOn = true;
    
    if (NULL != g_deviceHandle)
    {
        LogErrorWithTelemetry(GetLog(), "IotHubInitialize called at the wrong time");
        return NULL;
    }
    
    if (0 != IoTHub_Init())
    {
        LogErrorWithTelemetry(GetLog(), "IoTHub_Init failed");
    }
    else
    {
        if (NULL == (g_deviceHandle = IoTHubDeviceClient_LL_CreateFromConnectionString(connectionString, MQTT_Protocol)))
        {
            LogErrorWithTelemetry(GetLog(), "IoTHubDeviceClient_LL_CreateFromConnectionString failed");
        }
        else
        {
            IotHubSetOption(OPTION_LOG_TRACE, &traceOn);
            IotHubSetOption(OPTION_MODEL_ID, DEVICE_MODEL_ID);
            IotHubSetOption(OPTION_PRODUCT_INFO, DEVICE_PRODUCT_INFO);
            IotHubSetOption(OPTION_AUTO_URL_ENCODE_DECODE, &urlEncodeOn);
            
            if ((NULL != x509Certificate) && (NULL != x509PrivateKeyHandle))
            {
                IotHubSetOption(OPTION_OPENSSL_ENGINE, g_azIotKeys);
                IotHubSetOption(OPTION_OPENSSL_PRIVATE_KEY_TYPE, &g_keyTypeEngine);
                IotHubSetOption(OPTION_X509_CERT, x509Certificate);
                IotHubSetOption(OPTION_X509_PRIVATE_KEY, x509PrivateKeyHandle);
            }

            if (IOTHUB_CLIENT_OK != (iothubResult = IoTHubDeviceClient_LL_SetDeviceTwinCallback(g_deviceHandle, DeviceTwinCallback, (void*)g_deviceHandle)))
            {
                LogErrorWithTelemetry(GetLog(), "IoTHubDeviceClient_SetDeviceTwinCallback failed with %d", iothubResult);
            }
            else if (IOTHUB_CLIENT_OK != (iothubResult = IoTHubDeviceClient_LL_SetConnectionStatusCallback(g_deviceHandle, IotHubConnectionStatusCallback, (void*)g_deviceHandle)))
            {
                LogErrorWithTelemetry(GetLog(), "IoTHubDeviceClient_LL_SetConnectionStatusCallback failed with %d", iothubResult);
            }
        }

        if (NULL == g_deviceHandle)
        {
            LogErrorWithTelemetry(GetLog(), "IotHubInitialize failed");
            IoTHub_Deinit();
        }
    }

    return g_deviceHandle;
}

void IotHubDeInitialize(void)
{
    if (NULL != g_deviceHandle)
    {
        IoTHubDeviceClient_LL_Destroy(g_deviceHandle);
        IoTHub_Deinit();
        g_deviceHandle = NULL;
    }
}

void IotHubDoWork(void)
{
    IoTHubDeviceClient_LL_DoWork(g_deviceHandle);
}

IOTHUB_CLIENT_RESULT ReportPropertyToIotHub(const char* componentName, const char* propertyName, SHOULD_REPORT_PROPERTY_TO_IOTHUB_CALLBACK shouldReportPropertyToTwinCallback, bool mustReport)
{
    IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_OK;
    char* valuePayload = NULL;
    int valueLength = 0;
    bool reportProperty = false;
    char* decoratedPayload = NULL;
    int decoratedLength = 0;
    bool complexProperty = true;
    int mpiResult = MPI_OK;

    LogAssert(GetLog(), NULL != componentName);
    LogAssert(GetLog(), NULL != propertyName);

    if (NULL == g_deviceHandle)
    {
        LogErrorWithTelemetry(GetLog(), "%s: the component needs to be initialized before reporting properties", componentName);
        return IOTHUB_CLIENT_ERROR;
    }

    mpiResult = CallMpiGet(componentName, propertyName, &valuePayload, &valueLength, false);

    if ((MPI_OK == mpiResult) && (valueLength > 0))
    {
        if (NULL != shouldReportPropertyToTwinCallback)
        {
            reportProperty = mustReport ? mustReport : shouldReportPropertyToTwinCallback(propertyName, valuePayload, valueLength);
        }

        if (reportProperty)
        {
            LogMpiGet(componentName, propertyName, valuePayload, valueLength, mpiResult);

            OsConfigLogInfo(GetLog(), "%s: report property %s, %u bytes", componentName, propertyName, valueLength);

            complexProperty = IsComplexProperty(componentName, propertyName);

            decoratedLength = strlen(componentName) + strlen(propertyName) + valueLength + EXTRA_PROP_PAYLOAD_ESTIMATE;
            decoratedPayload = (char*)malloc(decoratedLength);
            if (NULL != decoratedPayload)
            {
                if (complexProperty)
                {
                    snprintf(decoratedPayload, decoratedLength, g_complexPropertyReadTemplate, componentName, propertyName, valueLength, valuePayload);
                }
                else
                {
                    snprintf(decoratedPayload, decoratedLength, g_simplePropertyReadTemplate, componentName, propertyName, valuePayload);
                }

                LogAssert(GetLog(), decoratedLength >= (int)strlen(decoratedPayload));
                decoratedLength = strlen(decoratedPayload);

                result = IoTHubDeviceClient_LL_SendReportedState(g_deviceHandle, (const unsigned char*)decoratedPayload, decoratedLength,
                    GetComponentReportedStateCallback(componentName), NULL);

#ifdef LOG_VALUE_PAYLOAD
                OsConfigLogInfo(GetLog(), "%s: reported %.*s (%d bytes), result: %d", componentName, decoratedLength, decoratedPayload, decoratedLength, result);
#endif 
                if (IOTHUB_CLIENT_OK == result)
                {
                    OsConfigLogInfo(GetLog(), "%s: property %s successfully reported to IoT Hub", componentName, propertyName);
                }
                else
                {
                    LogErrorWithTelemetry(GetLog(), "%s: property %s failed to be reported to IoT Hub with result %d", componentName, propertyName, result);
                }

                IotHubDoWork();
            }
            else
            {
                LogErrorWithTelemetry(GetLog(), "%s: out of memory allocating %u bytes to report property %s", componentName, decoratedLength, propertyName);
            }

            TraceLoggingWrite(g_providerHandle, "ReportPropertyToIotHub",
                TraceLoggingString(componentName, "Component"),
                TraceLoggingString(propertyName, "Property"),
                TraceLoggingInt32((int32_t)result, "Result"));
            OsConfigLogInfo(GetLog(), "TraceLoggingWrite(ReportPropertyToIotHub, Component: %s, Property: %s, Result: %d)", componentName, propertyName, result);
        }
    }
    else
    {
        OsConfigLogInfo(GetLog(), "%s: MPI failed to return data for property %s", componentName, propertyName);
        result = IOTHUB_CLIENT_INVALID_ARG;
    }

    CallMpiFree(valuePayload);

    FREE_MEMORY(decoratedPayload);

    return result;
}

IOTHUB_CLIENT_RESULT UpdatePropertyFromIotHub(const char* componentName, const char* propertyName, const JSON_Value* propertyValue, int version)
{
    IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_OK;
    int propertyUpdateResult = PNP_STATUS_SUCCESS;
    char* serializedValue = NULL;
    int valueLength = 0;
    int mpiResult = MPI_OK;

    LogAssert(GetLog(), NULL != componentName);
    LogAssert(GetLog(), NULL != propertyName);
    LogAssert(GetLog(), NULL != propertyValue);

    serializedValue = json_serialize_to_string(propertyValue);
    if (NULL == serializedValue)
    {
        OsConfigLogInfo(GetLog(), "%s: %s property update requested with no data (nothing to do)", componentName, propertyName);
    }
    else
    {
        valueLength = strlen(serializedValue);

#ifdef LOG_VALUE_PAYLOAD
        OsConfigLogInfo(GetLog(), "%s: received %.*s (%d bytes)", componentName, valueLength, serializedValue, valueLength);
#endif
        
        mpiResult = CallMpiSet(componentName, propertyName, serializedValue, valueLength);

        if (MPI_OK == mpiResult)
        {
            OsConfigLogInfo(GetLog(), "%s: property %s successfully updated via MPI", componentName, propertyName);
            result = IOTHUB_CLIENT_OK;
            propertyUpdateResult = PNP_STATUS_SUCCESS;
        }
        else
        {
            LogErrorWithTelemetry(GetLog(), "%s: failed to update via MPI property %s", componentName, propertyName);
            result = IOTHUB_CLIENT_INVALID_ARG;
            propertyUpdateResult = PNP_STATUS_BAD_DATA;
        }

        result = AckPropertyUpdateToIotHub(componentName, propertyName, serializedValue, valueLength, version, propertyUpdateResult);

        json_free_serialized_string(serializedValue);
    }

    TraceLoggingWrite(g_providerHandle, "UpdatePropertyFromIotHub", 
        TraceLoggingString(componentName, "Component"), 
        TraceLoggingString(propertyName, "Property"), 
        TraceLoggingInt32((int32_t)result, "Result"));
    OsConfigLogInfo(GetLog(), "TraceLoggingWrite(UpdatePropertyFromIotHub, Component: %s, Property: %s, Result: %d)", componentName, propertyName, result);

    return result;
}

IOTHUB_CLIENT_RESULT AckPropertyUpdateToIotHub(const char* componentName, const char* propertyName, char* propertyValue, int valueLength, int version, int propertyUpdateResult)
{
    IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_OK;
    int ackCode = propertyUpdateResult;
    char* ackBuffer = NULL;
    int ackValueLength = 0;
    bool complexProperty = true;
    
    LogAssert(GetLog(), NULL != componentName);
    LogAssert(GetLog(), NULL != propertyName);
    LogAssert(GetLog(), NULL != propertyValue);
    LogAssert(GetLog(), 0 != valueLength);

    OsConfigLogInfo(GetLog(), "%s: acknowledging received new desired payload for property %s, version %d, ack. code %d",  componentName, propertyName, version, ackCode);

    complexProperty = IsComplexProperty(componentName, propertyName);

    ackValueLength = strlen(componentName) + strlen(propertyName) + valueLength + EXTRA_PROP_PAYLOAD_ESTIMATE;
    ackBuffer = (char*)malloc(ackValueLength);
    if (NULL != ackBuffer)
    {
        if (complexProperty)
        {
            snprintf(ackBuffer, ackValueLength, g_complexPropertyAckTemplate, componentName, propertyName, valueLength, propertyValue, ackCode, version);
        }
        else
        {
            snprintf(ackBuffer, ackValueLength, g_simplePropertyAckTemplate, componentName, propertyName, propertyValue, ackCode, version);
        }

        LogAssert(GetLog(), ackValueLength >= (int)strlen(ackBuffer));
        ackValueLength = strlen(ackBuffer);

        result = IoTHubDeviceClient_LL_SendReportedState(g_deviceHandle, (const unsigned char*)ackBuffer, ackValueLength, 
            GetComponentReportedStateCallback(componentName), (void*)propertyName);

#ifdef LOG_VALUE_PAYLOAD
        OsConfigLogInfo(GetLog(), "%s: acknowledged %.*s (%d bytes), result: %d", componentName, ackValueLength, ackBuffer, ackValueLength, result);
#endif 

        if (IOTHUB_CLIENT_OK == result)
        {
            OsConfigLogInfo(GetLog(), "%s: property %s successfully acknowledged to IoT Hub", componentName, propertyName);
        }
        else
        {
            LogErrorWithTelemetry(GetLog(), "%s: property %s failed to be acknowledged to IoT Hub with result %d", componentName, propertyName, result);
        }

        IotHubDoWork();
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "%s: out of memory allocating %u bytes to acknowledge property %s", componentName, ackValueLength, propertyName);
    }

    FREE_MEMORY(ackBuffer);

    return result;
}