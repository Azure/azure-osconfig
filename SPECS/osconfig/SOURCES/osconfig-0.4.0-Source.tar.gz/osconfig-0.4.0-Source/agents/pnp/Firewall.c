// Copyright (c) Microsoft. All rights reserved.
#include "inc/PnpUtils.h"
#include "inc/MpiProxy.h"
#include "inc/Firewall.h"

// In the future when the payload will increase, this payload copy could be replaced by a hash of the same
static char* g_prevFirewallRules = NULL;
static int g_prevFirewallRulesSize = 0;

static bool CheckFirewallReportedPayload(const char* propertyName, char* payload)
{
    bool result = true;
    JSON_Value* propertyValue = NULL;
    JSON_Object* jsonObject = NULL;

    if (0 != strcmp(propertyName, FIREWALL_RULES))
    {
        return false;
    }

    if (NULL == (propertyValue = json_parse_string(payload)))
    {
        LogErrorWithTelemetry(GetLog(), "Firewall: json_parse_string for %s failed", propertyName);
        result = false;
    }

    if (result && (JSONObject != json_value_get_type(propertyValue)))
    {
        LogErrorWithTelemetry(GetLog(), "Firewall: invalid type for %s, not object", propertyName);
        result = false;
    }

    if (result && (NULL == (jsonObject = json_value_get_object(propertyValue))))
    {
        LogErrorWithTelemetry(GetLog(), "Firewall: json_value_get_object for %s failed", propertyName);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, FIREWALL_DIRECTIONS, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Firewall: %s missing required %s as a string", propertyName, FIREWALL_DIRECTIONS);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, FIREWALL_TARGETS, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Firewall: %s missing required %s as a string", propertyName, FIREWALL_TARGETS);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, FIREWALL_PROTOCOLS, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Firewall: %s missing required %s as a string", propertyName, FIREWALL_PROTOCOLS);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, FIREWALL_IPADDRESSES, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Firewall: %s missing required %s as a string", propertyName, FIREWALL_IPADDRESSES);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, FIREWALL_PORTS, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "Firewall: %s missing required %s as a string", propertyName, FIREWALL_PORTS);
        result = false;
    }

    if (propertyValue)
    {
        json_value_free(propertyValue);
    }

    return result;
}

static bool FirewallShouldReportPropertyToIotHubCallback(const char* propertyName, char* payload, int payloadSizeBytes)
{
    bool reportProperty = true;

    LogAssert(GetLog(), NULL != propertyName);
    LogAssert(GetLog(), NULL != payload);
    
    if (0 != strcmp(propertyName, FIREWALL_RULES))
    {
        return false;
    }

    if ((g_prevFirewallRulesSize == payloadSizeBytes) && (0 == memcmp(payload, g_prevFirewallRules, payloadSizeBytes)))
    {
        reportProperty = false;
    }
    else
    {
        FREE_MEMORY(g_prevFirewallRules);
        g_prevFirewallRulesSize = 0;

        if ((!payload) || (!CheckFirewallReportedPayload(propertyName, payload)))
        {
            LogErrorWithTelemetry(GetLog(), "Firewall: invalid payload for %s, cannot report", propertyName);
            reportProperty = false;
        }
        else
        {
            g_prevFirewallRules = (char*)malloc(payloadSizeBytes);
            if (NULL != g_prevFirewallRules)
            {
                memcpy(g_prevFirewallRules, payload, payloadSizeBytes);
                g_prevFirewallRulesSize = payloadSizeBytes;

                OsConfigLogInfo(GetLog(), "Firewall: %s property value appears new", propertyName);
            }
            else
            {
                LogErrorWithTelemetry(GetLog(), "FirewallShouldReportPropertyToIotHubCallback: out of memory allocating %u bytes", payloadSizeBytes);
                reportProperty = false;
            }
        }

        if (payloadSizeBytes > FIREWALL_MAX_PAYLOAD)
        {
            LogErrorWithTelemetry(GetLog(), "Firewall: payload size for %s is %d bytes, larger than maximum %u bytes, cannot report",
                propertyName, payloadSizeBytes, FIREWALL_MAX_PAYLOAD);
            reportProperty = false;
        }
    }

    return reportProperty;
}

void FirewallReportedStateCallback(int statusCode, void* userContextCallback)
{
    OsConfigLogInfo(GetLog(), "Firewall: ReportedStateCallback called with status code %u", statusCode);
    UNUSED(userContextCallback);
}

static IOTHUB_CLIENT_RESULT FirewallReportPropertyToIotHub(const char* propertyName)
{
    return ReportPropertyToIotHub(FIREWALL_COMPONENT_NAME, propertyName, FirewallShouldReportPropertyToIotHubCallback, false);
}

void FirewallInitialize(void)
{
    OsConfigLogInfo(GetLog(), "Firewall PnP component initialized");
}

void FirewallDoWork(void)
{
    // Invoked every DOWORK_INTERVAL with DOWORK_SLEEP delay (fine tune via these macros):
    FirewallReportPropertyToIotHub(FIREWALL_RULES);
}

void FirewallDestroy(void)
{
    FREE_MEMORY(g_prevFirewallRules);
    OsConfigLogInfo(GetLog(), "Firewall PnP component terminated");
}