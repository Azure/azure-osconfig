// Copyright (c) Microsoft. All rights reserved.
#include "inc/PnpUtils.h"
#include "inc/MpiProxy.h"
#include "inc/Settings.h"

static bool CheckSettingsDesiredPayload(const char* propertyName, const JSON_Value* propertyValue)
{
    bool result = true;
    int healthTelemetry = -1;
    JSON_Object* jsonObject = NULL;
    int percentageDownloadThrottle = -1;
    int cacheHostSource = -1;
    const char* cacheHost = NULL;

    if ((NULL == propertyName) || (NULL == propertyValue))
    {
        LogErrorWithTelemetry(GetLog(), "Settings: update attempted without a property name or value");
        result = false;
    }

    if (0 == strcmp(propertyName, SETTINGS_DEVICE_HEALTH_TELEMETRY_CONFIGURATION))
    {
        healthTelemetry = json_value_get_number(propertyValue);
        if ((healthTelemetry < HealthTelemetryNone) || (healthTelemetry > HealthTelemetryOptional))
        {
            LogErrorWithTelemetry(GetLog(), "Settings: invalid %s value (%d)", SETTINGS_DEVICE_HEALTH_TELEMETRY_CONFIGURATION, healthTelemetry);
            result = false;
        }
    }
    else if (0 == strcmp(propertyName, SETTINGS_DELIVERY_OPTIMIZATION_POLICIES))
    {
        if (json_value_get_type(propertyValue) != JSONObject)
        {
            LogErrorWithTelemetry(GetLog(), "Settings: invalid %s value type, not object", SETTINGS_DELIVERY_OPTIMIZATION_POLICIES);
            result = false;
        }

        if (result && (NULL == (jsonObject = json_value_get_object(propertyValue))))
        {
            LogErrorWithTelemetry(GetLog(), "Settings: json_value_get_object for %s failed", SETTINGS_DELIVERY_OPTIMIZATION_POLICIES);
            result = false;
        }

        if (result && (0 == json_object_has_value_of_type(jsonObject, DO_PERCENTAGE_DOWNLOAD_THROTTLE, JSONNumber)))
        {
            LogErrorWithTelemetry(GetLog(), "Settings: %s missing %s as a number", SETTINGS_DELIVERY_OPTIMIZATION_POLICIES, DO_PERCENTAGE_DOWNLOAD_THROTTLE);
            result = false;
        }

        if (result)
        {
            percentageDownloadThrottle = json_object_get_number(jsonObject, DO_PERCENTAGE_DOWNLOAD_THROTTLE);
            if ((percentageDownloadThrottle < 0) || (percentageDownloadThrottle > 100))
            {
                LogErrorWithTelemetry(GetLog(), "Settings: %s invalid %s value (%d), not an integer percentage between 0 and 100", SETTINGS_DELIVERY_OPTIMIZATION_POLICIES,
                    DO_PERCENTAGE_DOWNLOAD_THROTTLE, percentageDownloadThrottle);
                result = false;
            }
        }

        if (result && (0 == json_object_has_value_of_type(jsonObject, DO_CACHE_HOST_SOURCE, JSONNumber)))
        {
            LogErrorWithTelemetry(GetLog(), "Settings: %s missing %s as a number", SETTINGS_DELIVERY_OPTIMIZATION_POLICIES, DO_CACHE_HOST_SOURCE);
            result = false;
        }

        if (result)
        {
            cacheHostSource = json_object_get_number(jsonObject, DO_CACHE_HOST_SOURCE);
            if ((cacheHostSource < CacheHostSourceNone) || (cacheHostSource > CacheHostSourceDhcpServerCustomOptionId235))
            {
                LogErrorWithTelemetry(GetLog(), "Settings: %s unsupported %s value (%d)", SETTINGS_DELIVERY_OPTIMIZATION_POLICIES, DO_CACHE_HOST_SOURCE, cacheHostSource);
                result = false;
            }
        }

        if (result && (0 == json_object_has_value_of_type(jsonObject, DO_CACHE_HOST, JSONString)))
        {
            LogErrorWithTelemetry(GetLog(), "Settings: %s missing %s as a string", SETTINGS_DELIVERY_OPTIMIZATION_POLICIES, DO_CACHE_HOST);
            result = false;
        }

        if (result && (NULL == (cacheHost = json_object_get_string(jsonObject, DO_CACHE_HOST))))
        {
            LogErrorWithTelemetry(GetLog(), "Settings: %s, json_object_get_string for %s failed", SETTINGS_DELIVERY_OPTIMIZATION_POLICIES, DO_CACHE_HOST);
            result = false;
        }

        if (result && (0 == json_object_has_value_of_type(jsonObject, DO_CACHE_HOST_FALLBACK, JSONNumber)))
        {
            LogErrorWithTelemetry(GetLog(), "Settings: %s missing %s as a number", SETTINGS_DELIVERY_OPTIMIZATION_POLICIES, DO_CACHE_HOST_FALLBACK);
            result = false;
        }
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "Settings: unsupported property %s", propertyName);
        result = false;
    }

    return result;
}

IOTHUB_CLIENT_RESULT SettingsProcessPropertyUpdateFromIotHub(const char* propertyName, const JSON_Value* propertyValue, int version)
{
    IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_OK;
 
    LogAssert(GetLog(), NULL != propertyName);
    LogAssert(GetLog(), NULL != propertyValue);

    if (CheckSettingsDesiredPayload(propertyName, propertyValue))
    {
        result = UpdatePropertyFromIotHub(SETTINGS_COMPONENT_NAME, propertyName, propertyValue, version);
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "Settings: %s update received with invalid desired payload, not accepted", propertyName);
        result = IOTHUB_CLIENT_ERROR;
    }

    return result;
}

void SettingsReportedStateCallback(int statusCode, void* userContextCallback)
{
    OsConfigLogInfo(GetLog(), "Settings: ReportedStateCallback called with status code %u", statusCode);
    UNUSED(userContextCallback);
}

void SettingsInitialize(void)
{
    OsConfigLogInfo(GetLog(), "Settings PnP component initialized");
}

void SettingsDestroy(void)
{
    OsConfigLogInfo(GetLog(), "Settings PnP component terminated");
}