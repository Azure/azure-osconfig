// Copyright (c) Microsoft. All rights reserved.
#include "inc/PnpUtils.h"
#include "inc/MpiProxy.h"
#include "inc/CommandRunner.h"

// In the future when the payload will increase, this payload copy could be replaced by a hash of the same
static char* g_prevCommandStatus = NULL;
static int g_prevCommandStatusSize = 0;

static bool CheckCommandRunnerReportedPayload(char* payload)
{
    bool result = true;
    JSON_Value* propertyValue = NULL;
    JSON_Object* jsonObject = NULL;
    const char* commandId = NULL;
    int resultCode = -1;
    int currentState = -1;

    if (NULL == (propertyValue = json_parse_string(payload)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: json_parse_string for CommandStatus failed");
        result = false;
    }

    if (result && (JSONObject != json_value_get_type(propertyValue)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: invalid type for CommandStatus, not object");
        result = false;
    }

    if (result && (NULL == (jsonObject = json_value_get_object(propertyValue))))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: json_value_get_object for CommandStatus failed");
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, COMMANDRUNNER_COMMAND_ID, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandStatus missing required %s as a string", COMMANDRUNNER_COMMAND_ID);
        result = false;
    }

    if (result && (NULL == (commandId = json_object_get_string(jsonObject, COMMANDRUNNER_COMMAND_ID))))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandArguments, json_object_get_string for %s failed", COMMANDRUNNER_COMMAND_ID);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, COMMANDRUNNER_RESULT_CODE, JSONNumber)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandStatus missing required %s as a number", COMMANDRUNNER_RESULT_CODE);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, COMMANDRUNNER_EXTENDED_RESULT_CODE, JSONNumber)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandStatus missing required %s as a number", COMMANDRUNNER_EXTENDED_RESULT_CODE);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, COMMANDRUNNER_TEXT_RESULT, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandStatus missing required %s as a string", COMMANDRUNNER_TEXT_RESULT);
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, COMMANDRUNNER_CURRENT_STATE, JSONNumber)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandStatus missing required %s as a number", COMMANDRUNNER_CURRENT_STATE);
        result = false;
    }

    if (result)
    {
        resultCode = json_object_get_number(jsonObject, COMMANDRUNNER_RESULT_CODE);
        
        currentState = json_object_get_number(jsonObject, COMMANDRUNNER_CURRENT_STATE);
        if ((currentState < CommandStatusUnknown) || (currentState > CommandStatusFailed))
        {
            LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandStatus with unsupported %s value (%d)", COMMANDRUNNER_CURRENT_STATE, currentState);
            result = false;
        }
    }

    TraceLoggingWrite(g_providerHandle, "CommandResult",
        TraceLoggingString(commandId, "CommandId"),
        TraceLoggingInt32(resultCode, "Status"));

    if (propertyValue)
    {
        json_value_free(propertyValue);
    }

    return result;
}

static bool CommandRunnerShouldReportPropertyToIotHubCallback(const char* propertyName, char* payload, int payloadSizeBytes)
{
    bool reportProperty = true;

    LogAssert(GetLog(), NULL != propertyName);
    LogAssert(GetLog(), NULL != payload);
    
    if (0 != strcmp(propertyName, COMMANDRUNNER_COMMAND_STATUS))
    {
        return false;
    }

    if ((g_prevCommandStatusSize == payloadSizeBytes) && (0 == memcmp(payload, g_prevCommandStatus, payloadSizeBytes)))
    {
        reportProperty = false;
    }
    else
    {
        FREE_MEMORY(g_prevCommandStatus);
        g_prevCommandStatusSize = 0;

        if ((!payload) || (!CheckCommandRunnerReportedPayload(payload)))
        {
            LogErrorWithTelemetry(GetLog(), "CommandRunner: invalid payload for CommandStatus, cannot report");
            reportProperty = false;
        }
        else
        {
            g_prevCommandStatus = (char*)malloc(payloadSizeBytes);
            if (NULL != g_prevCommandStatus)
            {
                memcpy(g_prevCommandStatus, payload, payloadSizeBytes);
                g_prevCommandStatusSize = payloadSizeBytes;

                OsConfigLogInfo(GetLog(), "CommandRunner: %s property value appears new", propertyName);
            }
            else
            {
                LogErrorWithTelemetry(GetLog(), "CommandRunnerShouldReportPropertyToIotHubCallback: out of memory allocating %u bytes", payloadSizeBytes);
                reportProperty = false;
            }
        }

        if (payloadSizeBytes > COMMANDRUNNER_MAX_PAYLOAD)
        {
            LogErrorWithTelemetry(GetLog(), "CommandRunner: payload size for CommandStatus is %d bytes, larger than maximum %u bytes, cannot report",
                payloadSizeBytes, COMMANDRUNNER_MAX_PAYLOAD);
            reportProperty = false;
        }
    }

    return reportProperty;
}

void CommandRunnerReportedStateCallback(int statusCode, void* userContextCallback)
{
    OsConfigLogInfo(GetLog(), "CommandRunner: ReportedStateCallback called with status code %u", statusCode);
    UNUSED(userContextCallback);
}

static IOTHUB_CLIENT_RESULT CommandRunnerReportPropertyToIotHub(const char* propertyName, bool mustReport)
{
    return ReportPropertyToIotHub(COMMANDRUNNER_COMPONENT_NAME, propertyName, CommandRunnerShouldReportPropertyToIotHubCallback, mustReport);
}

static bool CheckCommandRunnerDesiredPayload(const JSON_Value* propertyValue, bool* isActionRefreshCommandStatus)
{
    bool result = true;
    char* serializedValue = NULL;
    int serializedValueSize = 0;
    JSON_Object* jsonObject = NULL;
    int desiredAction = -1;
    const char* commandArguments = NULL;
    const char* commandId = NULL;

    LogAssert(GetLog(), NULL != isActionRefreshCommandStatus);

    if (NULL == propertyValue)
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandArguments update attempted without a property value");
        result = false;
    }

    if (result && (NULL == (serializedValue = json_serialize_to_string(propertyValue))))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: json_serialize_to_string for CommandArguments payload failed");
        result = false;
    }

    if (result && (COMMANDRUNNER_MAX_PAYLOAD < (serializedValueSize = strlen(serializedValue))))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandArguments payload size of %u bytes over maximum %u bytes", serializedValueSize, COMMANDRUNNER_MAX_PAYLOAD);
        result = false;
    }

    if (result && (NULL == (serializedValue = json_serialize_to_string(propertyValue))))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: json_serialize_to_string for CommandArguments payload failed");
        result = false;
    }

    if (serializedValue)
    {
        json_free_serialized_string(serializedValue);
    }
    
    if (result && (JSONObject != json_value_get_type(propertyValue)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: invalid type for CommandArguments, not object");
        result = false;
    }

    if (result && (NULL == (jsonObject = json_value_get_object(propertyValue))))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: json_value_get_object for CommandArguments failed");
        result = false;
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, COMMANDRUNNER_ACTION, JSONNumber)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandArguments missing required %s as a number", COMMANDRUNNER_ACTION);
        result = false;
    }

    if (result)
    {
        desiredAction = json_object_get_number(jsonObject, COMMANDRUNNER_ACTION);
        if ((desiredAction < ActionNone) || (desiredAction > ActionRefreshCommandStatus))
        {
            LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandArguments update with unsupported %s value (%d)", COMMANDRUNNER_ACTION, desiredAction);
            result = false;
        }
        else if (NULL != isActionRefreshCommandStatus)
        {
            *isActionRefreshCommandStatus = (ActionRefreshCommandStatus == desiredAction) ? true : false;
        }
    }

    if (ActionRunCommand == desiredAction)
    {
        if (result && (0 == json_object_has_value_of_type(jsonObject, COMMANDRUNNER_ARGUMENTS, JSONString)))
        {
            LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandArguments missing required %s as a string", COMMANDRUNNER_ARGUMENTS);
            result = false;
        }

        if (result && (NULL == (commandArguments = json_object_get_string(jsonObject, COMMANDRUNNER_ARGUMENTS))))
        {
            LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandArguments, json_object_get_string for %s failed", COMMANDRUNNER_ARGUMENTS);
            result = false;
        }
    }

    if (result && (0 == json_object_has_value_of_type(jsonObject, COMMANDRUNNER_COMMAND_ID, JSONString)))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandArguments missing required %s as a string", COMMANDRUNNER_COMMAND_ID);
        result = false;
    }

    if (result && (NULL == (commandId = json_object_get_string(jsonObject, COMMANDRUNNER_COMMAND_ID))))
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: CommandArguments, json_object_get_string for %s failed", COMMANDRUNNER_COMMAND_ID);
        result = false;
    }

    TraceLoggingWrite(g_providerHandle, "RunCommand", 
        TraceLoggingInt32((int32_t)desiredAction, "Action"), 
        TraceLoggingString(commandId, "CommandId"));

    return result;
}

IOTHUB_CLIENT_RESULT CommandRunnerProcessPropertyUpdateFromIotHub(const char* propertyName, const JSON_Value* propertyValue, int version)
{
    IOTHUB_CLIENT_RESULT result = IOTHUB_CLIENT_OK;
    bool isActionRefreshCommandStatus = false;

    LogAssert(GetLog(), NULL != propertyName);
    LogAssert(GetLog(), NULL != propertyValue);

    if (0 == strcmp(propertyName, COMMANDRUNNER_COMMAND_ARGUMENTS))
    {
        if (CheckCommandRunnerDesiredPayload(propertyValue, &isActionRefreshCommandStatus))
        {
            if (IOTHUB_CLIENT_OK == (result = UpdatePropertyFromIotHub(COMMANDRUNNER_COMPONENT_NAME, propertyName, propertyValue, version)))
            {
                if (isActionRefreshCommandStatus)
                {
                    OsConfigLogInfo(GetLog(), "CommandRunner: RefreshCommandStatus");
                    result = CommandRunnerReportPropertyToIotHub(COMMANDRUNNER_COMMAND_STATUS, true);
                }
            }
        }
        else
        {
            LogErrorWithTelemetry(GetLog(), "CommandRunner: %s update received with invalid desired payload, not accepted", propertyName);
            result = IOTHUB_CLIENT_ERROR;
        }
    }
    else if (0 == strcmp(propertyName, COMMANDRUNNER_COMMAND_STATUS))
    {
        OsConfigLogInfo(GetLog(), "CommandRunner: read-only CommandStatus property update requested, nothing to do");
    }
    else
    {
        LogErrorWithTelemetry(GetLog(), "CommandRunner: property update received for an unsupported property %s, nothing to do)", propertyName);
        result = IOTHUB_CLIENT_ERROR;
    }

    return result;
}

void CommandRunnerInitialize(void)
{
    OsConfigLogInfo(GetLog(), "CommandRunner PnP component initialized");
}

void CommandRunnerDoWork(void)
{
    // Invoked every DOWORK_INTERVAL with DOWORK_SLEEP delay (fine tune via these macros):
    CommandRunnerReportPropertyToIotHub(COMMANDRUNNER_COMMAND_STATUS, false);
}

void CommandRunnerDestroy(void)
{
    FREE_MEMORY(g_prevCommandStatus);
    OsConfigLogInfo(GetLog(), "CommandRunner PnP component terminated");
}