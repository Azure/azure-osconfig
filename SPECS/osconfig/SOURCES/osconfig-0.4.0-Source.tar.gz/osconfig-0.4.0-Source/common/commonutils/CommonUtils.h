// Copyright (c) Microsoft. All rights reserved.
#ifndef COMMON_H
#define COMMON_H

// Uncomment next line to enable logging of system commands and payload values for debugging purposes
//#define LOG_VALUE_PAYLOAD 1

#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))

#define UNUSED(x) (void)(x)

// Linefeed (LF) ASCII character
#ifndef EOL
#define EOL 10
#endif

#ifdef __cplusplus
extern "C"
{
#endif

char* LoadStringFromFile(const char* fileName);

typedef int(*CommandCallback)(void);

int ExecuteCommand(const char* command, bool replaceEol, unsigned int maxTextResultBytes, unsigned int timeoutSeconds, char** textResult, CommandCallback callback, void* log);

#ifdef __cplusplus
}
#endif

#endif // COMMON_H