// Copyright (c) Microsoft. All rights reserved.
#ifndef LOGGING_H
#define LOGGING_H

#include <string.h>
#include <syslog.h>

// Maximum log size (131072 is 128KB aka 1024 * 128), increase or decrease as needed
#define MAX_LOG_SIZE 131072

#define TIME_FORMAT_STRING_LENGTH 20

#ifndef ARRAY_SIZE
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))
#endif

typedef void* OSCONFIG_LOG_HANDLE;

#ifdef __cplusplus
extern "C"
{
#endif

OSCONFIG_LOG_HANDLE OpenLog(const char* logFileName, const char* bakLogFileName, const char* sysLogName);
void CloseLog(OSCONFIG_LOG_HANDLE* log);

FILE* GetLogFile(OSCONFIG_LOG_HANDLE log);
char* GetFormattedTime();
void TrimLog(OSCONFIG_LOG_HANDLE log);
bool IsDaemon(OSCONFIG_LOG_HANDLE log);

#define __SHORT_FILE__ (strrchr(__FILE__, '/') ? strrchr(__FILE__, '/') + 1 : __FILE__)
#define __LOG__(log, format, loglevel, ...) printf("[%s] [%s:%d]%s" format "\n", GetFormattedTime(), __SHORT_FILE__, __LINE__, loglevel, ## __VA_ARGS__)
#define __LOG_TO_FILE__(log, format, loglevel, ...) {\
    TrimLog(log);\
    fprintf(GetLogFile(log), "[%s] [%s:%d]%s" format "\n", GetFormattedTime(), __SHORT_FILE__, __LINE__, loglevel, ## __VA_ARGS__);\
}\

#define __INFO__ " "
#define __ERROR__ " [ERROR] "

#define OSCONFIG_LOG_INFO(log, format, ...) __LOG__(log, format, __INFO__, ## __VA_ARGS__)
#define OSCONFIG_LOG_ERROR(log, format, ...) __LOG__(log, format, __ERROR__, ## __VA_ARGS__)
#define OSCONFIG_FILE_LOG_INFO(log, format, ...) __LOG_TO_FILE__(log, format, __INFO__, ## __VA_ARGS__)
#define OSCONFIG_FILE_LOG_ERROR(log, format, ...) __LOG_TO_FILE__(log, format, __ERROR__, ## __VA_ARGS__)

#define OsConfigLogInfo(log, FORMAT, ...) {\
    if (NULL != GetLogFile(log)) {\
        OSCONFIG_FILE_LOG_INFO(log, FORMAT, ##__VA_ARGS__);\
        fflush(GetLogFile(log));\
    }\
    if (IsDaemon(log)) {\
        syslog(LOG_INFO, FORMAT, ##__VA_ARGS__);\
    }\
    OSCONFIG_LOG_INFO(log, FORMAT, ##__VA_ARGS__);\
}\

#define OsConfigLogError(log, FORMAT, ...) {\
    if (NULL != GetLogFile(log)) {\
        OSCONFIG_FILE_LOG_ERROR(log, FORMAT, ##__VA_ARGS__);\
        fflush(GetLogFile(log));\
    }\
    if (IsDaemon(log)) {\
        syslog(LOG_ERR, FORMAT, ##__VA_ARGS__);\
    }\
    OSCONFIG_LOG_ERROR(log, FORMAT, ##__VA_ARGS__);\
}\

#define LogAssert(log, CONDITION) {\
    if (!(CONDITION)) {\
        OsConfigLogError(log, "Assert in %s", __func__);\
        assert(CONDITION);\
    }\
}\

#ifdef __cplusplus
}
#endif

#endif // LOGGING_H
