#include <fstream>
#include <iostream>
#include <gtest/gtest.h>
#include <CommonUtils.h>

using namespace std; 

static void SignalDoWork(int signal)
{
    UNUSED(signal);
}

class CommonUtilsTest : public ::testing::Test 
{
    protected:
        const char* m_path = "~test.test";
        const char* m_data = "`-=~!@#$%^&*()_+,./<>?'[]\{}| qwertyuiopasdfghjklzxcvbnm 1234567890 QWERTYUIOPASDFGHJKLZXCVBNM";

        bool CreateTestFile(const char* path, const char* data)
        {
            bool result = false;

            if (nullptr != path)
            {
                ofstream ofs(path);
                if (nullptr != data)
                {
                    ofs << data;
                    result = true;
                }
                ofs.close();
            }

            return result;
        }

        bool Cleanup(const char* path)
        {
            if (nullptr != path)
            {
                if (remove(path))
                {
                    printf("CommonUtilsTest::Cleanup: cannot remove test file %s\n", path);
                    return false;
                }
            }
            
            return true;
        }
};

TEST_F(CommonUtilsTest, InvalidArgument)
{
    EXPECT_STREQ(nullptr, LoadStringFromFile(nullptr));
}

TEST_F(CommonUtilsTest, LoadStringFromFile)
{
    EXPECT_TRUE(CreateTestFile(m_path, m_data));
    EXPECT_STREQ(m_data, LoadStringFromFile(m_path));
    EXPECT_TRUE(Cleanup(m_path));
}

TEST_F(CommonUtilsTest, ExecuteCommandWithTextResult)
{
    char* textResult = NULL;

    EXPECT_EQ(0, ExecuteCommand("echo test123", false, 0, 0, &textResult, NULL, NULL));
    // Echo appends an end of line character:
    EXPECT_STREQ("test123\n", textResult);

    if (NULL != textResult)
    {
        free(textResult);
    }
}

TEST_F(CommonUtilsTest, ExecuteCommandWithTextResultAndTimeout)
{
    char* textResult = NULL;

    signal(SIGUSR1, SignalDoWork);

    EXPECT_EQ(0, ExecuteCommand("echo test123", false, 0, 10, &textResult, NULL, NULL));
    // Echo appends an end of line character:
    EXPECT_STREQ("test123\n", textResult);

    if (NULL != textResult)
    {
        free(textResult);
    }
}

TEST_F(CommonUtilsTest, ExecuteCommandWithTextResultWithEolMapping)
{
    char* textResult = NULL;

    EXPECT_EQ(0, ExecuteCommand("echo test123", true, 0, 0, &textResult, NULL, NULL));
    // Echo appends an end of line character that's replaced with space:
    EXPECT_STREQ("test123 ", textResult);

    if (NULL != textResult)
    {
        free(textResult);
    }
}

TEST_F(CommonUtilsTest, ExecuteCommandWithTextResultAndTruncation)
{
    char* textResult = NULL;

    EXPECT_EQ(0, ExecuteCommand("echo test123", false, 5, 0, &textResult, NULL, NULL));
    // Only first 5 characters including a null terminator are returned:
    EXPECT_STREQ("test", textResult);

    if (NULL != textResult)
    {
        free(textResult);
    }
}

TEST_F(CommonUtilsTest, ExecuteCommandWithTextResultAndTruncationOfOne)
{
    char* textResult = NULL;

    EXPECT_EQ(0, ExecuteCommand("echo test123", false, 1, 0, &textResult, NULL, NULL));
    // Only the null terminator is returned, meaning empty string:
    EXPECT_STREQ("", textResult);

    if (NULL != textResult)
    {
        free(textResult);
    }
}

TEST_F(CommonUtilsTest, ExecuteCommandWithTextResultAndTruncationOfEol)
{
    char* textResult = NULL;

    EXPECT_EQ(0, ExecuteCommand("echo test123", false, 8, 0, &textResult, NULL, NULL)); 
    // The EOL appended by echo is truncated from the result (replaced with the null terminator in this case):
    EXPECT_STREQ("test123", textResult);

    if (NULL != textResult)
    {
        free(textResult);
    }
}

TEST_F(CommonUtilsTest, ExecuteCommandWithSpecialCharactersInTextResult)
{
    char* textResult = NULL;

    char specialCharacters[34] = {0};
    specialCharacters[0] = '\\'; 
    for (int i = 1; i < 32; i++)
    {
        specialCharacters[i] = (char)i;
    }
    specialCharacters[32] = 0x7f;
    specialCharacters[33] = 0;
    
    char command[50] = {0};
    sprintf(command, "echo \"%s\"", &specialCharacters[0]);

    // All special characters must be replaced with spaces:
    int expectedResultSize = sizeof(specialCharacters);
    char expectedResult[expectedResultSize + 1] = {0};
    for (int i = 0; i < expectedResultSize; i++)
    {
        expectedResult[i] = ' ';
    }

    EXPECT_EQ(0, ExecuteCommand(command, true, strlen(command), 0, &textResult, NULL, NULL));
    EXPECT_STREQ(expectedResult, textResult);

    if (NULL != textResult)
    {
        free(textResult);
        textResult = NULL;
    }
}

TEST_F(CommonUtilsTest, ExecuteCommandWithoutTextResult)
{
    EXPECT_EQ(0, ExecuteCommand("echo test456", false, 0, 0, NULL, NULL, NULL));
}

TEST_F(CommonUtilsTest, ExecuteCommandWithRedirectorCharacter)
{
    char* textResult = NULL;
    EXPECT_EQ(0, ExecuteCommand("echo test789 > testResultFile", false, 0, 0, &textResult, NULL, NULL));
    EXPECT_EQ(NULL, textResult);
}

TEST_F(CommonUtilsTest, ExecuteCommandWithNullArgument)
{
    char* textResult = NULL;
    EXPECT_EQ(-1, ExecuteCommand(NULL, false, 0, 0, &textResult, NULL, NULL));
    EXPECT_EQ(NULL, textResult);

    EXPECT_EQ(-1, ExecuteCommand(NULL, false, 0, 0, NULL, NULL, NULL));
}

TEST_F(CommonUtilsTest, ExecuteCommandThatTimesOut)
{
    char* textResult = NULL;

    signal(SIGUSR1, SignalDoWork);

    EXPECT_EQ(ETIME, ExecuteCommand("sleep 10", false, 0, 1, &textResult, NULL, NULL));

    if (NULL != textResult)
    {
        free(textResult);
    }
}

static int numberOfTimes = 0;

static int TestCommandCallback()
{
    numberOfTimes += 1;
    return (3 == numberOfTimes) ? 1 : 0;
}

TEST_F(CommonUtilsTest, CancelCommand)
{
    char* textResult = NULL;

    signal(SIGUSR1, SignalDoWork);

    EXPECT_EQ(ECANCELED, ExecuteCommand("sleep 20", false, 0, 120, &textResult, TestCommandCallback, NULL));

    if (NULL != textResult)
    {
        free(textResult);
    }
}
