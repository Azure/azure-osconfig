#include <gmock/gmock.h>
#include <gtest/gtest.h>

#include <Settings.h>
#include <Mmi.h>
#include <fstream>
#include <iostream>
#include <cstring>
using namespace std; 


TEST (SettingsTests, DH)
{ 
    static const char g_testFile[] = "test.toml";
    const char g_testTomlData[] = "Permission = \"None\"";

    ofstream ofs_toml(g_testFile); 
    if (nullptr != g_testTomlData)
    {
        ofs_toml << g_testTomlData;
    }
    ofs_toml.close();

    Settings settingsTest;

    bool configurationChanged = false; 
    ASSERT_EQ(MMI_OK, settingsTest.SetDeviceHealthTelemetryConfiguration("2", g_testFile, configurationChanged)); 

    configurationChanged = false; 
    settingsTest.SetDeviceHealthTelemetryConfiguration("2", g_testFile, configurationChanged); 
    ASSERT_EQ(false, configurationChanged); 

    ASSERT_NE(MMI_OK, settingsTest.SetDeviceHealthTelemetryConfiguration("7", g_testFile, configurationChanged));
    ASSERT_NE(MMI_OK, settingsTest.SetDeviceHealthTelemetryConfiguration("", g_testFile, configurationChanged));

    if (!(remove(g_testFile) == 0))
    {
        std::cout << "Err: can't remove test toml file."; 
    }
}

TEST(SettingsTests, DO)
{
    static const char g_testFile[] = "test.json";
    const char g_testJsonData[] = "{\"DOPercentageDownloadThrottle\":0, \"DOCacheHostSource\": 1, \"DOCacheHost\":\"test\", \"DOCacheHostFallback\":2020}";
    ofstream ofs_json(g_testFile); 

    if (nullptr != g_testJsonData)
    {
        ofs_json << g_testJsonData;
    }
    ofs_json.close();

    bool configurationChanged = false;
    Settings settingsTest; 
    Settings::DeliveryOptimization DO{30, 2, "testing", 2020};
    ASSERT_EQ(MMI_OK, settingsTest.SetDeliveryOptimizationPolicies(DO, g_testFile, configurationChanged)); 

    configurationChanged = false; 
    settingsTest.SetDeliveryOptimizationPolicies(DO, g_testFile, configurationChanged); 
    ASSERT_EQ(false, configurationChanged);
    
    Settings::DeliveryOptimization DO_empty{};
    ASSERT_EQ(MMI_OK, settingsTest.SetDeliveryOptimizationPolicies(DO_empty, g_testFile, configurationChanged)); 

    if (!(remove(g_testFile) == 0))
    {
        std::cout << "Err: can't remove test json file."; 
    }
}
