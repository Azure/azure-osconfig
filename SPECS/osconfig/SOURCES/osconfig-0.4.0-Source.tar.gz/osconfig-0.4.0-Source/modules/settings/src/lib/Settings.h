#include <string>

class Settings
{
    public:
        struct DeliveryOptimization 
        {
            int percentageDownloadThrottle;
            int cacheHostSource;
            std::string cacheHost;
            int cacheHostFallback;
        };
        Settings(unsigned int maxSizeInBytes = 0);
        virtual ~Settings() = default;
        int SetDeviceHealthTelemetryConfiguration(std::string payload, const char* fileName, bool &configurationChanged); 
        int SetDeliveryOptimizationPolicies(Settings::DeliveryOptimization deliveryoptimization, const char* fileName, bool &configurationChanged);

    private: 
        bool FileExists(const char* name);
        unsigned int maxPayloadSizeInBytes;
};
