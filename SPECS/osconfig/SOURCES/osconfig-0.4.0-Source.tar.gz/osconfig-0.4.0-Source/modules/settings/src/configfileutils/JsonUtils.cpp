// Copyright (c) Microsoft. All rights reserved.
#include <iostream>
#include <fstream>
#include <sstream>
#include "rapidjson/writer.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/error/en.h"
#include "JsonUtils.h"
#include "ConfigFileUtils.h"
#include "ScopeGuard.h"

bool JsonUtils::SetValueString(const std::string& name, const std::string& value)
{
    if (!DeserializeFromFile())
    {
        return false; 
    }

    if (!(m_jsonDocumentObject.HasMember(name.c_str())))
    {
        rapidjson::Document::AllocatorType& allocator = m_jsonDocumentObject.GetAllocator();
        rapidjson::Value key(name.c_str(), allocator);
        rapidjson::Value valueString(value.c_str(), allocator);
        m_jsonDocumentObject.AddMember(key, valueString, allocator);
    }
    else
    {
        rapidjson::Value& valueToSet = m_jsonDocumentObject[name.c_str()];
        valueToSet.SetString(value.c_str(), value.length(), m_jsonDocumentObject.GetAllocator());
    }

    return SerializeToFile();
}

char* JsonUtils::GetValueString(const std::string& name)
{
    if (!DeserializeFromFile())
    {
        return nullptr; 
    }

    if (!(m_jsonDocumentObject.HasMember(name.c_str())))
    {
        printf("JsonUtils::GetValueString: %s does not exist\n", name.c_str());
        return nullptr;
    }

    std::string valueString = m_jsonDocumentObject[name.c_str()].GetString();
    char* value = new(std::nothrow) char[valueString.length() + 1];
    if (value == nullptr)
    {
        printf("JsonUtils::GetValueString: Allocation failed, issue with memory.\n");
        return nullptr; 
    }
    strcpy(value, valueString.c_str()); 
    return value;  
}

bool JsonUtils::SetValueInteger(const std::string& name, const int value)
{
    if (!DeserializeFromFile())
    {
        return false; 
    }

    if (!(m_jsonDocumentObject.HasMember(name.c_str())))
    {
        rapidjson::Document::AllocatorType& allocator = m_jsonDocumentObject.GetAllocator();
        rapidjson::Value key(name.c_str(), allocator);
        m_jsonDocumentObject.AddMember(key, value, allocator);
    }
    else
    {
        m_jsonDocumentObject[name.c_str()] = value;
    }

    return SerializeToFile();
}

int JsonUtils::GetValueInteger(const std::string& name)
{
    if (!DeserializeFromFile())
    {
        return READ_CONFIG_FAILURE;
    }

    if (!(m_jsonDocumentObject.HasMember(name.c_str())))
    {
        printf("JsonUtils::GetValueInteger: %s does not exist\n", name.c_str());
        return READ_CONFIG_FAILURE;
    }
    
    return m_jsonDocumentObject[name.c_str()].GetInt();
}

bool JsonUtils::SerializeToFile()
{
    rapidjson::StringBuffer buffer;
    rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);

    m_jsonDocumentObject.Accept(writer);
    const std::string& buffContents = buffer.GetString();
    std::ofstream ofs(m_path);
    if (ofs.fail())
    {
        printf("JsonUtils::SerializeToFile: iostream operation failed\n");
        return false;
    }

    ScopeGuard sg {[&]() 
    { 
        ofs.close(); 
    }};

    ofs << buffContents;
    return true;    
}

bool JsonUtils::DeserializeFromFile()
{
    std::stringstream buffer;
    std::ifstream ifs(m_path);
    if (ifs.fail())
    {
        printf("JsonUtils::DeserializeFromFile: iostream operation failed\n");
        return false; 
    }

    ScopeGuard sg {[&]() 
    { 
        ifs.close(); 
    }};

    buffer << ifs.rdbuf();

    const std::string& buffContents = buffer.str();
    std::string validJson(buffContents);
    m_jsonDocumentObject.Parse(validJson.c_str());

    if (m_jsonDocumentObject.HasParseError())
    {
        printf("JsonUtils::DeserializeFromFile: Parse operation failed with error: %s (offset: %u)\n",
            GetParseError_En(m_jsonDocumentObject.GetParseError()),
            (unsigned)m_jsonDocumentObject.GetErrorOffset());
        return false; 
    }

    return true;
}