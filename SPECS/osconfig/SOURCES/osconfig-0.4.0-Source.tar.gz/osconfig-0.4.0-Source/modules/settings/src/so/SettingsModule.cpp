// Copyright (c) Microsoft. All rights reserved.
#include <cstring>
#include <errno.h>
#include <memory>
#include <CommonUtils.h>
#include <Mmi.h>
#include <Settings.h>
#include "rapidjson/document.h"
#include <iostream>

const std::string SETTINGS = "Settings";
const std::string DEVICEHEALTHTELEMETRY = "DeviceHealthTelemetryConfiguration";
const std::string DELIVERYOPTIMIZATION = "DeliveryOptimizationPolicies"; 
const std::string PERCENTAGEDOWNLOADTHROTTLE = "PercentageDownloadThrottle";
const std::string CACHEHOSTSOURCE = "CacheHostSource";
const std::string CACHEHOST = "CacheHost";
const std::string CACHEHOSTFALLBACK = "CacheHostFallback";

using namespace rapidjson;
std::unique_ptr<Settings> settings; 

unsigned int maxPayloadSizeBytes = 0;

int MmiGetInfo(
    const char* clientName,
    MMI_JSON_STRING* payload,
    int* payloadSizeBytes)
{
    UNUSED(clientName);

    if (nullptr == payload || nullptr == payloadSizeBytes)
    {
        return EINVAL;
    }

    constexpr const char ret[] = R""""({ "Name": "Settings", "Description": "Provides functionality to configure other settings on the device", "Manufacturer": "Microsoft", "VersionMajor": 0, "VersionMinor": 1, "VersionInfo": "Initial Version", "Components": ["Settings"], "Lifetime": 0, "UserAccount": 0})"""";

    std::size_t len = sizeof(ret) - 1;

    *payloadSizeBytes = len;
    *payload = new char[len];
    if (!(*payload))
    {
        return ENOMEM;
    }
    std::memcpy(*payload, ret, len);

    return MMI_OK;
}

MMI_HANDLE MmiOpen(
    const char* clientName,
    const unsigned int maxPayloadSize)
{
    if (nullptr == clientName)
    {
        return nullptr; 
    }
    maxPayloadSizeBytes = maxPayloadSize;
    settings.reset(new Settings(maxPayloadSizeBytes));
    return reinterpret_cast<MMI_HANDLE>(settings.get());
}

void MmiClose(MMI_HANDLE clientSession)
{
    if (clientSession == reinterpret_cast<MMI_HANDLE>(settings.get()))
    {
        settings.reset();
    }
}

int MmiSet(
    MMI_HANDLE clientSession,
    const char* componentName,
    const char* objectName,
    const MMI_JSON_STRING payload,
    const int payloadSizeBytes)
{
    int result = EPERM;

    if (nullptr == clientSession)
    {
        return result;
    }

    if (SETTINGS != componentName)
    {
        return result;
    }

    if ((maxPayloadSizeBytes > 0) && (payloadSizeBytes > static_cast<int> (maxPayloadSizeBytes)))
    {
        result = E2BIG;
        return result;
    }

    std::string str(objectName);
    Document document; 
    document.Parse(payload); 

    if (str == DEVICEHEALTHTELEMETRY)
    {
        bool configurationChanged = false;
        static const char g_healthTelemetryConfigFile[] = "/etc/azure-device-health-services/config.toml";
        std::string DHStr = std::string(payload, payloadSizeBytes);

        result = settings->SetDeviceHealthTelemetryConfiguration(DHStr, g_healthTelemetryConfigFile, configurationChanged);

        if (result == MMI_OK)
        {
            if (configurationChanged && (0 == (result = ExecuteCommand("systemctl kill -s SIGHUP azure-device-telemetryd.service", false, 0, 0, nullptr, nullptr, nullptr))))
            {
                result = ExecuteCommand("systemctl kill -s SIGHUP azure-device-errorreporting-uploaderd.service", false, 0, 0, nullptr, nullptr, nullptr);
            } 
        }
    }
    else if (str == DELIVERYOPTIMIZATION)
    {
        bool configurationChanged = false; 
        static const char g_doConfigFile[] = "/etc/deliveryoptimization-agent/admin-config.json";
        Settings::DeliveryOptimization deliveryOptimization; 
        if (document.HasMember(PERCENTAGEDOWNLOADTHROTTLE.c_str()))
        {
            deliveryOptimization.percentageDownloadThrottle = document[PERCENTAGEDOWNLOADTHROTTLE.c_str()].GetInt(); 
        }

        if (document.HasMember(CACHEHOSTSOURCE.c_str()))
        {
            deliveryOptimization.cacheHostSource = document[CACHEHOSTSOURCE.c_str()].GetInt();
        }

        if (document.HasMember(CACHEHOST.c_str()))
        {
            deliveryOptimization.cacheHost = document[CACHEHOST.c_str()].GetString(); 
        }

        if (document.HasMember(CACHEHOSTFALLBACK.c_str()))
        {
            deliveryOptimization.cacheHostFallback = document[CACHEHOSTFALLBACK.c_str()].GetInt(); 
        }

        result = settings->SetDeliveryOptimizationPolicies(deliveryOptimization, g_doConfigFile, configurationChanged);

        if ((result == MMI_OK) && configurationChanged)
        {
            result = ExecuteCommand("systemctl kill -s SIGHUP deliveryoptimization-agent", false, 0, 0, nullptr, nullptr, nullptr);
        }
    }

    return result;
}

int MmiGet(
    MMI_HANDLE clientSession,
    const char* componentName,
    const char* objectName,
    MMI_JSON_STRING* payload,
    int* payloadSizeBytes)
{
    UNUSED(clientSession);
    UNUSED(componentName);
    UNUSED(objectName);
    UNUSED(payload);
    UNUSED(payloadSizeBytes);

    return ENODEV;
}

void MmiFree(MMI_JSON_STRING payload)
{
    if (!payload)
    {
        return; 
    }
    delete[] payload;
}