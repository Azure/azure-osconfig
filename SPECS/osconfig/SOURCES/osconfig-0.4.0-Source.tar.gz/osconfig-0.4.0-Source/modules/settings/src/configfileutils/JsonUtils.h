// Copyright (c) Microsoft. All rights reserved.
#pragma once

#include "rapidjson/document.h"
#include "BaseUtils.h"

class JsonUtils : public BaseUtils
{
public:
    JsonUtils(const char* path) : m_path(path) {};
    ~JsonUtils() {};

    bool SetValueString(const std::string& name, const std::string& value) override;
    char* GetValueString(const std::string& name) override;
    bool SetValueInteger(const std::string& name, const int value) override;
    int GetValueInteger(const std::string& name) override;

private:
    bool SerializeToFile();
    bool DeserializeFromFile();

    const char* m_path;
    rapidjson::Document m_jsonDocumentObject;
};