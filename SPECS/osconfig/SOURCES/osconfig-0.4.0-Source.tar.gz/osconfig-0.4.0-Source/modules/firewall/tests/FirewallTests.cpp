#include <gtest/gtest.h>
#include <memory>
#include <CommonUtils.h>
#include <Firewall.h>
#include <Mmi.h> 
#include <vector>
#include <string>

using namespace std;
class FirewallObjectTest : public FirewallObjectBase
{
public:
    std::vector <std::string> testTableStrings;
    unsigned int runCommandCount = 0;
    int GetFirewallTable(vector<string> &iPTables);
    FirewallObjectTest(unsigned int maxPayloadSizeBytes);
    ~FirewallObjectTest();
};

FirewallObjectTest::FirewallObjectTest(unsigned int maxPayloadSizeBytes)
{
    m_maxPayloadSizeBytes = maxPayloadSizeBytes;
}

FirewallObjectTest::~FirewallObjectTest() {}

int FirewallObjectTest::GetFirewallTable(vector<string> &iPTables)
{ 
    int status = MMI_OK;

    vector<string> tableNames; 
    tableNames.push_back("filter");
    tableNames.push_back("nat");
    tableNames.push_back("raw");
    tableNames.push_back("mangle");
    tableNames.push_back("security");

    for (std::vector<string>::size_type k = 0; k < tableNames.size(); k++)
    {
        string specificOutput = "";
        char* char_specificOutput = nullptr;        
        if (runCommandCount < (unsigned int)testTableStrings.size())
        {
            string currentTable = testTableStrings[runCommandCount++];
            if (!currentTable.empty())
            {
                size_t tableSize = (currentTable.length() + 1) * sizeof(currentTable[0]);
                char_specificOutput = new (std::nothrow) char[tableSize];
                if (nullptr == char_specificOutput)
                {
                    status = ENOBUFS;
                }
                else
                {
                    std::fill(char_specificOutput, char_specificOutput + tableSize, 0);
                    std::memcpy(char_specificOutput, currentTable.c_str(), currentTable.length());
                }
            }
            else
            {
                status = ENODATA;
            }
        }

        specificOutput = (nullptr != char_specificOutput) ? string(char_specificOutput) : "";
        iPTables.push_back(specificOutput);
        if (nullptr != char_specificOutput)
        {
            free(char_specificOutput);
        }
    }

    return status;
}

TEST (FirewallTests, GetFirewallTable)
{
    string filterTable =
    R"""(Chain INPUT (policy ACCEPT)
    num  target     prot opt source               destination         
    1    DROP       udp  --  0.0.0.0/0            0.0.0.0/0           
    2    ACCEPT     all  --  192.168.11.230       0.0.0.0/0           
    3    DROP       all  --  0.0.0.0/0            0.0.0.0/0            MAC 00:00:00:00:00:00

    Chain FORWARD (policy ACCEPT)
    num  target     prot opt source               destination         
    1    DROP       all  --  0.0.0.0/0            0.0.0.0/0           

    Chain OUTPUT (policy ACCEPT)
    num  target     prot opt source               destination         
    1    DROP       all  --  0.0.0.0/0            192.168.11.123  )""";

    string natTable =
    R"""(Chain PREROUTING (policy ACCEPT)
    num  target     prot opt source               destination         
    1    DNAT       tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:43 to:12.12.12.12

    Chain INPUT (policy ACCEPT)
    num  target     prot opt source               destination         

    Chain OUTPUT (policy ACCEPT)
    num  target     prot opt source               destination         
    1               all  --  0.0.0.0/0            19.168.21.22        

    Chain POSTROUTING (policy ACCEPT)
    num  target     prot opt source               destination   )""";
        
    string rawTable =
    R"""(Chain PREROUTING (policy ACCEPT)
    num  target     prot opt source               destination         
    1               tcp  --  0.0.0.0/0            0.0.0.0/0           

    Chain OUTPUT (policy ACCEPT)
    num  target     prot opt source               destination )""";

    string mangleTable =
    R"""(Chain PREROUTING (policy ACCEPT)
    num  target     prot opt source               destination         

    Chain INPUT (policy ACCEPT)
    num  target     prot opt source               destination         
    1    MARK       tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:51 MARK set 0x3

    Chain FORWARD (policy ACCEPT)
    num  target     prot opt source               destination         

    Chain OUTPUT (policy ACCEPT)
    num  target     prot opt source               destination         
    1    MARK       tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:501 MARK set 0x2

    Chain POSTROUTING (policy ACCEPT)
    num  target     prot opt source               destination )""";

    string securityTable =
    R"""(Chain INPUT (policy ACCEPT)
    num  target     prot opt source               destination         
    1    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           

    Chain FORWARD (policy ACCEPT)
    num  target     prot opt source               destination         

    Chain OUTPUT (policy ACCEPT)
    num  target     prot opt source               destination )""";

  
    vector<string> testVector;
    unsigned int maxPayloadSizeBytes = 0;
    FirewallObjectTest testModule(maxPayloadSizeBytes);

    testModule.testTableStrings = {filterTable, natTable, rawTable, mangleTable, securityTable};
  
    testModule.GetFirewallTable(testVector); 
    int vectorSize = testVector.size();
    EXPECT_EQ(5, vectorSize);
    filterTable = R"""()""";
    mangleTable = R"""(tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:501 MARK set 0x2 0.0.0.0/0            LOG flags 0 level 4 
      (policy ACCEPT))""";
    securityTable = R"""()""";
    testModule.GetFirewallTable(testVector);
    EXPECT_EQ(5, vectorSize);
}

TEST (CreateSettingString, FullSetOfRules)
{ 
    unsigned int maxPayloadSizeBytes = 0;
    FirewallObjectTest testModule(maxPayloadSizeBytes);
    string sampleIptable =
    "Chain INPUT (policy ACCEPT) \n\
    num  target     prot opt source               destination \n\
    1    DROP       all  --  11.11.11.11          0.0.0.0/0 \n\
    2    LOG        all  --  0.0.0.0/0            0.0.0.0/0            LOG flags 0 level 4 \n\
    3    LOG        all  --  12.12.12.12          0.0.0.0/0            LOG flags 0 level 4 prefix  ** SUSPECT ** \n\
    4    ACCEPT     tcp  --  0.0.0.0/0            10.10.10.10 \n\
    \n\
    Chain FORWARD (policy ACCEPT) \n\
    num  target     prot opt source               destination \n\
    \n\
    Chain OUTPUT (policy ACCEPT) \n\
    num  target     prot opt source               destination \n\
    1    LOG        tcp  --  0.0.0.0/0            0.0.0.0/0            tcp spt:80 LOG flags 0 level 4 \n\
    2    ACCEPT     udp  --  0.0.0.0/0            0.0.0.0/0            udp dpt:1 \n";

    vector<string> output; 
    output = testModule.CreateStringSetting(0, sampleIptable);

    string directions = "filter.INPUT.1=In;filter.INPUT.3=In;filter.INPUT.4=Out;filter.OUTPUT.1=In;filter.OUTPUT.2=Out;";
    string targets = "filter.INPUT=ACCEPT;filter.INPUT.1=DROP;filter.INPUT.2=LOG/flags0level4/;filter.INPUT.3=LOG/flags0level4prefix**SUSPECT**/;filter.INPUT.4=ACCEPT;filter.FORWARD=ACCEPT;filter.OUTPUT=ACCEPT;filter.OUTPUT.1=LOG/flags0level4/;filter.OUTPUT.2=ACCEPT;";
    string protocols = "filter.INPUT.1=all;filter.INPUT.2=all;filter.INPUT.3=all;filter.INPUT.4=tcp;filter.OUTPUT.1=tcp;filter.OUTPUT.2=udp;";
    string ipaddresses = "filter.INPUT.1=11.11.11.11;filter.INPUT.3=12.12.12.12;filter.INPUT.4=10.10.10.10;";
    string ports = "filter.OUTPUT.1=80;filter.OUTPUT.2=1;";

    EXPECT_EQ(directions, output[0]);
    EXPECT_EQ(targets, output[1]);
    EXPECT_EQ(protocols, output[2]);
    EXPECT_EQ(ipaddresses, output[3]);
    EXPECT_EQ(ports, output[4]);
}

TEST(CreateSettingString, DefaultRules)
{
    unsigned int maxPayloadSizeBytes = 0;
    FirewallObjectTest testModule(maxPayloadSizeBytes);
    string sampleIptable =
    "Chain INPUT (policy ACCEPT) \n\
    num  target     prot opt source               destination \n\
    \n\
    Chain FORWARD (policy ACCEPT) \n\
    num  target     prot opt source               destination \n\
    \n\
    Chain OUTPUT (policy ACCEPT) \n\
    num  target     prot opt source               destination \n";

    vector<string> output;
    output = testModule.CreateStringSetting(1, sampleIptable); 

    string directions = "";
    string targets = "nat.INPUT=ACCEPT;nat.FORWARD=ACCEPT;nat.OUTPUT=ACCEPT;";
    string protocols = "";
    string ipaddresses = "";
    string ports = ""; 

    EXPECT_EQ(directions, output[0]);
    EXPECT_EQ(targets, output[1]);
    EXPECT_EQ(protocols, output[2]);
    EXPECT_EQ(ipaddresses, output[3]);
    EXPECT_EQ(ports, output[4]);

    vector<string> allTargets; 
    allTargets.push_back("filter.INPUT=ACCEPT;filter.FORWARD=ACCEPT;filter.OUTPUT=ACCEPT;");
    allTargets.push_back("nat.INPUT=ACCEPT;nat.FORWARD=ACCEPT;nat.OUTPUT=ACCEPT;");
    allTargets.push_back("raw.INPUT=ACCEPT;raw.FORWARD=ACCEPT;raw.OUTPUT=ACCEPT;");
    allTargets.push_back("mangle.INPUT=ACCEPT;mangle.FORWARD=ACCEPT;mangle.OUTPUT=ACCEPT;");
    allTargets.push_back("security.INPUT=ACCEPT;security.FORWARD=ACCEPT;security.OUTPUT=ACCEPT;");

    vector<vector<string>> allIptables; 
    for (int k = 0; k < 5; k++) 
    {
        allIptables.push_back(testModule.CreateStringSetting(k, sampleIptable));
        EXPECT_EQ(allIptables[k][1], allTargets[k]); 
    }
}
TEST(CreateSettingString, EdgeCases)
{
    unsigned int maxPayloadSizeBytes = 0;
    FirewallObjectTest testModule(maxPayloadSizeBytes);
    string sampleIptable = 
    R"""( Chain INPUT (policy ACCEPT)
    num  target     prot opt source               destination         
    1    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp spt:84 dpt:96
    2    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp spt:122
    3    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:999
    4    ACCEPT     tcp  --  0.0.0.0/0            10.10.10.10          tcp spt:22
    5    ACCEPT     tcp  --  10.10.10.10          0.0.0.0/0            tcp dpt:22
    6    ACCEPT     tcp  --  10.10.10.10          0.0.0.0/0            tcp spt:22
    7    ACCEPT     tcp  --  0.0.0.0/0            10.10.10.10          tcp dpt:22
    8    ACCEPT     tcp  --  11.11.11.11          10.10.10.10          tcp spt:44 dpt:22 )""";

    vector<string> output;
    output = testModule.CreateStringSetting(0, sampleIptable);

    string directions = "filter.INPUT.1=Both;filter.INPUT.2=In;filter.INPUT.3=Out;filter.INPUT.4=Both;filter.INPUT.5=Both;filter.INPUT.6=In;filter.INPUT.7=Out;filter.INPUT.8=Both;";
    string targets =  "filter.INPUT=ACCEPT;filter.INPUT.1=ACCEPT;filter.INPUT.2=ACCEPT;filter.INPUT.3=ACCEPT;filter.INPUT.4=ACCEPT;filter.INPUT.5=ACCEPT;filter.INPUT.6=ACCEPT;filter.INPUT.7=ACCEPT;filter.INPUT.8=ACCEPT;";
    string protocols = "filter.INPUT.1=tcp;filter.INPUT.2=tcp;filter.INPUT.3=tcp;filter.INPUT.4=tcp;filter.INPUT.5=tcp;filter.INPUT.6=tcp;filter.INPUT.7=tcp;filter.INPUT.8=tcp;";
    string ipaddresses = "filter.INPUT.4=10.10.10.10;filter.INPUT.5=10.10.10.10;filter.INPUT.6=10.10.10.10;filter.INPUT.7=10.10.10.10;filter.INPUT.8=11.11.11.11,10.10.10.10;";
    string ports = "filter.INPUT.1=84,96;filter.INPUT.2=122;filter.INPUT.3=999;filter.INPUT.4=22;filter.INPUT.5=22;filter.INPUT.6=22;filter.INPUT.7=22;filter.INPUT.8=44,22;";

    EXPECT_EQ(directions, output[0]);
    EXPECT_EQ(targets, output[1]);
    EXPECT_EQ(protocols, output[2]);
    EXPECT_EQ(ipaddresses, output[3]);
    EXPECT_EQ(ports, output[4]);
}

TEST (FirewallTests, CreateFirewallJson)
{
    unsigned int maxPayloadSizeBytes = 0;
    FirewallObjectTest testModule(maxPayloadSizeBytes);
    std::vector<std::string> testTables =
    {
        R"""( Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    DROP       all  --  15.15.15.51          0.0.0.0/0            
        2    DROP       all  --  15.15.15.51          0.0.0.0/0            

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    ACCEPT     all  --  0.0.0.0/0             0.0.0.0/0             ctstate ESTABLISHED
        2    ACCEPT     all  --  0.0.0.0/0             0.0.0.0/0             ctstate ESTABLISHED
        3    ACCEPT     all  --  0.0.0.0/0             0.0.0.0/0             ctstate ESTABLISHED )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain POSTROUTING (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain POSTROUTING (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination  )"""
    };

    std::vector<std::string> testTables2 = 
    {
        R"""( Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:20

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:60
        2    ACCEPT     udp  --  0.0.0.0/0            0.0.0.0/0            udp dpt:33 )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain POSTROUTING (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain POSTROUTING (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination )"""
    };

    // When an IP table string is empty or partial, its info will not be reported
    // Only the first table (filter) will be reported
    std::vector<std::string> testTables3 = 
    {
        R"""( Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    DROP       tcp  --  31.13.92.0/24        12.34.0.0/16          

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    ACCEPT     tcp  --  1.1.1.1/0            0.0.0.0/0            tcp dpt:60
        2    ACCEPT     udp  --  0.0.0.0/0            0.0.0.0/0            udp spt:33 )""",

        R"""()""",

        R"""(  1    ACCEPT     tcp  --  1.1.1.1/0            12.1.2.0/0            tcp dpt:60 )""",

        R"""( Chain OUTPUT  )""",

        R"""(  
        num  target     prot opt source               destination
        num  target     prot opt source               destination )"""        
    };

    std::vector<std::string> testTables4 = 
    {
        R"""( Chain INPUT   )""",

        R"""()""",

        R"""(  1    ACCEPT     tcp  --  1.1.1.1/0            0.0.0.0/0            tcp dpt:60 )""",

        R"""(test string )""",

        R"""(  
        num  target     prot opt source               destination    
        10    ACCEPT     tcp  --  9.1.1.1/0            0.0.0.0/0            tcp dpt:60    
        num  target     prot opt source               destination )"""        
    };
   
    MMI_JSON_STRING jsonString;
    int jsonSizeBytes;
    int status = MMI_OK;
    status = testModule.CreateFirewallJson(testTables, &jsonString, &jsonSizeBytes);
    ASSERT_TRUE(((MMI_OK == status) && (nullptr != jsonString)) || (MMI_OK != status));
    string resultString = string(jsonString, jsonSizeBytes);
    string expectedString = R"""({"Directions":"filter.INPUT.1=In;filter.INPUT.2=In","Targets":"filter.INPUT=ACCEPT;filter.INPUT.1=DROP;filter.INPUT.2=DROP;filter.FORWARD=ACCEPT;filter.OUTPUT=ACCEPT;filter.OUTPUT.1=ACCEPT;filter.OUTPUT.2=ACCEPT;filter.OUTPUT.3=ACCEPT;nat.PREROUTING=ACCEPT;nat.INPUT=ACCEPT;nat.OUTPUT=ACCEPT;nat.POSTROUTING=ACCEPT;raw.PREROUTING=ACCEPT;raw.OUTPUT=ACCEPT;mangle.PREROUTING=ACCEPT;mangle.INPUT=ACCEPT;mangle.FORWARD=ACCEPT;mangle.OUTPUT=ACCEPT;mangle.POSTROUTING=ACCEPT;security.INPUT=ACCEPT;security.FORWARD=ACCEPT;security.OUTPUT=ACCEPT","Protocols":"filter.INPUT.1=all;filter.INPUT.2=all;filter.OUTPUT.1=all;filter.OUTPUT.2=all;filter.OUTPUT.3=all","IpAddresses":"filter.INPUT.1=15.15.15.51;filter.INPUT.2=15.15.15.51","Ports":""})""";
    EXPECT_STREQ(resultString.c_str(), expectedString.c_str());
    delete [] jsonString;
    jsonString = nullptr;
    status = MMI_OK;

    status = testModule.CreateFirewallJson(testTables2, &jsonString, &jsonSizeBytes);
    ASSERT_TRUE(((MMI_OK == status) && (nullptr != jsonString)) || (MMI_OK != status));
    expectedString = R"""({"Directions":"filter.INPUT.1=Out;filter.OUTPUT.1=Out;filter.OUTPUT.2=Out","Targets":"filter.INPUT=ACCEPT;filter.INPUT.1=ACCEPT;filter.FORWARD=ACCEPT;filter.OUTPUT=ACCEPT;filter.OUTPUT.1=ACCEPT;filter.OUTPUT.2=ACCEPT;nat.PREROUTING=ACCEPT;nat.INPUT=ACCEPT;nat.OUTPUT=ACCEPT;nat.POSTROUTING=ACCEPT;raw.PREROUTING=ACCEPT;raw.OUTPUT=ACCEPT;mangle.PREROUTING=ACCEPT;mangle.INPUT=ACCEPT;mangle.FORWARD=ACCEPT;mangle.OUTPUT=ACCEPT;mangle.POSTROUTING=ACCEPT;security.INPUT=ACCEPT;security.FORWARD=ACCEPT;security.OUTPUT=ACCEPT","Protocols":"filter.INPUT.1=tcp;filter.OUTPUT.1=tcp;filter.OUTPUT.2=udp","IpAddresses":"","Ports":"filter.INPUT.1=20;filter.OUTPUT.1=60;filter.OUTPUT.2=33"})""";
    resultString = string(jsonString, jsonSizeBytes);
    EXPECT_STREQ(resultString.c_str(), expectedString.c_str());
    delete [] jsonString;
    jsonString = nullptr;
    status = MMI_OK;

    status = testModule.CreateFirewallJson(testTables3, &jsonString, &jsonSizeBytes);
    ASSERT_TRUE((MMI_OK == status) && (nullptr != jsonString));
    expectedString = R"""({"Directions":"filter.INPUT.1=Both;filter.OUTPUT.1=Both;filter.OUTPUT.2=In","Targets":"filter.INPUT=ACCEPT;filter.INPUT.1=DROP;filter.FORWARD=ACCEPT;filter.OUTPUT=ACCEPT;filter.OUTPUT.1=ACCEPT;filter.OUTPUT.2=ACCEPT","Protocols":"filter.INPUT.1=tcp;filter.OUTPUT.1=tcp;filter.OUTPUT.2=udp","IpAddresses":"filter.INPUT.1=31.13.92.0/24,12.34.0.0/16;filter.OUTPUT.1=1.1.1.1/0","Ports":"filter.OUTPUT.1=60;filter.OUTPUT.2=33"})""";
    resultString = string(jsonString, jsonSizeBytes);
    EXPECT_STREQ(resultString.c_str(), expectedString.c_str());
    delete [] jsonString;
    jsonString = nullptr;

    status = testModule.CreateFirewallJson(testTables4, &jsonString, &jsonSizeBytes);
    ASSERT_TRUE((MMI_OK == status) && (nullptr != jsonString));
    resultString = string(jsonString, jsonSizeBytes);
    expectedString = R"""({"Directions":"","Targets":"","Protocols":"","IpAddresses":"","Ports":""})""";
    EXPECT_STREQ(resultString.c_str(), expectedString.c_str());
    delete [] jsonString;
    jsonString = nullptr;
}

TEST (FirewallTests, MaXPayloadSize)
{
    unsigned int maxPayloadSizeBytes = 4096;
    FirewallObjectTest testModule(maxPayloadSizeBytes);
    std::vector<std::string> testTables =
    {
        R"""( Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:3306
        2    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:3306
        3    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:3306

        Chain FORWARD (policy DROP)
        num  target     prot opt source               destination         
        1    DOCKER-USER  all  --  0.0.0.0/0            0.0.0.0/0           
        2    DOCKER-ISOLATION-STAGE-1  all  --  0.0.0.0/0            0.0.0.0/0           
        3    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0            ctstate RELATED,ESTABLISHED
        4    DOCKER     all  --  0.0.0.0/0            0.0.0.0/0           
        5    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           
        6    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           
        7    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0            ctstate RELATED,ESTABLISHED
        8    DOCKER     all  --  0.0.0.0/0            0.0.0.0/0           
        9    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           
        10   ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           
        11   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        12   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        13   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        14   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        15   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        16   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        17   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        18   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        19   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        20   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        21   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        22   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        23   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        24   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        25   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        26   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        27   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        28   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED
        29   ACCEPT     all  --  192.168.2.0/24       192.168.122.0/24     state NEW,RELATED,ESTABLISHED

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain DOCKER (2 references)
        num  target     prot opt source               destination         

        Chain DOCKER-ISOLATION-STAGE-1 (1 references)
        num  target     prot opt source               destination         
        1    DOCKER-ISOLATION-STAGE-2  all  --  0.0.0.0/0            0.0.0.0/0           
        2    DOCKER-ISOLATION-STAGE-2  all  --  0.0.0.0/0            0.0.0.0/0           
        3    RETURN     all  --  0.0.0.0/0            0.0.0.0/0           

        Chain DOCKER-ISOLATION-STAGE-2 (2 references)
        num  target     prot opt source               destination         
        1    DROP       all  --  0.0.0.0/0            0.0.0.0/0           
        2    DROP       all  --  0.0.0.0/0            0.0.0.0/0           
        3    RETURN     all  --  0.0.0.0/0            0.0.0.0/0           

        Chain DOCKER-USER (1 references)
        num  target     prot opt source               destination         
        1    RETURN     all  --  0.0.0.0/0            0.0.0.0/0  )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         
        1    DOCKER     all  --  0.0.0.0/0            0.0.0.0/0            ADDRTYPE match dst-type LOCAL

        Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    DOCKER     all  --  0.0.0.0/0           !127.0.0.0/8          ADDRTYPE match dst-type LOCAL

        Chain POSTROUTING (policy ACCEPT)
        num  target     prot opt source               destination         
        1    MASQUERADE  all  --  172.17.0.0/16        0.0.0.0/0           
        2    MASQUERADE  all  --  172.18.0.0/16        0.0.0.0/0           

        Chain DOCKER (2 references)
        num  target     prot opt source               destination         
        1    RETURN     all  --  0.0.0.0/0            0.0.0.0/0           
        2    RETURN     all  --  0.0.0.0/0            0.0.0.0/0 )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain POSTROUTING (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination )"""
    };

    std::vector<std::string> testTables2 = 
    {
        R"""( Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:20

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         
        1    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0            tcp dpt:60
        2    ACCEPT     udp  --  0.0.0.0/0            0.0.0.0/0            udp dpt:33 )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain POSTROUTING (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain PREROUTING (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain POSTROUTING (policy ACCEPT)
        num  target     prot opt source               destination )""",

        R"""( Chain INPUT (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain FORWARD (policy ACCEPT)
        num  target     prot opt source               destination         

        Chain OUTPUT (policy ACCEPT)
        num  target     prot opt source               destination )"""
    };

    MMI_JSON_STRING jsonString;
    int jsonSizeBytes;
    int status = MMI_OK;
    status = testModule.CreateFirewallJson(testTables, &jsonString, &jsonSizeBytes);
    ASSERT_TRUE(((MMI_OK == status) && (nullptr != jsonString)) || (MMI_OK != status));
    string resultString = string(jsonString, jsonSizeBytes);
    string expectedString = R"""({"Directions":"filter.INPUT.1=Out;filter.INPUT.2=Out;filter.INPUT.3=Out;filter.FORWARD.11=Both;filter.FORWARD.12=Both;filter.FORWARD.13=Both;filter.FORWARD.14=Both;filter.FORWARD.15=Both;filter.FORWARD.16=Both;filter.FORWARD.17=Both;filter.FORWARD.18=Both;filter.FORWARD.19=Both;filter.FORWARD.20=Both;filter.FORWARD.21=Both;filter.FORWARD.22=Both;filter.FORWARD.23=Both;filter.FORWARD.24=Both;filter.FORWARD.25=Both;filter.FORWARD.26=Both;filter.FORWARD.27=Both;filter.FORWARD.28=Both;filter.FORWARD.29=Both;nat.OUTPUT.1=Out;nat.POSTROUTING.1=In;nat.POSTROUTING.2=In","Targets":"filter.INPUT=ACCEPT;filter.INPUT.1=ACCEPT;filter.INPUT.2=ACCEPT;filter.INPUT.3=ACCEPT;filter.FORWARD=DROP;filter.FORWARD.1=DOCKER-USER;filter.FORWARD.2=DOCKER-ISOLATION-STAGE-1;filter.FORWARD.3=ACCEPT;filter.FORWARD.4=DOCKER;filter.FORWARD.5=ACCEPT;filter.FORWARD.6=ACCEPT;filter.FORWARD.7=ACCEPT;filter.FORWARD.8=DOCKER;filter.FORWARD.9=ACCEPT;filter.FORWARD.10=ACCEPT;filter.FORWARD.11=ACCEPT;filter.FORWARD.12=ACCEPT;filter.FORWARD.13=ACCEPT;filter.FORWARD.14=ACCEPT;filter.FORWARD.15=ACCEPT;filter.FORWARD.16=ACCEPT;filter.FORWARD.17=ACCEPT;filter.FORWARD.18=ACCEPT;filter.FORWARD.19=ACCEPT;filter.FORWARD.20=ACCEPT;filter.FORWARD.21=ACCEPT;filter.FORWARD.22=ACCEPT;filter.FORWARD.23=ACCEPT;filter.FORWARD.24=ACCEPT;filter.FORWARD.25=ACCEPT;filter.FORWARD.26=ACCEPT;filter.FORWARD.27=ACCEPT;filter.FORWARD.28=ACCEPT;filter.FORWARD.29=ACCEPT;filter.OUTPUT=ACCEPT;filter.DOCKER=references;filter.DOCKER-ISOLATION-STAGE-1=references;filter.DOCKER-ISOLATION-STAGE-1.1=DOCKER-ISOLATION-STAGE-2;filter.DOCKER-ISOLATION-STAGE-1.2=DOCKER-ISOLATION-STAGE-2;filter.DOCKER-ISOLATION-STAGE-1.3=RETURN;filter.DOCKER-ISOLATION-STAGE-2=references;filter.DOCKER-ISOLATION-STAGE-2.1=DROP;filter.DOCKER-ISOLATION-STAGE-2.2=DROP;filter.DOCKER-ISOLATION-STAGE-2.3=RETURN;filter.DOCKER-USER=references;filter.DOCKER-USER.1=RETURN;nat.PREROUTING=ACCEPT;nat.PREROUTING.1=DOCKER;nat.INPUT=ACCEPT;nat.OUTPUT=ACCEPT;nat.OUTPUT.1=DOCKER;nat.POSTROUTING=ACCEPT;nat.POSTROUTING.1=MASQUERADE;nat.POSTROUTING.2=MASQUERADE;nat.DOCKER=references;nat.DOCKER.1=RETURN;nat.DOCKER.2=RETURN;raw.PREROUTING=ACCEPT;raw.OUTPUT=ACCEPT;mangle.PREROUTING=ACCEPT;mangle.INPUT=ACCEPT;mangle.FORWARD=ACCEPT;mangle.OUTPUT=ACCEPT;mangle.POSTROUTING=ACCEPT;security.INPUT=ACCEPT;security.FORWARD=ACCEPT;security.OUTPUT=ACCEPT","Protocols":"filter.INPUT.1=tcp;filter.INPUT.2=tcp;filter.INPUT.3=tcp;filter.FORWARD.1=all;filter.FORWARD.2=all;filter.FORWARD.3=all;filter.FORWARD.4=all;filter.FORWARD.5=all;filter.FORWARD.6=all;filter.FORWARD.7=all;filter.FORWARD.8=all;filter.FORWARD.9=all;filter.FORWARD.10=all;filter.FORWARD.11=all;filter.FORWARD.12=all;filter.FORWARD.13=all;filter.FORWARD.14=all;filter.FORWARD.15=all;filter.FORWARD.16=all;filter.FORWARD.17=all;filter.FORWARD.18=all;filter.FORWARD.19=all;filter.FORWARD.20=all;filter.FORWARD.21=all;filter.FORWARD.22=all;filter.FORWARD.23=all;filter.FORWARD.24=all;filter.FORWARD.25=all;filter.FORWARD.26=all;filter.FORWARD.27=all;filter.FORWARD.28=all;filter.FORWARD.29=all;filter.DOCKER-ISOLATION-STAGE-1.1=all;filter.DOCKER-ISOLATION-STAGE-1.2=all;filter.DOCKER-ISOLATION-STAGE-1.3=all;filter.DOCKER-ISOLATION-STAGE-2.1=all;filter.DOCKER-ISOLATION-STAGE-2.2=all;filter.DOCKER-ISOLATION-STAGE-2.3=all;filter.DOCKER-USER.1=all;nat.PREROUTING.1=all;nat.OUTPUT.1=all;nat.POSTROUTING.1=all;nat.POSTROUTING.2=all;nat.DOCKER.1=all;nat.DOCKER.2=all","IpAddresses":"","Ports":"filter.INPUT.1=3306;filter.INPUT.2=3306;filter.INPUT.3=3306"})""";
    EXPECT_STREQ(resultString.c_str(), expectedString.c_str());
    delete [] jsonString;
    jsonString = nullptr;
    status = MMI_OK;

    status = testModule.CreateFirewallJson(testTables2, &jsonString, &jsonSizeBytes);
    ASSERT_TRUE(((MMI_OK == status) && (nullptr != jsonString)) || (MMI_OK != status));
    expectedString = R"""({"Directions":"filter.INPUT.1=Out;filter.OUTPUT.1=Out;filter.OUTPUT.2=Out","Targets":"filter.INPUT=ACCEPT;filter.INPUT.1=ACCEPT;filter.FORWARD=ACCEPT;filter.OUTPUT=ACCEPT;filter.OUTPUT.1=ACCEPT;filter.OUTPUT.2=ACCEPT;nat.PREROUTING=ACCEPT;nat.INPUT=ACCEPT;nat.OUTPUT=ACCEPT;nat.POSTROUTING=ACCEPT;raw.PREROUTING=ACCEPT;raw.OUTPUT=ACCEPT;mangle.PREROUTING=ACCEPT;mangle.INPUT=ACCEPT;mangle.FORWARD=ACCEPT;mangle.OUTPUT=ACCEPT;mangle.POSTROUTING=ACCEPT;security.INPUT=ACCEPT;security.FORWARD=ACCEPT;security.OUTPUT=ACCEPT","Protocols":"filter.INPUT.1=tcp;filter.OUTPUT.1=tcp;filter.OUTPUT.2=udp","IpAddresses":"","Ports":"filter.INPUT.1=20;filter.OUTPUT.1=60;filter.OUTPUT.2=33"})""";
    resultString = string(jsonString, jsonSizeBytes);
    EXPECT_STREQ(resultString.c_str(), expectedString.c_str());
    delete [] jsonString;
    jsonString = nullptr;
}