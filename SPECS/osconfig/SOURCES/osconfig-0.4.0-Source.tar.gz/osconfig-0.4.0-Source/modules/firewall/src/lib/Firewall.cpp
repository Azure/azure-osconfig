#include <CommonUtils.h>
#include <Mmi.h>
#include <vector> 
#include <string>
#include <sstream>
#include <bits/stdc++.h>
#include "Firewall.h"

OSCONFIG_LOG_HANDLE FirewallLog::m_logFirewall = nullptr; 

#define DIRECTIONS "Directions"
#define TARGETS "Targets"
#define PROTOCOLS "Protocols"
#define IPADDRESSES "IpAddresses"
#define PORTS "Ports"

const string g_chainString = "Chain";
const string g_numString = "num";
const string g_logString = "LOG";
const string g_inString = "In";
const string g_outString = "Out";
const string g_bothString = "Both";
const string g_anyIp = "0.0.0.0/0";

const unsigned char g_sourcePort = 's';
const unsigned char g_destinationPort = 'd';

const unsigned int g_protocolIndex = 2;
const unsigned int g_policyIndex = 3;
const unsigned int g_sourceIndex = 4;
const unsigned int g_destinationIndex = 5;
const unsigned int g_firstPortIndex = 7;
const unsigned int g_secondPortIndex = 8;

const vector<string> g_tableNames = {"filter", "nat", "raw", "mangle", "security"};
const unsigned int g_numFields = g_tableNames.size();

const char* g_firewallTemplate = R"""({"Directions":"","Targets":"","Protocols":"","IpAddresses":"","Ports":""})""";

FirewallObject::FirewallObject(unsigned int maxPayloadSizeBytes)
{
    m_maxPayloadSizeBytes = maxPayloadSizeBytes;
}

FirewallObject::~FirewallObject() {}

int FirewallObjectBase::Set(
    MMI_HANDLE /* clientSession */,
    const char* /* componentName */,
    const char* /* objectName */,
    const MMI_JSON_STRING /* payload */,
    const int /* payloadSizeBytes */)
{
    OsConfigLogError(FirewallLog::Get(), "Set not implemented.");
    return ENOSYS;
}

int FirewallObjectBase::Get(
    MMI_HANDLE /*clientSession*/,
    const char* /*componentName*/,
    const char* /*objectName*/,
    MMI_JSON_STRING*  payload,
    int* payloadSizeBytes)
{
    int status = MMI_OK; 
    vector<string> iptables; 
    status = GetFirewallTable(iptables);

    if (status != MMI_OK) 
    {
        payload = nullptr;
        return ENODATA; 
    }

    status = CreateFirewallJson(iptables, payload, payloadSizeBytes);

    return status;
}

int FirewallObject::GetFirewallTable(vector<string> &iPTables)
{ 
    int status = MMI_OK;
    int tempStatus = MMI_OK;
    for (std::vector<string>::size_type k = 0; k < g_tableNames.size(); k++)
    {
        string specificTable = "iptables -t " + g_tableNames[k] + " -L -n --line-numbers";
        string specificOutput = "";
        char* char_specificOutput = nullptr;
        const char* char_specificTable = specificTable.c_str();
        if (MMI_OK == (tempStatus = ExecuteCommand(char_specificTable, false, 0, 0, &char_specificOutput, nullptr, FirewallLog::Get())))
        {
            specificOutput = (nullptr != char_specificOutput) ? string(char_specificOutput) : "";
        }
        else
        {
#ifdef LOG_VALUE_PAYLOAD
            OsConfigLogError(FirewallLog::Get(), "Failed to execute command '%s': %d, '%s'", specificTable.c_str(), tempStatus, (nullptr != char_specificOutput) ? char_specificOutput : "-");
#endif
        }

        iPTables.push_back(specificOutput);
        if (nullptr != char_specificOutput)
        {
            free(char_specificOutput);
        }
    }

    if (iPTables.size() != g_tableNames.size())
    {
        iPTables = vector<string> (g_tableNames.size(), "");
    }
    return status;
}

vector<string> FirewallObjectBase::CreateStringSetting(int tableIndex, string table)
{
    vector<string> iptable;
    string chainName; 
    string defaultChainTarget;
    string tableName;
    string directions;
    string targets;
    string protocols;
    string ipaddresses;
    string ports;

    if (table.empty())
    {
        return vector<string>(g_numFields, "");
    }
    
    if (tableIndex >= 0 && tableIndex < (int)g_tableNames.size())
    {
        tableName = g_tableNames[tableIndex];
    }
    else
    {
        return vector<string>(g_numFields, "");
    }
 
    string buf; 
    stringstream ss(table); 
    vector<string> tokens;

    while(std::getline(ss, buf, '\n')) 
    {
        tokens.push_back(buf);
    }

    for (std::string::size_type k = 0; k < tokens.size(); k++)
    {
        stringstream ss(tokens[k]);
        vector<string> currLine;
        string buf;

        while (ss >> buf)
        {
            currLine.push_back(buf);
        } 

        if (!tokens[k].empty())
        {
            if ((currLine.size() > 0) && (currLine[0] == g_chainString))
            {
                if (currLine.size() > 1)
                {
                    chainName = currLine[1];
                }

                string formattedTarget; 
                if (currLine.size() > g_policyIndex)
                {
                    for (std::string::size_type m = 0; m < currLine[g_policyIndex].length() - 1; m++)
                    {
                        formattedTarget += currLine[g_policyIndex][m];
                    }
                }

                if (!formattedTarget.empty())
                {
                    string defaultChainRule = tableName + "." + chainName + "=" + formattedTarget + ";";
                    targets += defaultChainRule;
                }
            }
            else if ((currLine.size() > 0) && (currLine[0] != g_numString))
            {
                // This line is a rule starting with a number like "1", "2", "3"
                // Convert this rule to strings
                string tempDirections = RuleToString(DIRECTIONS, tableName, chainName, tokens[k]);
                if (!tempDirections.empty())
                {
                    directions += tempDirections;
                }

                string tempTargets = RuleToString(TARGETS, tableName, chainName, tokens[k]);
                if (!tempTargets.empty())
                {
                    targets += tempTargets;
                }

                string tempProtocols = RuleToString(PROTOCOLS, tableName, chainName, tokens[k]);
                if (!tempProtocols.empty())
                {
                    protocols += tempProtocols;
                }

                string tempIpaddresses = RuleToString(IPADDRESSES, tableName, chainName, tokens[k]);
                if (!tempIpaddresses.empty())
                {
                    ipaddresses += tempIpaddresses;
                }

                string tempPorts = RuleToString(PORTS, tableName, chainName, tokens[k]);
                if (!tempPorts.empty())
                {
                    ports += tempPorts;
                }
            }
        }
    }
 
    iptable.push_back(directions);
    iptable.push_back(targets);
    iptable.push_back(protocols);
    iptable.push_back(ipaddresses);
    iptable.push_back(ports);

    if (iptable.size() != g_numFields)
    {
        iptable = vector<string>(g_numFields, "");
    }

    return iptable;
}

string FirewallObjectBase::RuleToString(string settingName, string tableName, string chainName, string rule)
{
    string append;
    string ruleNumber;

    if (settingName.empty() || tableName.empty() || chainName.empty() || rule.empty())
    {
        return append; 
    }

    stringstream ss(rule);
    vector<string> tokens;
    string buf;

    while (ss >> buf)
    {
        tokens.push_back(buf);
    }

    if (tokens.empty())
    {
        return append;
    }

    ruleNumber = tokens[0];

    if (settingName == DIRECTIONS)
    {
        // If source ipaddress and destination ipaddress are 0.0.0.0/0
        if ((tokens.size() > g_destinationIndex) && (tokens[g_sourceIndex] == g_anyIp) && (tokens[g_destinationIndex] == g_anyIp))
        {
            // If sport and dport both exist
            if ((tokens.size() > g_secondPortIndex) && (!tokens[g_firstPortIndex].empty() && tokens[g_firstPortIndex][0] == g_sourcePort) && (!tokens[g_secondPortIndex].empty() && tokens[g_secondPortIndex][0] == g_destinationPort))
            {
                 append = tableName + "." + chainName + "." + ruleNumber + "=" + g_bothString + ";";
            }
            // If only sport exists, then direction is in
            else if ((tokens.size() > g_firstPortIndex) && (!tokens[g_firstPortIndex].empty() && tokens[g_firstPortIndex][0] == g_sourcePort))
            {
                append = tableName + "." + chainName + "." + ruleNumber + "=" + g_inString + ";";
            }
            // If only dport exists, then direction is out
            else if ((tokens.size() > g_firstPortIndex) && (!tokens[g_firstPortIndex].empty() && tokens[g_firstPortIndex][0] == g_destinationPort))
            {
                append = tableName + "." + chainName + "." + ruleNumber + "=" + g_outString + ";";
            }
        }
        else if ((tokens.size() > g_destinationIndex) && (tokens[g_sourceIndex] != g_anyIp) && (tokens[g_destinationIndex] != g_anyIp))
        {
            append = tableName + "." + chainName + "." + ruleNumber + "=" + g_bothString + ";";
        }
        else
        {
            // If source ipaddress is not 0.0.0.0
            // check if first port is dport or second port is dport, then direction is both
            // otherwise, directino is in
            if ((tokens.size() > g_sourceIndex) && (tokens[g_sourceIndex] != g_anyIp))
            {
                if ((tokens.size() > g_firstPortIndex) && (!tokens[g_firstPortIndex].empty() && tokens[g_firstPortIndex][0] == g_destinationPort))
                {
                    append = tableName + "." + chainName + "." + ruleNumber + "=" + g_bothString + ";";
                }
                else if ((tokens.size() > g_secondPortIndex) && !tokens[g_secondPortIndex].empty() && tokens[g_secondPortIndex][0] == g_destinationPort)
                {
                    append = tableName + "." + chainName + "." + ruleNumber + "=" + g_bothString + ";";
                }
                else
                {
                    append = tableName + "." + chainName + "." + ruleNumber + "=" + g_inString + ";";
                }
            }

            // If destination ipaddress is not 0.0.0.0
            // check if sport exists, if so, direction is both
            // otherwise, direction is out
            if ((tokens.size() > g_destinationIndex) && (tokens[g_destinationIndex] != g_anyIp))
            {
                if ((tokens.size() > g_firstPortIndex) && (!tokens[g_firstPortIndex].empty() && tokens[g_firstPortIndex][0] == g_sourcePort))
                {
                    append = tableName + "." + chainName + "." + ruleNumber + "=" + g_bothString + ";";
                }
                else
                {
                    append = tableName + "." + chainName + "." + ruleNumber + "=" + g_outString + ";";
                }
            }
        }

        return append;
    }
    else if (settingName == TARGETS)
    {
        bool log = false; 
        string logOutput; 
        for (std::string::size_type k = 2; k < tokens.size(); k++)
        {
            if (tokens[k] == g_logString)
            {
                log = true; 
                logOutput = "/";
            }
            else if (log)
            {
                logOutput += tokens[k];
            }
        }
        if (log && (tokens.size() > 1))
        {
            logOutput += "/"; 
            append = tableName + "." + chainName + "." + ruleNumber + "=" + tokens[1] + logOutput + ";";
        }
        else if (tokens.size() > 1)
        {
            append = tableName + "." + chainName + "." + ruleNumber + "=" + tokens[1] + ";";
        }

        return append;
    }
    else if ((settingName == PROTOCOLS) && (tokens.size() > g_protocolIndex))
    {
        append = tableName + "." + chainName + "." + ruleNumber + "=" + tokens[g_protocolIndex] + ";";
        
        return append; 
    }
    else if (settingName == IPADDRESSES)
    {
        // If both source and destination ipaddresses are non-zero
        // we add both to ipaddress
        if ((tokens.size() > g_destinationIndex) && (tokens[g_sourceIndex] != g_anyIp) && (tokens[g_destinationIndex] != g_anyIp))
        {
            append = tableName + "." + chainName + "." + ruleNumber + "=" + tokens[g_sourceIndex] + "," + tokens[g_destinationIndex] + ";";
        }
        else
        {
            // otherwise add the non-zero ipaddress (if any)
            if ((tokens.size() > g_sourceIndex) && (tokens[g_sourceIndex] != g_anyIp))
            {
                append = tableName + "." + chainName + "." + ruleNumber + "=" + tokens[g_sourceIndex] + ";";
            }

            if (tokens.size() > g_destinationIndex && (tokens[g_destinationIndex] != g_anyIp))
            {
                append = tableName + "." + chainName + "." + ruleNumber + "=" + tokens[g_destinationIndex] + ";";
            }
        }

        return append;
    }
    // settingName == "Ports"
    else
    {
        // tokens[g_firstPortIndex] and tokens[g_firstPortIndex] are strings look like dpt:80 or spt:22
        // Check if source and destination port numbers exist
        // Create a rule appending port numbers (if any)
        if ((tokens.size() > g_secondPortIndex) && (tokens[g_firstPortIndex].size() > 2) && (tokens[g_firstPortIndex][1] == 'p') && (tokens[g_secondPortIndex].size() > 2) && (tokens[g_secondPortIndex][1] == 'p'))
        {
            string firstPortNumber, secondPortNumber;
            for (std::string::size_type m = 0; m < tokens[g_firstPortIndex].length(); m++)
            {
                if (tokens[g_firstPortIndex][m] == ':')
                {
                    for (std::string::size_type s = m + 1; s < tokens[g_firstPortIndex].length(); s++)
                    {
                        firstPortNumber += tokens[g_firstPortIndex][s];
                    }
                    break;
                }
            }

            for (std::string::size_type m = 0; m < tokens[g_secondPortIndex].length(); m++)
            {
                if (tokens[g_secondPortIndex][m] == ':')
                {
                    for (std::string::size_type s = m + 1; s < tokens[g_secondPortIndex].length(); s++)
                    {
                        secondPortNumber += tokens[g_secondPortIndex][s];
                    }
                    break;
                }
            }

            if (!firstPortNumber.empty() && !secondPortNumber.empty())
            {
                append = tableName + "." + chainName + "." + ruleNumber + "=" + firstPortNumber + "," + secondPortNumber + ";";
            }
        }
        else if ((tokens.size() > g_firstPortIndex) && (tokens[g_firstPortIndex].size() > 2) && (tokens[g_firstPortIndex][1] == 'p'))
        {
            string firstPortNumber;
            for (std::string::size_type m = 0; m < tokens[g_firstPortIndex].length(); m++)
            {
                if (tokens[g_firstPortIndex][m] == ':')
                {
                    for (std::string::size_type s = m + 1; s < tokens[g_firstPortIndex].length(); s++)
                    {
                        firstPortNumber += tokens[g_firstPortIndex][s];
                    }
                    break;
                }
            }
            if (!firstPortNumber.empty())
            {
                append = tableName + "." + chainName + "." + ruleNumber + "=" + firstPortNumber + ";";
            }
        }

        return append;
    }
}

//concatenate each strings in the same row
string FirewallObjectBase::CreateJsonValueString(vector<vector<string>> &columns, int currentRow)
{
    string valueString = "";
    for (size_t j = 0; j < columns.size(); j++)
    {
        if ((currentRow >= 0) && (currentRow < (int)columns[j].size()))
        {
            if (!columns[j][currentRow].empty())
            {
                valueString += columns[j][currentRow];
            }
        }
    }
    if (!valueString.empty() && valueString.back() == ';')
    {
        valueString.pop_back();
    }
    // valueString can be empty
    return valueString;
}

int FirewallObjectBase::CreateJsonFromTables(rapidjson::Document &doc ,vector<string> tables)
{
    int status = MMI_OK;
    try
    {
        // Convert iptable special strings to JSON Document
        vector<std::string> keys = {DIRECTIONS, TARGETS, PROTOCOLS, IPADDRESSES, PORTS};
        auto& allocator = doc.GetAllocator();
        doc.SetObject();
        vector<vector<string>> columns;

        for (size_t i = 0; i < tables.size(); i++)
        {
            vector<string> stringSettings = CreateStringSetting(i, tables[i]);
            columns.push_back(stringSettings);
        }
        unsigned int maxValueSize = 0;
        // If m_maxPayloadSizeBytes is zero or a negative number, we do not truncate.
        if (m_maxPayloadSizeBytes > 0)
        {
            maxValueSize = (m_maxPayloadSizeBytes > strlen(g_firewallTemplate)) ? (m_maxPayloadSizeBytes - strlen(g_firewallTemplate)) : 0;
        }

        unsigned int currentValueSize = 0;
        for (size_t i = 0; i < keys.size(); i++)
        {
            rapidjson::Value key(keys[i].c_str(), allocator);
            string valueString = CreateJsonValueString(columns, i);
            if ((m_maxPayloadSizeBytes > 0) && ((currentValueSize + valueString.length()) > maxValueSize))
            {
                valueString = "";
            }

            currentValueSize += valueString.length();
            rapidjson::Value value(valueString.c_str(), allocator);
            doc.AddMember(key, value, allocator);
        }
    }
    catch (const std::exception &e)
    {
        status = EINTR;
    }

    return status;
}

int FirewallObjectBase::CreateFirewallJson(vector<string> tables, MMI_JSON_STRING* jsonString, int* jsonSizeBytes)
{
    int status = MMI_OK;
    rapidjson::Document doc;
    // Convert iptable special strings to JSON Document
    status = CreateJsonFromTables(doc, tables);
    if (MMI_OK != status)
    {
        jsonString = nullptr;
        return status;
    }

    try
    {
        // Serialize JSON Document
        rapidjson::StringBuffer buffer;
        rapidjson::Writer<rapidjson::StringBuffer> writer(buffer);
        doc.Accept(writer);
        *jsonSizeBytes = buffer.GetSize();
        *jsonString = new (std::nothrow) char[buffer.GetSize()];
        if (nullptr == *jsonString)
        {
            status = ENOBUFS;
        }
        else
        {
            std::fill(*jsonString, *jsonString + buffer.GetSize(), 0);
            std::memcpy(*jsonString, buffer.GetString(), buffer.GetSize());
        }
    }
    catch (const std::exception &e)
    {
        status = EINTR;
    }

    return status;
}