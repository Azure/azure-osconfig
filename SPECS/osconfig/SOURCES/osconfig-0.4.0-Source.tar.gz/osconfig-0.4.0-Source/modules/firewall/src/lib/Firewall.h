#include <string>
#include <vector>
#include <memory>
#include <Mmi.h>
#include <Logging.h>
#include <rapidjson/document.h>
#include <rapidjson/writer.h>
#include <rapidjson/schema.h>

using namespace std; 

#define FIREWALL_LOGFILE "/var/log/osconfig_firewall.log"
#define FIREWALL_ROLLEDLOGFILE "/var/log/osconfig_firewall.bak"
class FirewallLog
{
public:
    static OSCONFIG_LOG_HANDLE Get()
    {
        return m_logFirewall;
    }
    static void OpenLog()
    {
        m_logFirewall = ::OpenLog(FIREWALL_LOGFILE, FIREWALL_ROLLEDLOGFILE, NULL);
    }
    static void CloseLog()
    {
        ::CloseLog(&m_logFirewall);
    }
    
private:
    static OSCONFIG_LOG_HANDLE m_logFirewall;
};

class FirewallObjectBase
{
public:
    virtual ~FirewallObjectBase() {};
    int Get(MMI_HANDLE clientSession, const char* componentName, const char* objectName, MMI_JSON_STRING*  payload, int* payloadSizeBytes); 
    int Set(MMI_HANDLE clientSession, const char* componentName, const char* objectName, const MMI_JSON_STRING payload, const int payloadSizeBytes);
    virtual int GetFirewallTable(vector<string> &iPTables) = 0;
    int CreateFirewallJson(vector<string> tables, MMI_JSON_STRING* jsonString, int* jsonSizeBytes);
    vector<string> CreateStringSetting(int tableType, string table);
    unsigned int m_maxPayloadSizeBytes;

private:
    string RuleToString(string settingName, string tableName, string chainName, string rule);
    string CreateJsonValueString(vector<vector<string>> &columns, int currentRow);
    int CreateJsonFromTables(rapidjson::Document &doc ,vector<string> tables);
};

class FirewallObject : public FirewallObjectBase
{
public:
    FirewallObject(unsigned int maxPayloadSizeBytes);
    ~FirewallObject();
    int GetFirewallTable(vector<string> &iPTables);
};