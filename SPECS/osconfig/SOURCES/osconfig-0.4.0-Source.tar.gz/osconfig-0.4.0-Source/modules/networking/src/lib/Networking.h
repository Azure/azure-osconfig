#include <string>
#include <vector>
#include <rapidjson/writer.h>
#include <Logging.h>
#include <Mmi.h>

#define NETWORKING_LOGFILE "/var/log/osconfig_networking.log"
#define NETWORKING_ROLLEDLOGFILE "/var/log/osconfig_networking.bak"

class NetworkingLog
{
public:
    static OSCONFIG_LOG_HANDLE Get()
    {
        return m_logNetworking;
    }

    static void OpenLog()
    {
        m_logNetworking = ::OpenLog(NETWORKING_LOGFILE, NETWORKING_ROLLEDLOGFILE, NULL);
    }

    static void CloseLog()
    {
        ::CloseLog(&m_logNetworking);
    }

private:
    static OSCONFIG_LOG_HANDLE m_logNetworking;
};

struct NetworkingData
{
    std::string interfaceTypes;
    std::string macAddresses;
    std::string ipAddresses;
    std::string subnetMasks;
    std::string defaultGateways;
    std::string dnsServers;
    std::string dhcpEnabled;
    std::string enabled;
    std::string connected;
};

enum class NetworkingSettingType
{
    InterfaceTypes,
    MacAddresses,
    IpAddresses,
    SubnetMasks,
    DefaultGateways,
    DnsServers,
    DhcpEnabled,
    Enabled,
    Connected
};

enum class NetworkingQueryType
{
    IpAddr,
    IpRoute,
    Other
};

class NetworkingObjectBase
{
public:
    virtual ~NetworkingObjectBase() {};
    virtual std::string RunCommand(const char* command) = 0;

    int Get(
        MMI_HANDLE clientSession,
        const char* componentName,
        const char* objectName,
        MMI_JSON_STRING* payload,
        int* payloadSizeBytes);

    int Set(
        MMI_HANDLE clientSession,
        const char* componentName,
        const char* objectName,
        const MMI_JSON_STRING payload,
        const int payloadSizeBytes);

    bool IsSamePayload(const char* payload, int* payloadSizeBytes);

    unsigned int m_maxPayloadSizeBytes;

private:
    void ExtractTargetData(bool labeled, std::vector<std::string> dataIdentifiers, std::stringstream& commandOutputStream, std::vector<std::string>& data);
    void GenerateInterfaceSettingsString(std::vector<std::string> interfaceSettings, std::string& interfaceSettingsString);
    void ParseCommandOutput(const std::string& interfaceName, const std::string& interfaceData, NetworkingSettingType networkingSettingType, std::string& interfaceSettingsString);
    void GetInterfaceNames(std::vector<std::string>& interfaceNames);
    const char* NetworkingSettingTypeToString(NetworkingSettingType networkingSettingType);
    void GenerateNetworkingSettingsString(std::vector<std::tuple<std::string, std::string>> networkingSettings, std::string& networkingSettingsString);
    void GetData(NetworkingSettingType networkingSettingType, NetworkingQueryType networkingQueryType, std::string& networkingSettingsString);
    bool IsInterfaceName(std::string name);
    void GenerateIpAddrDataMap();
    void GenerateDefaultGatewaysMap();
    void GenerateDnsServersMap();
    void GenerateNetworkingData();
    virtual int WriteJsonElement(rapidjson::Writer<rapidjson::StringBuffer>* writer, const char* key, const char* value) = 0;

    NetworkingData m_networkingData;
    std::vector<std::string> m_interfaceNames;
    std::map<std::string, std::string> m_ipAddrDataMap;
    std::map<std::string, std::vector<std::string>> m_defaultGatewaysMap;
    std::map<std::string, std::vector<std::string>> m_dnsServersMap;

    std::hash<std::string> m_hashString;
    size_t m_previousPayloadHash;
};

class NetworkingObject : public NetworkingObjectBase
{
public:
    std::string RunCommand(const char* command) override;
    int WriteJsonElement(rapidjson::Writer<rapidjson::StringBuffer>* writer, const char* key, const char* value) override;
    NetworkingObject(unsigned int maxPayloadSizeBytes);
    ~NetworkingObject();
};