#include <algorithm>
#include <iostream>
#include <rapidjson/document.h>
#include <rapidjson/schema.h>
#include <rapidjson/stringbuffer.h>
#include <rapidjson/writer.h>
#include <regex>
#include <sstream>
#include <stdio.h>
#include <Networking.h>
#include <CommonUtils.h>

const char* g_interfaceNamesCommand = "ls -A /sys/class/net";

const char* g_ipAddrQuery = "ip addr";
const char* g_ipRouteQuery = "ip route";
const char* g_systemdResolveQuery = "systemd-resolve --status";

const char* g_interfaceTypesString = "InterfaceTypes";

const char* g_macAddressesString = "MacAddresses";
const char* g_macAddressesDataLabel = "link/";

const char* g_ipAddressesString = "IpAddresses";
const char* g_ipAddressesDataLabel = "inet";

const char* g_subnetMasksString = "SubnetMasks";
const char* g_subnetMasksDataLabel = "inet";

const char* g_defaultGatewaysString = "DefaultGateways";

const char* g_dnsServersString = "DnsServers";

const char* g_dhcpEnabledString = "DhcpEnabled";
const char* g_dhcpEnabledIdentifier = "dynamic";
const char* g_dhcpDisabled = "DHCP_DISABLED";

const char* g_enabledString = "Enabled";
const char* g_enabledDataLabel = "state";
const char* g_isEnabledString = "UP";
const char* g_isDisabledString = "DOWN";

const char* g_connectedString = "Connected";
const char* g_connectedIdentifier = "LOWER_UP";

const char* g_true = "true";
const char* g_false = "false";
const char* g_unknown = "unknown";

const char* g_networkingTemplate = R"""({"InterfaceTypes":"","MacAddresses":"","IpAddresses":"","SubnetMasks":"","DefaultGateways":"","DnsServers":"","DhcpEnabled":"","Enabled":"","Connected":""})""";
const char* g_emptyValue = "";

const bool g_labeledData = true;
const bool g_nonLabeledData = false;

OSCONFIG_LOG_HANDLE NetworkingLog::m_logNetworking = nullptr;

NetworkingObject::NetworkingObject(unsigned int maxPayloadSizeBytes)
{
    m_maxPayloadSizeBytes = maxPayloadSizeBytes;
}

NetworkingObject::~NetworkingObject() {}

std::string NetworkingObject::RunCommand(const char* command)
{
    char* textResult = nullptr;
    int status = ExecuteCommand(command, false, 0, 0, &textResult, nullptr, NetworkingLog::Get());
    std::string commandOutputToReturn = "";
    if (MMI_OK == status)
    {
        commandOutputToReturn = (nullptr != textResult) ? std::string(textResult) : "";
    }
    else
    {
#ifdef LOG_VALUE_PAYLOAD
        OsConfigLogError(NetworkingLog::Get(), "Failed to execute command '%s': %d, '%s'", command, status, (nullptr != textResult) ? textResult : "-");
#endif
    }

    if (nullptr != textResult)
    {
        free(textResult);
    }

    return commandOutputToReturn;
}

void NetworkingObjectBase::ExtractTargetData(bool labeled, std::vector<std::string> dataIdentifiers, std::stringstream& commandOutputStream, std::vector<std::string>& data)
{
    std::string token = "";
    while (std::getline(commandOutputStream, token, ' '))
    {
        for (std::string identifier : dataIdentifiers)
        {
            if (token.find(identifier) != std::string::npos)
            {
                if (labeled)
                {
                    std::getline(commandOutputStream, token, ' ');
                }
                if (!token.empty())
                {
                    token.erase(std::remove(token.begin(), token.end(), '\n'), token.end());
                    data.push_back(token);
                }
            }
        }
    }
}

void NetworkingObjectBase::GenerateInterfaceSettingsString(std::vector<std::string> interfaceSettings, std::string& interfaceSettingsString)
{
    size_t interfaceSettingsSize = interfaceSettings.size();
    for (size_t i = 0; i < interfaceSettingsSize; ++i)
    {
        if (i > 0)
        {
            interfaceSettingsString += ",";
        }

        interfaceSettingsString += interfaceSettings[i];
    }
}

void NetworkingObjectBase::ParseCommandOutput(const std::string& interfaceName, const std::string& interfaceData, NetworkingSettingType networkingSettingType, std::string& interfaceSettingsString)
{
    
    std::vector<std::string> interfaceSettings;
    std::vector<std::string> dataLabels;
    std::stringstream commandOutputStream(interfaceData);

    if ((networkingSettingType != NetworkingSettingType::DefaultGateways) && (networkingSettingType != NetworkingSettingType::DnsServers) && (interfaceData.empty()))
    {
        if ((networkingSettingType == NetworkingSettingType::DhcpEnabled) || (networkingSettingType == NetworkingSettingType::Enabled) || (networkingSettingType == NetworkingSettingType::Connected))
        {
            interfaceSettings.push_back(g_unknown);
        } 
        else
        {
            interfaceSettings.push_back("");
        }
    }
    else
    {
        switch (networkingSettingType)
        {
            case NetworkingSettingType::InterfaceTypes:
            {
                std::regex interfaceTypesPattern("link/[a-z]+\\s+");
                std::smatch interfaceTypesMatch;
                if (std::regex_search(interfaceData, interfaceTypesMatch, interfaceTypesPattern))
                {
                    std::string interfaceTypesData = interfaceTypesMatch.str(0);
                    size_t interfaceTypesDataPrefix = interfaceTypesData.find("/", 0);
                    size_t interfaceTypesDataSuffix = interfaceTypesData.find(" ", 0);
                    if (interfaceTypesDataPrefix != std::string::npos)
                    {
                        interfaceSettings.push_back(interfaceTypesData.substr(interfaceTypesDataPrefix + 1, interfaceTypesDataSuffix - interfaceTypesDataPrefix - 1));
                    }
                }
                break;
            }
            case NetworkingSettingType::MacAddresses:
            {
                dataLabels.push_back(g_macAddressesDataLabel);
                ExtractTargetData(g_labeledData, dataLabels, commandOutputStream, interfaceSettings);
                break;
            }
            case NetworkingSettingType::IpAddresses:
            {

                dataLabels.push_back(g_ipAddressesDataLabel);
                ExtractTargetData(g_labeledData, dataLabels, commandOutputStream, interfaceSettings);
                size_t interfaceSettingsSize = interfaceSettings.size();
                for (size_t i = 0; i < interfaceSettingsSize; ++i)
                {
                    auto subnetMaskDelimiter = interfaceSettings[i].find("/");
                    if (subnetMaskDelimiter != std::string::npos)
                    {
                        interfaceSettings[i] = interfaceSettings[i].substr(0, subnetMaskDelimiter);
                    }
                    else
                    {
                        interfaceSettings.erase(interfaceSettings.begin() + i);
                    }
                }
                break;
            }
            case NetworkingSettingType::SubnetMasks:
            {
                dataLabels.push_back(g_subnetMasksDataLabel);
                ExtractTargetData(g_labeledData, dataLabels, commandOutputStream, interfaceSettings);
                size_t interfaceSettingsSize = interfaceSettings.size();
                for (size_t i = 0; i < interfaceSettingsSize; ++i)
                {
                    auto subnetMaskDelimiter = interfaceSettings[i].find("/");
                    if (subnetMaskDelimiter != std::string::npos)
                    {
                        interfaceSettings[i] = interfaceSettings[i].substr(subnetMaskDelimiter);
                    }
                    else
                    {
                        interfaceSettings.erase(interfaceSettings.begin() + i);
                    }
                }
                break;
            }
            case NetworkingSettingType::DefaultGateways:
            {
                for (size_t i = 0; i < this->m_defaultGatewaysMap[interfaceName].size(); ++i)
                {
                    interfaceSettings.push_back((this->m_defaultGatewaysMap[interfaceName]).at(i));
                }
                break;
            }
            case NetworkingSettingType::DnsServers:
            {
                for (size_t i = 0; i < this->m_dnsServersMap[interfaceName].size(); ++i)
                {
                    interfaceSettings.push_back((this->m_dnsServersMap[interfaceName]).at(i));
                }
                break;
            }
            case NetworkingSettingType::DhcpEnabled:
            {
                dataLabels.push_back(g_dhcpEnabledIdentifier);
                std::vector<std::string> interfaceSettingIdentifiers;
                ExtractTargetData(g_nonLabeledData, dataLabels, commandOutputStream, interfaceSettingIdentifiers);
                if (!interfaceSettingIdentifiers.empty())
                {
                    interfaceSettings.push_back(g_true);
                }
                else
                {
                    interfaceSettings.push_back(g_false);
                }
                break;
            }
            case NetworkingSettingType::Enabled:
            {
                dataLabels.push_back(g_enabledDataLabel);
                std::vector<std::string> interfaceSettingIdentifiers;
                ExtractTargetData(g_labeledData, dataLabels, commandOutputStream, interfaceSettingIdentifiers);
                if (!interfaceSettingIdentifiers.empty())
                {
                    std::string data = interfaceSettingIdentifiers.front(); 
                    if (data == g_isEnabledString)
                    {
                        interfaceSettings.push_back(g_true);
                    }
                    else if (data == g_isDisabledString)
                    {
                        interfaceSettings.push_back(g_false);
                    }
                    else
                    {
                        interfaceSettings.push_back(g_unknown);
                    }
                }
                break;
            }
            case NetworkingSettingType::Connected:
            {
                dataLabels.push_back(g_connectedIdentifier);
                std::vector<std::string> interfaceSettingIdentifiers;
                ExtractTargetData(g_nonLabeledData, dataLabels, commandOutputStream, interfaceSettingIdentifiers);
                if (!interfaceSettingIdentifiers.empty())
                {
                    interfaceSettings.push_back(g_true);
                }
                else
                {
                    interfaceSettings.push_back(g_false);
                }
                break;
            }
        }
    }

    GenerateInterfaceSettingsString(interfaceSettings, interfaceSettingsString);
}

void NetworkingObjectBase::GetInterfaceNames(std::vector<std::string>& interfaceNames)
{
    std::string commandOutput = RunCommand(g_interfaceNamesCommand);
    std::vector<std::string> interfaceNamesAccumulator;
    if (!commandOutput.empty())
    {
        std::stringstream commandOutputStream(commandOutput);
        std::string token = "";
        while (std::getline(commandOutputStream, token))
        {
            interfaceNamesAccumulator.push_back(token);
        }
    }

    interfaceNames = interfaceNamesAccumulator;
}

const char* NetworkingObjectBase::NetworkingSettingTypeToString(NetworkingSettingType networkingSettingType)
{
    switch (networkingSettingType)
    {
        case NetworkingSettingType::InterfaceTypes:
            return g_interfaceTypesString;
        case NetworkingSettingType::MacAddresses:
            return g_macAddressesString;
        case NetworkingSettingType::IpAddresses:
            return g_ipAddressesString;
        case NetworkingSettingType::SubnetMasks:
            return g_subnetMasksString;
        case NetworkingSettingType::DefaultGateways:
            return g_defaultGatewaysString;
        case NetworkingSettingType::DnsServers:
            return g_dnsServersString;
        case NetworkingSettingType::DhcpEnabled:
            return g_dhcpEnabledString;
        case NetworkingSettingType::Enabled:
            return g_enabledString;
        case NetworkingSettingType::Connected:
            return g_connectedString;
        default:
            return nullptr;
    }

    return nullptr;
}

void NetworkingObjectBase::GenerateNetworkingSettingsString(std::vector<std::tuple<std::string, std::string>> networkingSettings, std::string& networkingSettingsString)
{
    std::string networkingSettingsAccumulator;
    if (!networkingSettings.empty())
    {
        sort(networkingSettings.begin(), networkingSettings.end());
        int networkingSettingsSize = networkingSettings.size();
        for (int i = 0; i < networkingSettingsSize; ++i)
        {
            if (!std::get<1>(networkingSettings[i]).empty())
            {
                if (!networkingSettingsAccumulator.empty())
                {
                    networkingSettingsAccumulator += ";";
                }
                networkingSettingsAccumulator += std::get<0>(networkingSettings[i]) + "=" + std::get<1>(networkingSettings[i]);
            }
        }
    }

    networkingSettingsString = networkingSettingsAccumulator;
}

void NetworkingObjectBase::GetData(NetworkingSettingType networkingSettingType, NetworkingQueryType networkingQueryType, std::string& networkingSettingsString)
{
    std::vector<std::tuple<std::string, std::string>> networkingSettings;
    for (size_t i = 0; i < this->m_interfaceNames.size(); ++i)
    {
        std::string interfaceData;
        if (networkingQueryType == NetworkingQueryType::IpAddr)
        {
            interfaceData = this->m_ipAddrDataMap[this->m_interfaceNames[i]];
        }

        std::string interfaceSettingsString;
        ParseCommandOutput(this->m_interfaceNames[i], interfaceData, networkingSettingType, interfaceSettingsString);

        networkingSettings.push_back(make_tuple(this->m_interfaceNames[i], interfaceSettingsString));
    }

    GenerateNetworkingSettingsString(networkingSettings, networkingSettingsString);
}

bool NetworkingObjectBase::IsInterfaceName(std::string name)
{
    for (size_t i = 0; i < this->m_interfaceNames.size(); ++i)
    {
        if (name == this->m_interfaceNames[i])
        {
            return true;
        }
    }

    return false;
}

void NetworkingObjectBase::GenerateIpAddrDataMap()
{
    std::string ipData = RunCommand(g_ipAddrQuery);
    std::regex interfaceDataPrefixPattern("[0-9]+:\\s+.*:\\s+");
    std::smatch interfaceDataPrefixMatch;

    while (std::regex_search(ipData, interfaceDataPrefixMatch, interfaceDataPrefixPattern)) 
    {
        std::string interfaceDataPrefix = interfaceDataPrefixMatch.str(0);
        size_t interfaceNamePrefixBack = interfaceDataPrefix.find(" ", 0);
        size_t interfaceDataPrefixBack = interfaceDataPrefix.find_last_of(":");

        ipData = interfaceDataPrefixMatch.suffix().str();

        std::string interfaceName;
        if ((interfaceNamePrefixBack != std::string::npos) && (interfaceDataPrefixBack != std::string::npos))
        {
            interfaceName = interfaceDataPrefix.substr(interfaceNamePrefixBack + 1, interfaceDataPrefixBack - interfaceNamePrefixBack - 1);
        }

        if (IsInterfaceName(interfaceName))
        {
            std::string interfaceData = std::regex_search(ipData, interfaceDataPrefixMatch, interfaceDataPrefixPattern) ? ipData.substr(0, interfaceDataPrefixMatch.position(0)) : ipData;
            std::map<std::string, std::string>::iterator ipDataMapIterator = this->m_ipAddrDataMap.find(interfaceName);
            if (ipDataMapIterator != this->m_ipAddrDataMap.end())
            {
                ipDataMapIterator->second = interfaceData;
            }
            else
            {
                this->m_ipAddrDataMap.insert(std::pair<std::string, std::string>(interfaceName, interfaceData));
            }
        }
    }
}

void NetworkingObjectBase::GenerateDefaultGatewaysMap()
{
    this->m_defaultGatewaysMap.clear();

    std::string defaultGatewaysData = RunCommand(g_ipRouteQuery);
    std::regex interfaceNamePrefixPattern("default\\s+via\\s+.*\\s+dev\\s+");
    std::smatch interfaceNamePrefixMatch;

    while (std::regex_search(defaultGatewaysData, interfaceNamePrefixMatch, interfaceNamePrefixPattern))
    {
        std::string interfaceNamePrefix = interfaceNamePrefixMatch.str(0);
        std::string interfaceNameData = interfaceNamePrefixMatch.suffix().str();
        size_t interfaceNameSuffixFront = interfaceNameData.find(" ", 0);

        std::string interfaceName;
        if (interfaceNameSuffixFront != std::string::npos)
        {
            interfaceName = interfaceNameData.substr(0, interfaceNameSuffixFront);
        }

        if (IsInterfaceName(interfaceName))
        {
            std::string defaultGateway;
            std::regex defaultGatewayPrefixPattern("default\\s+via\\s+");
            std::smatch defaultGatewayPrefixMatch;

            if (std::regex_search(defaultGatewaysData, defaultGatewayPrefixMatch, defaultGatewayPrefixPattern))
            {
                defaultGateway = defaultGatewayPrefixMatch.suffix().str();

                size_t defaultGatewaySuffixFront = defaultGateway.find(" ", 0);
                if (defaultGatewaySuffixFront != std::string::npos)
                {
                    defaultGateway = defaultGateway.substr(0, defaultGatewaySuffixFront);
                }
            }
            
            if (!defaultGateway.empty())
            {
                std::map<std::string, std::vector<std::string>>::iterator defaultGatewaysMapIterator = this->m_defaultGatewaysMap.find(interfaceName);
                if (defaultGatewaysMapIterator != this->m_defaultGatewaysMap.end())
                {
                    (defaultGatewaysMapIterator->second).push_back(defaultGateway);
                }
                else
                {
                    std::vector<std::string> defaultGateways{ defaultGateway };
                    this->m_defaultGatewaysMap.insert(std::pair<std::string, std::vector<std::string>>(interfaceName, defaultGateways));
                }
            }
        }

        defaultGatewaysData = interfaceNamePrefixMatch.suffix().str();
    }
}

void NetworkingObjectBase::GenerateDnsServersMap()
{
    this->m_dnsServersMap.clear();

    std::string dnsServersData = RunCommand(g_systemdResolveQuery);
    std::regex interfaceNamePrefixPattern("Link\\s+[0-9]+\\s+\\(");
    std::smatch interfaceNamePrefixMatch;

    while (std::regex_search(dnsServersData, interfaceNamePrefixMatch, interfaceNamePrefixPattern))
    {
        std::string interfaceNamePrefix = interfaceNamePrefixMatch.str(0);
        std::string interfaceNameData = interfaceNamePrefixMatch.suffix().str();
        size_t interfaceNameSuffixFront = interfaceNameData.find(")", 0);

        std::string interfaceName;
        if (interfaceNameSuffixFront != std::string::npos)
        {
            interfaceName = interfaceNameData.substr(0, interfaceNameSuffixFront);
        }

        dnsServersData = interfaceNameData;
        std::string interfaceData = std::regex_search(dnsServersData, interfaceNamePrefixMatch, interfaceNamePrefixPattern) ? dnsServersData.substr(0, interfaceNamePrefixMatch.position(0)) : dnsServersData; 

        if (IsInterfaceName(interfaceName))
        {
            std::string dnsServer;
            std::regex dnsServerPrefixPattern("DNS\\s+Servers:\\s+");
            std::smatch dnsServerPrefixMatch;

            if (std::regex_search(interfaceData, dnsServerPrefixMatch, dnsServerPrefixPattern))
            {
                std::stringstream dnsServerStream(dnsServerPrefixMatch.suffix().str());
                std::regex ipv4Pattern("(([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])");
                std::regex ipv6Pattern("(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}"
                ":[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}"
                "|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}"
                ":((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|[fF][eE]80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::([fF][eE]{4}(:0{1,4}){0,1}:){0,1}"
                "((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}"
                ":((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))");

                while(std::getline(dnsServerStream, dnsServer) && ((std::regex_match(dnsServer, ipv4Pattern)) || (std::regex_match(dnsServer, ipv6Pattern))))
                {
                    dnsServer.erase(remove(dnsServer.begin(), dnsServer.end(), ' '), dnsServer.end());

                    std::map<std::string, std::vector<std::string>>::iterator dnsServersMapIterator = this->m_dnsServersMap.find(interfaceName);
                    if (dnsServersMapIterator != this->m_dnsServersMap.end())
                    {
                        (dnsServersMapIterator->second).push_back(dnsServer);
                    }
                    else
                    {
                        std::vector<std::string> dnsServers{ dnsServer };
                        this->m_dnsServersMap.insert(std::pair<std::string, std::vector<std::string>>(interfaceName, dnsServers));
                    }
                }
            }
        }
    }
}

void NetworkingObjectBase::GenerateNetworkingData()
{
    GetInterfaceNames(this->m_interfaceNames);
    if (this->m_interfaceNames.size() > 0)
    {
        GenerateIpAddrDataMap();
        GenerateDefaultGatewaysMap();
        GenerateDnsServersMap();
        GetData(NetworkingSettingType::InterfaceTypes, NetworkingQueryType::IpAddr, this->m_networkingData.interfaceTypes);
        GetData(NetworkingSettingType::MacAddresses, NetworkingQueryType::IpAddr, this->m_networkingData.macAddresses);
        GetData(NetworkingSettingType::IpAddresses, NetworkingQueryType::IpAddr, this->m_networkingData.ipAddresses);
        GetData(NetworkingSettingType::SubnetMasks, NetworkingQueryType::IpAddr, this->m_networkingData.subnetMasks);
        GetData(NetworkingSettingType::DefaultGateways, NetworkingQueryType::IpRoute, this->m_networkingData.defaultGateways);
        GetData(NetworkingSettingType::DnsServers, NetworkingQueryType::Other, this->m_networkingData.dnsServers);
        GetData(NetworkingSettingType::DhcpEnabled, NetworkingQueryType::IpAddr, this->m_networkingData.dhcpEnabled);
        GetData(NetworkingSettingType::Enabled, NetworkingQueryType::IpAddr, this->m_networkingData.enabled);
        GetData(NetworkingSettingType::Connected, NetworkingQueryType::IpAddr, this->m_networkingData.connected);
    }
}

int NetworkingObject::WriteJsonElement(rapidjson::Writer<rapidjson::StringBuffer>* writer, const char* key, const char* value)
{
    int result = 0;
    if (false == writer->Key(key))
    {
        result = 1;
    }

    if (false == writer->String(value))
    {
        result = 1;
    }

    return result;
}

int NetworkingObjectBase::Get(
        MMI_HANDLE clientSession,
        const char* componentName,
        const char* objectName,
        MMI_JSON_STRING* payload,
        int* payloadSizeBytes)
{
    UNUSED(clientSession);
    UNUSED(componentName);
    UNUSED(objectName);

    int status = MMI_OK;

    GenerateNetworkingData();
    unsigned int maxValueSize = 0;
    // If m_maxPayloadSizeBytes is zero or a negative number, we do not truncate.
    if (m_maxPayloadSizeBytes > 0)
    {
        maxValueSize = (m_maxPayloadSizeBytes > strlen(g_networkingTemplate)) ? (m_maxPayloadSizeBytes - strlen(g_networkingTemplate)) : 0;
    }

    unsigned int currentValueSize = 0;
    rapidjson::StringBuffer sb;
    rapidjson::Writer<rapidjson::StringBuffer> writer(sb);
    writer.StartObject();

    int writeResult = 0;
    if ((!m_maxPayloadSizeBytes) || ((m_networkingData.interfaceTypes.length() + currentValueSize) <= maxValueSize))
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::InterfaceTypes), m_networkingData.interfaceTypes.c_str());
        currentValueSize += m_networkingData.interfaceTypes.length();
    }
    else
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::InterfaceTypes), g_emptyValue);
    }

    if ((!m_maxPayloadSizeBytes) || ((m_networkingData.macAddresses.length() + currentValueSize) <= maxValueSize))
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::MacAddresses), m_networkingData.macAddresses.c_str());
        currentValueSize += m_networkingData.macAddresses.length();
    }
    else
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::MacAddresses), g_emptyValue);
    }

    if ((!m_maxPayloadSizeBytes) || ((m_networkingData.ipAddresses.length() + currentValueSize) <= maxValueSize))
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::IpAddresses), m_networkingData.ipAddresses.c_str());
        currentValueSize += m_networkingData.ipAddresses.length();
    }
    else
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::IpAddresses), g_emptyValue);
    }

    if ((!m_maxPayloadSizeBytes) || ((m_networkingData.subnetMasks.length() + currentValueSize) <= maxValueSize))
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::SubnetMasks), m_networkingData.subnetMasks.c_str());
        currentValueSize += m_networkingData.subnetMasks.length();
    }
    else
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::SubnetMasks),g_emptyValue);
    }

    if ((!m_maxPayloadSizeBytes) || ((m_networkingData.defaultGateways.length() + currentValueSize) <= maxValueSize))
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::DefaultGateways), m_networkingData.defaultGateways.c_str());
        currentValueSize += m_networkingData.defaultGateways.length();
    }
    else
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::DefaultGateways), g_emptyValue);
    }

    if ((!m_maxPayloadSizeBytes) || ((m_networkingData.dnsServers.length() + currentValueSize) <= maxValueSize))
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::DnsServers), m_networkingData.dnsServers.c_str());
        currentValueSize += m_networkingData.dnsServers.length();
    }
    else
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::DnsServers), g_emptyValue);
    }

    if ((!m_maxPayloadSizeBytes) || ((m_networkingData.dhcpEnabled.length() + currentValueSize) <= maxValueSize))
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::DhcpEnabled), m_networkingData.dhcpEnabled.c_str());
        currentValueSize += m_networkingData.dhcpEnabled.length();
    }
    else
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::DhcpEnabled), g_emptyValue);
    }
    
    if ((!m_maxPayloadSizeBytes) || ((m_networkingData.enabled.length() + currentValueSize) <= maxValueSize))
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::Enabled), m_networkingData.enabled.c_str());
        currentValueSize += m_networkingData.enabled.length();
    }
    else
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::Enabled),  g_emptyValue);
    }

    if ((!m_maxPayloadSizeBytes) || ((m_networkingData.connected.length() + currentValueSize) <= maxValueSize))
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::Connected), m_networkingData.connected.c_str());
        currentValueSize += m_networkingData.connected.length();
    }
    else
    {
        writeResult += WriteJsonElement(&writer, NetworkingSettingTypeToString(NetworkingSettingType::Connected), g_emptyValue);
    }

    writer.EndObject();

    std::string networkingJsonString(sb.GetString());
    networkingJsonString.erase(std::find(networkingJsonString.begin(), networkingJsonString.end(), '\0'), networkingJsonString.end()); 

    *payloadSizeBytes = networkingJsonString.length();

    if (((m_maxPayloadSizeBytes > 0) && (m_maxPayloadSizeBytes <= strlen(g_networkingTemplate)) && ((unsigned int)*payloadSizeBytes != strlen(g_networkingTemplate))) || ((m_maxPayloadSizeBytes > strlen(g_networkingTemplate)) && ((unsigned int)*payloadSizeBytes > m_maxPayloadSizeBytes)))
    {
        OsConfigLogInfo(NetworkingLog::Get(), "Networking payload to report %u bytes, need to report %u bytes, reporting empty strings", (unsigned int)*payloadSizeBytes, m_maxPayloadSizeBytes);
        *payloadSizeBytes = strlen(g_networkingTemplate);
    }
    
    if (writeResult > 0)
    {
        *payloadSizeBytes = strlen(g_networkingTemplate);
    }

    *payload = new (std::nothrow) char[*payloadSizeBytes];
    if (nullptr == *payload)
    {
        status = ENOBUFS;
        OsConfigLogError(NetworkingLog::Get(), "Networking::Get failed to allocate memory");
    }
    else
    {
        std::fill(*payload, *payload + *payloadSizeBytes, 0);
        std::memcpy(*payload, ((*payloadSizeBytes) == (int)strlen(g_networkingTemplate)) ? g_networkingTemplate : networkingJsonString.c_str(), *payloadSizeBytes);
    }

    return status;
}

int NetworkingObjectBase::Set(
        MMI_HANDLE clientSession,
        const char* componentName,
        const char* objectName,
        const MMI_JSON_STRING payload, 
        const int payloadSizeBytes)
{
    UNUSED(clientSession);
    UNUSED(componentName);
    UNUSED(objectName);
    UNUSED(payload);
    UNUSED(payloadSizeBytes);

    OsConfigLogError(NetworkingLog::Get(), "Networking::Set not implemented");
    return ENOSYS;
}

bool NetworkingObjectBase::IsSamePayload(const char* payload, int* payloadSizeBytes)
{
    bool status = true;
    if ((nullptr != payload) && (nullptr != payloadSizeBytes))
    {
        size_t currentHash = this->m_hashString(std::string(*payload, *payloadSizeBytes));
        if (currentHash != this->m_previousPayloadHash)
        {
            this->m_previousPayloadHash = currentHash;
            status = false;
        }
    }
    else
    {
        OsConfigLogError(NetworkingLog::Get(), "Networking::IsSamePayload argument is nullptr");
    }

    return status;
}