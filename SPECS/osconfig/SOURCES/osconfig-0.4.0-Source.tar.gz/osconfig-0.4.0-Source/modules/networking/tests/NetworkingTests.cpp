// Copyright (c) Microsoft. All rights reserved.
#include <algorithm>
#include <cstdio>
#include <gtest/gtest.h>
#include <string>
#include <CommonUtils.h>
#include <Mmi.h>
#include <Networking.h>
#include <Logging.h>

class NetworkingObjectTest : public NetworkingObjectBase
{
public:
    NetworkingObjectTest(unsigned int maxPayloadSizeBytes);
    ~NetworkingObjectTest();
    std::vector <std::string> returnValues;
    unsigned int runCommandCount = 0;
    std::string RunCommand(const char* command);
    bool isTestWriteJsonElement = false;
    int WriteJsonElement(rapidjson::Writer<rapidjson::StringBuffer>* writer, const char* key, const char* value);
};

NetworkingObjectTest::NetworkingObjectTest(unsigned int maxPayloadSizeBytes)
{
    m_maxPayloadSizeBytes = maxPayloadSizeBytes;
}

NetworkingObjectTest::~NetworkingObjectTest() {}

std::string NetworkingObjectTest::RunCommand(const char* command)
{
    UNUSED(command);
    std::string commandResult = "";
    if (runCommandCount < (unsigned int)returnValues.size())
    {
        commandResult = returnValues[runCommandCount++];
    }

    return commandResult;
}

int NetworkingObjectTest::WriteJsonElement(rapidjson::Writer<rapidjson::StringBuffer>* writer, const char* key, const char* value)
{
    int result = MMI_OK;
    if (false == isTestWriteJsonElement)
    {
        if (false == writer->Key(key))
        {
            result = ENODATA;
        }

        if (false == writer->String(value))
        {
            result = ENODATA;
        }
    }
    else
    {
        writer->Key(key);
        writer->String(value);
        // return test error ENODATA indicating errors in writing key and value
        result = ENODATA;
    }

    return result;
}

namespace OSConfig::Platform::Tests
{
    unsigned int g_maxPayloadSizeBytes = 4000;

    std::string g_testCommandOutputNames = "docker0\neth0";
    
    std::string g_testIpData =
    "1: docker0: <BROADCAST,UP,LOWER_UP> mtu 65536 qdisc noqueue state UP group default qlen 1000\n"
    " link/bridge 0a:25:3g:6v:2f:89 brd 00:00:00:00:00:00\n"
    " inet 172.32.233.234/8 scope global dynamic noprefixroute docker0 valid_lft forever preferred_lft forever\n"
    " inet6 ::1/128 scope host valid_lft forever preferred_lft forever\n"
    "2: eth0: <BROADCAST,UP> mtu 65536 qdisc noqueue state DOWN group default qlen 1000\n"
    " link/ether 00:15:5d:26:cf:89 brd 00:00:00:00:00:00\n"
    " inet 172.27.181.213/20 scope noprefixroute valid_lft forever preferred_lft forever\n"
    " inet 10.1.1.2/16 scope global eth0\n"
    " inet6 fe80::5e42:4bf7:dddd:9b0f/64 scope link noprefixroute";
    
    std::string g_testCommandOutputDefaultGateways =
    "default via 172.17.128.1 dev docker0 proto\n"
    " 172.29.64.0/20 dev eth0 proto kernel scope link src 172.29.78.164\n"
    " default via 172.13.145.1 dev eth0 proto";
    
    std::string g_testCommandOutputDnsServers =
    "Link 2 (docker0)\n"
        "Current Scopes: DNS\n"
    "DefaultRoute setting: yes\n"
        "LLMNR setting: yes\n"
    "MulticastDNS setting: no\n"
    "DNSOverTLS setting: no\n"
        "DNSSEC setting: no\n"
        "DNSSEC supported: no\n"
    "Current DNS Server: 8.8.8.8\n"
            "DNS Servers: 8.8.8.8\n"
                        "172.29.64.1\n"
            "DNS Domain: mshome.net\n"
    "Link 3 (eth0)\n"
        "Current Scopes: DNS\n"
    "DefaultRoute setting: yes\n"
        "LLMNR setting: yes\n"
    "MulticastDNS setting: no\n"
    "DNSOverTLS setting: no\n"
        "DNSSEC setting: no\n"
        "DNSSEC supported: no\n"
    "Current DNS Server: 172.29.64.1\n"
            "DNS Servers: 172.29.64.1\n"
            "DNS Domain: mshome.net\n";

    std::vector<std::string> g_returnValues = {g_testCommandOutputNames, g_testIpData, g_testCommandOutputDefaultGateways, g_testCommandOutputDnsServers};

    TEST(NetworkingTests, Get_Success)
    {
        MMI_JSON_STRING payload;
        int payloadSizeBytes;
        NetworkingObjectTest testModule(g_maxPayloadSizeBytes);
        testModule.returnValues = g_returnValues;
        int result = testModule.Get(nullptr, nullptr, nullptr, &payload, &payloadSizeBytes);

        EXPECT_EQ(result, MMI_OK);

        std::string resultString(payload, payloadSizeBytes);
        EXPECT_STREQ(resultString.c_str(), "{\"InterfaceTypes\":\"docker0=bridge;eth0=ether\","
                                                "\"MacAddresses\":\"docker0=0a:25:3g:6v:2f:89;eth0=00:15:5d:26:cf:89\","
                                                "\"IpAddresses\":\"docker0=172.32.233.234,::1;eth0=172.27.181.213,10.1.1.2,fe80::5e42:4bf7:dddd:9b0f\","
                                                "\"SubnetMasks\":\"docker0=/8,/128;eth0=/20,/16,/64\","
                                                "\"DefaultGateways\":\"docker0=172.17.128.1;eth0=172.13.145.1\","
                                                "\"DnsServers\":\"docker0=8.8.8.8,172.29.64.1;eth0=172.29.64.1\","
                                                "\"DhcpEnabled\":\"docker0=true;eth0=false\","
                                                "\"Enabled\":\"docker0=true;eth0=false\","
                                                "\"Connected\":\"docker0=true;eth0=false\"}");

        delete payload;
    }

    TEST(NetworkingTests, Get_DnsServers)
    {
        std::string testCommandOutputNamesDnsServers = "br-1234\ndocker0\nveth\neth0";

        std::string testCommandOutputDnsServers =
        "Link 1 (br-1234)\n"
            "Current Scopes: none\n"
            "LLMNR setting: yes\n"
        "MulticastDNS setting: no\n"
        "DNSOverTLS setting: no\n"
            "DNSSEC setting: no\n"
            "DNSSEC supported: no\n"
        "\n"
        "Link 2 (docker0)\n"
            "Current Scopes: DNS\n"
        "DefaultRoute setting: yes\n"
            "LLMNR setting: yes\n"
        "MulticastDNS setting: no\n"
        "DNSOverTLS setting: no\n"
            "DNSSEC setting: no\n"
            "DNSSEC supported: no\n"
        "Current DNS Server: 8.8.8.8\n"
                "DNS Servers: 8.8.8.8\n"
                            "fe80::215:5dff:fe26:cf91\n"
                "DNS Domain: mshome.net\n"
        "\n"
        "Link 3 (veth)\n"
            "Current Scopes: none\n"
            "LLMNR setting: yes\n"
        "MulticastDNS setting: no\n"
        "DNSOverTLS setting: no\n"
            "DNSSEC setting: no\n"
            "DNSSEC supported: no\n"
        "\n"
        "Link 4 (eth0)\n"
            "Current Scopes: DNS\n"
        "DefaultRoute setting: yes\n"
            "LLMNR setting: yes\n"
        "MulticastDNS setting: no\n"
        "DNSOverTLS setting: no\n"
            "DNSSEC setting: no\n"
            "DNSSEC supported: no\n"
        "Current DNS Server: 172.29.64.1\n"
                "DNS Servers: 172.29.64.1\n"
                "DNS Domain: mshome.net\n";

        MMI_JSON_STRING payload;
        int payloadSizeBytes;
        NetworkingObjectTest testModule(g_maxPayloadSizeBytes);
        testModule.returnValues = g_returnValues;
        testModule.returnValues[0] = testCommandOutputNamesDnsServers;
        testModule.returnValues[3] = testCommandOutputDnsServers;

        int result = testModule.Get(nullptr, nullptr, nullptr, &payload, &payloadSizeBytes);

        EXPECT_EQ(result, MMI_OK);

        std::string resultString(payload, payloadSizeBytes);
        EXPECT_STREQ(resultString.c_str(), "{\"InterfaceTypes\":\"docker0=bridge;eth0=ether\","
                                                "\"MacAddresses\":\"docker0=0a:25:3g:6v:2f:89;eth0=00:15:5d:26:cf:89\","
                                                "\"IpAddresses\":\"docker0=172.32.233.234,::1;eth0=172.27.181.213,10.1.1.2,fe80::5e42:4bf7:dddd:9b0f\","
                                                "\"SubnetMasks\":\"docker0=/8,/128;eth0=/20,/16,/64\","
                                                "\"DefaultGateways\":\"docker0=172.17.128.1;eth0=172.13.145.1\","
                                                "\"DnsServers\":\"docker0=8.8.8.8,fe80::215:5dff:fe26:cf91;eth0=172.29.64.1\","
                                                "\"DhcpEnabled\":\"br-1234=unknown;docker0=true;eth0=false;veth=unknown\","
                                                "\"Enabled\":\"br-1234=unknown;docker0=true;eth0=false;veth=unknown\","
                                                "\"Connected\":\"br-1234=unknown;docker0=true;eth0=false;veth=unknown\"}");

        delete payload;
    }

    TEST(NetworkingTests, Get_Success_Multiple_Calls)
    {
        std::string testIpDataDocker0AddedAddress =
        "1: docker0: <BROADCAST,UP,LOWER_UP> mtu 65536 qdisc noqueue state UP group default qlen 1000\n"
        " link/bridge 0a:25:3g:6v:2f:89 brd 00:00:00:00:00:00\n"
        " inet 172.32.233.234/8 scope global dynamic noprefixroute docker0 valid_lft forever preferred_lft forever\n"
        " inet 10.1.1.1/16 scope global dynamic noprefixroute docker0 valid_lft forever preferred_lft forever\n"
        " inet6 ::1/128 scope host valid_lft forever preferred_lft forever\n"
        "2: eth0: <BROADCAST,UP> mtu 65536 qdisc noqueue state DOWN group default qlen 1000\n"
        " link/ether 00:15:5d:26:cf:89 brd 00:00:00:00:00:00\n"
        " inet 172.27.181.213/20 scope noprefixroute valid_lft forever preferred_lft forever\n"
        " inet 10.1.1.2/16 scope global eth0\n"
        " inet6 fe80::5e42:4bf7:dddd:9b0f/64 scope link noprefixroute";
        
        NetworkingObjectTest testModule(g_maxPayloadSizeBytes);
        testModule.returnValues = g_returnValues;
        MMI_JSON_STRING payload;
        int payloadSizeBytes;
        int result = testModule.Get(nullptr, nullptr, nullptr, &payload, &payloadSizeBytes);

        EXPECT_EQ(result, MMI_OK);

        std::string resultString(payload, payloadSizeBytes);
        EXPECT_STREQ(resultString.c_str(), "{\"InterfaceTypes\":\"docker0=bridge;eth0=ether\","
                                                "\"MacAddresses\":\"docker0=0a:25:3g:6v:2f:89;eth0=00:15:5d:26:cf:89\","
                                                "\"IpAddresses\":\"docker0=172.32.233.234,::1;eth0=172.27.181.213,10.1.1.2,fe80::5e42:4bf7:dddd:9b0f\","
                                                "\"SubnetMasks\":\"docker0=/8,/128;eth0=/20,/16,/64\","
                                                "\"DefaultGateways\":\"docker0=172.17.128.1;eth0=172.13.145.1\","
                                                "\"DnsServers\":\"docker0=8.8.8.8,172.29.64.1;eth0=172.29.64.1\","
                                                "\"DhcpEnabled\":\"docker0=true;eth0=false\","
                                                "\"Enabled\":\"docker0=true;eth0=false\","
                                                "\"Connected\":\"docker0=true;eth0=false\"}");

        delete payload;

        testModule.runCommandCount = 0;
        testModule.returnValues[1] = testIpDataDocker0AddedAddress;

        result = testModule.Get(nullptr, nullptr, nullptr, &payload, &payloadSizeBytes);

        EXPECT_EQ(result, MMI_OK);

        resultString = std::string(payload, payloadSizeBytes);
        EXPECT_STREQ(resultString.c_str(), "{\"InterfaceTypes\":\"docker0=bridge;eth0=ether\","
                                                "\"MacAddresses\":\"docker0=0a:25:3g:6v:2f:89;eth0=00:15:5d:26:cf:89\","
                                                "\"IpAddresses\":\"docker0=172.32.233.234,10.1.1.1,::1;eth0=172.27.181.213,10.1.1.2,fe80::5e42:4bf7:dddd:9b0f\","
                                                "\"SubnetMasks\":\"docker0=/8,/16,/128;eth0=/20,/16,/64\","
                                                "\"DefaultGateways\":\"docker0=172.17.128.1;eth0=172.13.145.1\","
                                                "\"DnsServers\":\"docker0=8.8.8.8,172.29.64.1;eth0=172.29.64.1\","
                                                "\"DhcpEnabled\":\"docker0=true;eth0=false\","
                                                "\"Enabled\":\"docker0=true;eth0=false\","
                                                "\"Connected\":\"docker0=true;eth0=false\"}");

        delete payload;
    }

    TEST(NetworkingTests, Get_Success_EmptyData_InterfaceNames)
    {
        std::string testCommandOutputNamesEmpty = "";
        NetworkingObjectTest testModule(g_maxPayloadSizeBytes);
        testModule.returnValues = {testCommandOutputNamesEmpty};
        MMI_JSON_STRING payload;
        int payloadSizeBytes;
        int result = testModule.Get(nullptr, nullptr, nullptr, &payload, &payloadSizeBytes);

        EXPECT_EQ(result, MMI_OK);

        std::string resultString(payload, payloadSizeBytes);
        EXPECT_STREQ(resultString.c_str(), "{\"InterfaceTypes\":\"\","
                                                "\"MacAddresses\":\"\","
                                                "\"IpAddresses\":\"\","
                                                "\"SubnetMasks\":\"\","
                                                "\"DefaultGateways\":\"\","
                                                "\"DnsServers\":\"\","
                                                "\"DhcpEnabled\":\"\","
                                                "\"Enabled\":\"\","
                                                "\"Connected\":\"\"}");

        delete payload;
    }

    TEST(NetworkingTests, Get_Success_EmptyData_Eth0)
    {
        std::string testIpDataEth0Empty =
        "1: docker0: <BROADCAST,UP,LOWER_UP> mtu 65536 qdisc noqueue state UP group default qlen 1000\n"
        " link/bridge 0a:25:3g:6v:2f:89 brd 00:00:00:00:00:00\n"
        " inet 172.32.233.234/8 scope global dynamic noprefixroute docker0 valid_lft forever preferred_lft forever\n"
        " inet6 ::1/128 scope host valid_lft forever preferred_lft forever\n"
        "2: eth0: ";

        std::string testCommandOutputDefaultGatewaysEth0Empty =
        "default via 172.17.128.1 dev docker0 proto\n"
        " 172.29.64.0/20 dev eth0 proto kernel scope link src 172.29.78.164";
        
        std::string testCommandOutputDnsServersEth0Empty =
        "Link 2 (docker0)\n"
            "Current Scopes: DNS\n"
        "DefaultRoute setting: yes\n"
            "LLMNR setting: yes\n"
        "MulticastDNS setting: no\n"
        "DNSOverTLS setting: no\n"
            "DNSSEC setting: no\n"
            "DNSSEC supported: no\n"
        "Current DNS Server: 8.8.8.8\n"
                "DNS Servers: 8.8.8.8\n"
                            "172.29.64.1\n"
                "DNS Domain: mshome.net\n"
        "Link 3 (eth0)\n"
            "Current Scopes: DNS\n"
        "DefaultRoute setting: yes\n"
            "LLMNR setting: yes\n"
        "MulticastDNS setting: no\n"
        "DNSOverTLS setting: no\n"
            "DNSSEC setting: no\n"
            "DNSSEC supported: no\n";

        NetworkingObjectTest testModule(g_maxPayloadSizeBytes);
        testModule.returnValues = g_returnValues;
        testModule.returnValues[1] = testIpDataEth0Empty;
        testModule.returnValues[2] = testCommandOutputDefaultGatewaysEth0Empty;
        testModule.returnValues[3] = testCommandOutputDnsServersEth0Empty;

        MMI_JSON_STRING payload;
        int payloadSizeBytes;
        int result = testModule.Get(nullptr, nullptr, nullptr, &payload, &payloadSizeBytes);

        EXPECT_EQ(result, MMI_OK);

        std::string resultString(payload, payloadSizeBytes);
        EXPECT_STREQ(resultString.c_str(), "{\"InterfaceTypes\":\"docker0=bridge\","
                                                "\"MacAddresses\":\"docker0=0a:25:3g:6v:2f:89\","
                                                "\"IpAddresses\":\"docker0=172.32.233.234,::1\","
                                                "\"SubnetMasks\":\"docker0=/8,/128\","
                                                "\"DefaultGateways\":\"docker0=172.17.128.1\","
                                                "\"DnsServers\":\"docker0=8.8.8.8,172.29.64.1\","
                                                "\"DhcpEnabled\":\"docker0=true;eth0=unknown\","
                                                "\"Enabled\":\"docker0=true;eth0=unknown\","
                                                "\"Connected\":\"docker0=true;eth0=unknown\"}");

        delete payload;
    }

    TEST(NetworkingTests, GetPayloadSizeLimit)
    {
        MMI_JSON_STRING payload;
        int payloadSizeBytes;
        unsigned int maxPayloadSizeBytes = 260;
        NetworkingObjectTest testModule(maxPayloadSizeBytes);
        testModule.returnValues = g_returnValues;
        int result = testModule.Get(nullptr, nullptr, nullptr, &payload, &payloadSizeBytes);

        EXPECT_EQ(result, MMI_OK);

        std::string resultString = std::string(payload, payloadSizeBytes);
        std::string expectedString = R"""({"InterfaceTypes":"docker0=bridge;eth0=ether","MacAddresses":"docker0=0a:25:3g:6v:2f:89;eth0=00:15:5d:26:cf:89","IpAddresses":"","SubnetMasks":"docker0=/8,/128;eth0=/20,/16,/64","DefaultGateways":"","DnsServers":"","DhcpEnabled":"","Enabled":"","Connected":""})""";
        EXPECT_STREQ(resultString.c_str(), expectedString.c_str());
          
        delete payload;

        maxPayloadSizeBytes = 100;
        NetworkingObjectTest testModule2(maxPayloadSizeBytes);
        testModule2.returnValues = g_returnValues;
        result = testModule2.Get(nullptr, nullptr, nullptr, &payload, &payloadSizeBytes);
        
        EXPECT_EQ(result, MMI_OK);

        resultString = std::string(payload, payloadSizeBytes);
        expectedString = R"""({"InterfaceTypes":"","MacAddresses":"","IpAddresses":"","SubnetMasks":"","DefaultGateways":"","DnsServers":"","DhcpEnabled":"","Enabled":"","Connected":""})""";
        EXPECT_STREQ(resultString.c_str(), expectedString.c_str());

        delete payload;

        maxPayloadSizeBytes = 0;
        NetworkingObjectTest testModule3(maxPayloadSizeBytes);
        testModule3.returnValues = g_returnValues;
        result = testModule3.Get(nullptr, nullptr, nullptr, &payload, &payloadSizeBytes);
        
        EXPECT_EQ(result, MMI_OK);
        
        resultString = std::string(payload, payloadSizeBytes);
        expectedString = R"""({"InterfaceTypes":"docker0=bridge;eth0=ether","MacAddresses":"docker0=0a:25:3g:6v:2f:89;eth0=00:15:5d:26:cf:89","IpAddresses":"docker0=172.32.233.234,::1;eth0=172.27.181.213,10.1.1.2,fe80::5e42:4bf7:dddd:9b0f","SubnetMasks":"docker0=/8,/128;eth0=/20,/16,/64","DefaultGateways":"docker0=172.17.128.1;eth0=172.13.145.1","DnsServers":"docker0=8.8.8.8,172.29.64.1;eth0=172.29.64.1","DhcpEnabled":"docker0=true;eth0=false","Enabled":"docker0=true;eth0=false","Connected":"docker0=true;eth0=false"})""";
        EXPECT_STREQ(resultString.c_str(), expectedString.c_str());

        delete payload;
    }
} // namespace OSConfig::Platform::Tests