// Copyright (c) Microsoft. All rights reserved.
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include <string>

#include <CommandRunner.h>
#include <CommonUtils.h>
#include <Mmi.h>

using ::testing::_;
using ::testing::Invoke;

class CommandRunnerMock : public CommandRunner
{
public:
    MOCK_METHOD5(Execute, int(std::string commandId, std::string command, CommandRunner::CommandStatus cmdStatus, std::function<int()> pre, std::function<int()> post));
};
namespace OSConfig::Platform::Tests
{
    TEST(CommandRunnerTests, ExecuteCommand)
    {
        CommandRunner::CommandArguments cmdArgs{"1", "echo test", CommandRunner::Action::ActionRunCommand};
        CommandRunner cmdRunner;
        ASSERT_EQ(MMI_OK, cmdRunner.Execute(cmdRunner, cmdArgs.commandId, cmdArgs.arguments, CommandRunner::CommandState::Unknown, nullptr, nullptr, 0));
        auto cmdStatus = cmdRunner.GetCommandStatus("1");
        ASSERT_NE(nullptr, cmdStatus);
        ASSERT_STREQ(cmdArgs.commandId.c_str(), cmdStatus->commandId.c_str());
        ASSERT_STREQ("test ", cmdStatus->textResult.c_str());   // "test " CommandRunner adds " " instead of EOL
        ASSERT_EQ(CommandRunner::CommandState::Succeeded, cmdStatus->commandState);
    }

    TEST(CommandRunnerTests, CommandStatusUpdated)
    {
        CommandRunner cmdRunner;
        CommandRunner::CommandArguments cmdArgsFirst{"1", "echo test", CommandRunner::Action::ActionRunCommand};

        // Run 1st command
        CommandRunner::CommandArguments cmdArgs1{"1", "echo test1", CommandRunner::Action::ActionRunCommand};
        ASSERT_EQ(MMI_OK, cmdRunner.Execute(cmdRunner, cmdArgs1.commandId, cmdArgs1.arguments, CommandRunner::CommandState::Unknown, nullptr, nullptr, 0));
        auto cmdStatus1 = cmdRunner.GetCommandStatus("1");
        ASSERT_NE(nullptr, cmdStatus1);
        ASSERT_STREQ(cmdArgs1.commandId.c_str(), cmdStatus1->commandId.c_str());
        ASSERT_STREQ("test1 ", cmdStatus1->textResult.c_str());
        ASSERT_EQ(CommandRunner::CommandState::Succeeded, cmdStatus1->commandState);

        // Run 2nd command
        CommandRunner::CommandArguments cmdArgs2{"2", "echo test2", CommandRunner::Action::ActionRunCommand};
        ASSERT_EQ(MMI_OK, cmdRunner.Execute(cmdRunner, cmdArgs2.commandId, cmdArgs2.arguments, CommandRunner::CommandState::Unknown, nullptr, nullptr, 0));
        auto cmdStatus2 = cmdRunner.GetCommandStatus("2");
        ASSERT_NE(nullptr, cmdStatus2);
        ASSERT_STREQ(cmdArgs2.commandId.c_str(), cmdStatus2->commandId.c_str());
        ASSERT_STREQ("test2 ", cmdStatus2->textResult.c_str());
        ASSERT_EQ(CommandRunner::CommandState::Succeeded, cmdStatus2->commandState);

        ASSERT_STREQ(cmdArgs2.commandId.c_str(), cmdRunner.GetCommandIdToRefresh().c_str());
    }

    TEST(CommandRunnerTests, ExecuteCommandLimitedPayload)
    {
        CommandRunner::CommandArguments cmdArgs{"1", "echo test", CommandRunner::Action::ActionRunCommand};
        CommandRunner cmdRunner(105);
        ASSERT_EQ(MMI_OK, cmdRunner.Execute(cmdRunner, cmdArgs.commandId, cmdArgs.arguments, CommandRunner::CommandState::Unknown, nullptr, nullptr, 0));
        auto cmdStatus = cmdRunner.GetCommandStatus("1");
        ASSERT_NE(nullptr, cmdStatus);
        ASSERT_STREQ(cmdArgs.commandId.c_str(), cmdStatus->commandId.c_str());
        ASSERT_STREQ("t", cmdStatus->textResult.c_str());
        ASSERT_EQ(CommandRunner::CommandState::Succeeded, cmdStatus->commandState);
    }

    TEST(CommandRunnerTests, CachedCommandStatus)
    {
        CommandRunner::CommandArguments cmdArgs{"1", "echo 1", CommandRunner::Action::ActionRunCommand};
        CommandRunner cmdRunner(105);
        ASSERT_EQ(MMI_OK, cmdRunner.Execute(cmdRunner, cmdArgs.commandId, cmdArgs.arguments, CommandRunner::CommandState::Unknown, nullptr, nullptr, 0));

        auto status = cmdRunner.GetLastCommandStatus();

        ASSERT_STREQ(cmdArgs.commandId.c_str(), status.commandId.c_str());
        ASSERT_STREQ("1", status.textResult.c_str());
        ASSERT_EQ(CommandRunner::CommandState::Succeeded, status.commandState);
    }

    TEST(CommandRunnerTests, OverwriteBufferCommandStatus)
    {
        constexpr int CommandArgumentsListSize = COMMANDSTATUS_CACHE_MAX + 1;
        std::array<CommandRunner::CommandArguments, CommandArgumentsListSize> commandArgumentList;
        CommandRunner cmdRunner(105);
        for (int i=0; i < CommandArgumentsListSize; ++i)
        {
            char size, commandId[10], command[20];
            size = sprintf(commandId, "%d", i);
            ASSERT_GT(size, 0);
            size = sprintf(command, "echo %d", i);
            ASSERT_GT(size, 0);
            commandArgumentList[i] = {commandId, command, CommandRunner::Action::ActionRunCommand};
            ASSERT_EQ(MMI_OK, cmdRunner.Execute(cmdRunner, commandArgumentList[i].commandId, commandArgumentList[i].arguments, CommandRunner::CommandState::Unknown, nullptr, nullptr, 0));
        }
        
        // 1st element should no longer be present in the buffer
        auto cmd1 = cmdRunner.GetCommandStatus(commandArgumentList[0].commandId);
        auto cmd2 = cmdRunner.GetCommandStatus(commandArgumentList[1].commandId);
        ASSERT_EQ(nullptr, cmd1);
        ASSERT_NE(nullptr, cmd2);
    }

    TEST(CommandRunnerTests, WorkerThreadExecution)
    {
        CommandRunner::CommandArguments cmdArgs1{"1", "sleep 1s && echo 1", CommandRunner::Action::ActionRunCommand};
        CommandRunner::CommandArguments cmdArgs2{"2", "sleep 1s && echo 2", CommandRunner::Action::ActionRunCommand};
        CommandRunner cmdRunner;
        
        // Dispatch both
        cmdRunner.RunCommand(cmdArgs1, nullptr, nullptr, 0);
        cmdRunner.RunCommand(cmdArgs2, nullptr, nullptr, 0);
        
        auto cmdStatus1 = cmdRunner.GetCommandStatus(cmdArgs1.commandId);
        auto cmdStatus2 = cmdRunner.GetCommandStatus(cmdArgs2.commandId);

        ASSERT_NE(nullptr, cmdStatus1);
        ASSERT_NE(nullptr, cmdStatus2);

        ASSERT_STREQ(cmdArgs1.commandId.c_str(), cmdStatus1->commandId.c_str());
        ASSERT_TRUE((CommandRunner::CommandState::Unknown == cmdStatus1->commandState) || (CommandRunner::CommandState::Running == cmdStatus1->commandState));
        ASSERT_STREQ(cmdArgs2.commandId.c_str(), cmdStatus2->commandId.c_str());
        ASSERT_TRUE((CommandRunner::CommandState::Unknown == cmdStatus2->commandState) || (CommandRunner::CommandState::Running == cmdStatus2->commandState));

        cmdRunner.WaitForCommandResults();

        ASSERT_EQ(CommandRunner::CommandState::Succeeded, cmdStatus1->commandState);
        ASSERT_STREQ("1 ", cmdStatus1->textResult.c_str());
        ASSERT_EQ(CommandRunner::CommandState::Succeeded, cmdStatus2->commandState);
        ASSERT_STREQ("2 ", cmdStatus2->textResult.c_str());
    }
} // namespace OSConfig::Platform::Tests