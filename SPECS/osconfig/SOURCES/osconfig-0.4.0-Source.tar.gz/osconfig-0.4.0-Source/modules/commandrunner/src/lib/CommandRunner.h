// Copyright (c) Microsoft. All rights reserved.
#ifndef COMMANDRUNNER_H
#define COMMANDRUNNER_H

#include <array>
#include <functional>
#include <Logging.h>
#include <map>
#include <memory>
#include <queue>
#include <string>
#include <thread>
#include <vector>

#define COMMANDSTATUS_CACHE_MAX 10
#define COMMANDRUNNER_LOGFILE "/var/log/osconfig_commandrunner.log"
#define COMMADRUNNER_ROLLEDLOGFILE "/var/log/osconfig_commandrunner.bak"

class CommandRunnerLog
{
public:
    static OSCONFIG_LOG_HANDLE Get()
    {
        return m_log;
    }

    static void OpenLog()
    {
        m_log = ::OpenLog(COMMANDRUNNER_LOGFILE, COMMADRUNNER_ROLLEDLOGFILE, NULL);
    }

    static void CloseLog()
    {
        ::CloseLog(&m_log);
    }

    static OSCONFIG_LOG_HANDLE m_log;
};

class CommandRunner
{
public:
    enum Action
    {
        ActionNone = 0,
        ActionReboot,
        ActionShutdown,
        ActionRunCommand,
        ActionRefreshCommandStatus
    };

    enum CommandState
    {
        Unknown = 0,
        Running,
        Succeeded,
        Failed
    };

    struct CommandArguments
    {
        std::string commandId;
        std::string arguments;
        Action action;
    };

    struct CommandArgumentsMetadata
    {
        CommandArguments commandArguments;
        std::function<int()> preRunFunction;
        std::function<int()> postRunFunction;
        unsigned int timeoutSeconds;
    };

    struct CommandStatus
    {
        std::string commandId;
        int resultCode;
        int extendedResultCode;
        std::string textResult;
        CommandState commandState;
    };
    typedef std::map<std::string, std::weak_ptr<CommandStatus>> CommandResults;

    CommandRunner(unsigned int maxSizeInBytes = 0);
    virtual ~CommandRunner();
    virtual void RunCommand(CommandArguments command, std::function<int()> preRunFunc, std::function<int()> postRunFunc, unsigned int timeoutSeconds);
    static void CommandWorkerThread(CommandRunner& commandRunnerInstance, std::queue<CommandArgumentsMetadata>& commandArgumentsBuffer);
    virtual CommandStatus* GetCommandStatus(std::string commandId);
    static int Execute(CommandRunner& commandRunnerInstance, std::string commandId, std::string command, CommandState initialState, std::function<int()> preRunFunc, std::function<int()> postRunFunc, unsigned int timeoutSeconds);
    virtual const std::string &GetCommandIdToRefresh();
    virtual void SetCommandIdToRefresh(std::string commandId);
    virtual void WaitForCommandResults();
    virtual CommandStatus GetLastCommandStatus();
    virtual void AddCommandStatus(CommandStatus commandStatus, bool updateCommandIdToBeRefreshed);
    virtual int GetMaxPayloadSizeInBytes();

private:
    static int CommandExecutionCallback();
    static bool cancelCommands;

    std::queue<CommandArgumentsMetadata> commandArgumentsBuffer;
    std::thread commandWorkerThread;
    std::array<std::shared_ptr<CommandStatus>, COMMANDSTATUS_CACHE_MAX> commandStatusBuffer;
    int curIndexCommandBuffer;
    CommandResults commmandMap;
    CommandStatus lastCommandStatus;
    std::string commandIdToRefresh;
    unsigned int maxPayloadSizeInBytes;
};


#endif // COMMANDRUNNER_H