// Copyright (c) Microsoft. All rights reserved.
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <Mmi.h>
#include <random>
#include <sstream>
#include <streambuf>

#include <CommandRunner.h>
#include <CommonUtils.h>

const char commandStatusTemplate[] = "{\"CommandId\":\"\",\"ResultCode\":,\"ExtendedResultCode\":,\"TextResult\":\"\",\"CurrentState\":}";
const char resultCodeChar[] = "-32767";

static const std::string COMMAND_SEPARATOR = " > ";

OSCONFIG_LOG_HANDLE CommandRunnerLog::m_log = nullptr;
bool CommandRunner::cancelCommands = false;

CommandRunner::CommandRunner(unsigned int maxSizeInBytes) : curIndexCommandBuffer(0)
{
    maxPayloadSizeInBytes = maxSizeInBytes;
}

CommandRunner::~CommandRunner()
{
    OsConfigLogInfo(CommandRunnerLog::Get(), "CommandRunner shutting down");
    CommandRunner::cancelCommands = true;
    try
    {
        commandWorkerThread.join();
    }
    catch (const std::exception &e) {}
}

void CommandRunner::RunCommand(CommandArguments command, std::function<int()> preRunFunc, std::function<int()> postRunFunc, unsigned int timeoutSeconds)
{
    if (commandArgumentsBuffer.empty() && commandWorkerThread.joinable())
    {
        commandWorkerThread.join();
    }

    AddCommandStatus({command.commandId, MMI_OK, MMI_OK, "", CommandRunner::CommandState::Unknown}, false);

    switch (command.action)
    {
        case CommandRunner::Action::ActionNone:
            OsConfigLogInfo(CommandRunnerLog::Get(), "No action to perform.");
            break;

        case CommandRunner::Action::ActionRefreshCommandStatus:
            OsConfigLogInfo(CommandRunnerLog::Get(), "Refreshing commandId: %s", command.commandId.c_str());
            SetCommandIdToRefresh(command.commandId);
            break;

        default:
            // Push command onto command buffer and start worker thread if not already running
            commandArgumentsBuffer.push({command, preRunFunc, postRunFunc, timeoutSeconds});
            if (!commandWorkerThread.joinable())
            {
                commandWorkerThread = std::thread(CommandWorkerThread, std::ref(*this), std::ref(commandArgumentsBuffer));
            }
    }
}

void CommandRunner::CommandWorkerThread(CommandRunner& commandRunnerInstance, std::queue<CommandArgumentsMetadata>& commandArgumentsBuffer)
{
    OsConfigLogInfo(CommandRunnerLog::Get(), "CommandRunner worker thread started. Processing commands");
    while (!commandArgumentsBuffer.empty())
    {
        // Execute command
        auto commandMetadata = commandArgumentsBuffer.front();
        auto command = commandMetadata.commandArguments;
        switch (commandMetadata.commandArguments.action)
        {
            case CommandRunner::Action::ActionReboot:
                OsConfigLogInfo(CommandRunnerLog::Get(), "Attempting to reboot");
                commandRunnerInstance.Execute(commandRunnerInstance, command.commandId, "shutdown -r now", CommandState::Succeeded, commandMetadata.preRunFunction, nullptr, 0);
                break;

            case CommandRunner::Action::ActionShutdown:
                OsConfigLogInfo(CommandRunnerLog::Get(), "Attempting to shutdown");
                commandRunnerInstance.Execute(commandRunnerInstance, command.commandId, "shutdown now", CommandState::Succeeded, commandMetadata.preRunFunction, nullptr, 0);
                break;

            case CommandRunner::Action::ActionRunCommand:
                commandRunnerInstance.Execute(commandRunnerInstance, command.commandId, command.arguments, CommandState::Running, commandMetadata.preRunFunction, commandMetadata.postRunFunction, commandMetadata.timeoutSeconds);
                break;

            default:
                OsConfigLogError(CommandRunnerLog::Get(), "Invalid action: %d", command.action);
        }
        commandArgumentsBuffer.pop();
    }
    OsConfigLogInfo(CommandRunnerLog::Get(), "CommandRunner worker thread finished. No more commands to process");
}

int CommandRunner::CommandExecutionCallback()
{
    return CommandRunner::cancelCommands ? 1 : 0;
}

int CommandRunner::Execute(CommandRunner& cmdRunnerInstance, std::string commandId, std::string command, CommandState initialState, std::function<int()> preRunFunc, std::function<int()> postRunFunc, unsigned int timeoutSeconds)
{
    int status = EINVAL;
    char* textResult = nullptr;

    OsConfigLogInfo(CommandRunnerLog::Get(), "Running command '%s'", commandId.c_str());
    cmdRunnerInstance.AddCommandStatus({commandId, MMI_OK, MMI_OK, "", initialState}, false);
    if (preRunFunc)
    {
        if (MMI_OK != (status = preRunFunc()))
        {
            // Unable to save to cache! Do not run command!
            OsConfigLogError(CommandRunnerLog::Get(), "Unable to persist to cache, skipping command '%s' with %d", commandId.c_str(), status);
            return status;
        }
    }
    const char* commandCharPtr = command.c_str();
    unsigned int maxTextResultBytes = 0;
    unsigned int maxPayloadSizeInBytes = static_cast<unsigned int>(cmdRunnerInstance.GetMaxPayloadSizeInBytes());
    if (maxPayloadSizeInBytes > 0)
    {
        unsigned int estimatedSize = strlen(commandStatusTemplate) + strlen(commandId.c_str()) + (3 * strlen(resultCodeChar));
        maxTextResultBytes = (maxPayloadSizeInBytes > estimatedSize) ? (maxPayloadSizeInBytes - estimatedSize) : 1;
    }
    status = ExecuteCommand(commandCharPtr, true, maxTextResultBytes, timeoutSeconds, &textResult, CommandRunner::CommandExecutionCallback, CommandRunnerLog::Get());

#ifdef LOG_VALUE_PAYLOAD
    OsConfigLogInfo(CommandRunnerLog::Get(), "Command '%s' ('%s') completed with %d and '%s'", commandId.c_str(), commandCharPtr, status, textResult ? textResult : "no text result");
#else
    OsConfigLogInfo(CommandRunnerLog::Get(), "Command '%s' completed with %d", commandId.c_str(), status);
#endif

    std::string results;
    
    if (textResult)
    {
        results = std::string(textResult, strlen(textResult));
        free(textResult);
    }
    
    // Add new commandStatus
    cmdRunnerInstance.AddCommandStatus({commandId, status, status, results, (0 == status) ? CommandState::Succeeded : CommandState::Failed}, true);
    if (postRunFunc)
    {
        if ((MMI_OK == status) && (MMI_OK != (status = postRunFunc())))
        {
            // post operation failed, return error downstream
            OsConfigLogError(CommandRunnerLog::Get(), "Post command operation failed for command '%s' with %d", commandId.c_str(), status);
            return status;
        }
    }
    
    // The command was executed and the command's result was saved to be reported via CommandStatus
    return MMI_OK;
}

const std::string &CommandRunner::GetCommandIdToRefresh()
{
    return commandIdToRefresh;
}

void CommandRunner::SetCommandIdToRefresh(std::string commandId)
{
    commandIdToRefresh = commandId;
}

CommandRunner::CommandStatus* CommandRunner::GetCommandStatus(std::string commandId)
{
    try
    {
        if (commmandMap.end() == commmandMap.find(commandId))
        {
            return nullptr;
        }
        else if (commmandMap[commandId].expired())
        {
            commmandMap.erase(commmandMap.find(commandId));
            return nullptr;
        }
        return commmandMap[commandId].lock().get();
    }
    catch (const std::exception &e)
    {
        OsConfigLogError(CommandRunnerLog::Get(), "Unable to retreive CommandStatus for commandId: %s", commandId.c_str());
        return nullptr;
    }
}

CommandRunner::CommandStatus CommandRunner::GetLastCommandStatus()
{
    return lastCommandStatus;
}

void CommandRunner::AddCommandStatus(CommandStatus commandStatus, bool updateCommandIdToBeRefreshed)
{
    if (!commandStatus.commandId.empty())
    {
        bool updateCommandStatus = true;
        std::shared_ptr<CommandStatus> tempCommandStatus;
        if ((commmandMap.end() != commmandMap.find(commandStatus.commandId)) && !commmandMap[commandStatus.commandId].expired())
        {
            // Update existing Commandstatus
            tempCommandStatus = commmandMap[commandStatus.commandId].lock();

            // If updated CommandStatus CommandState::Unknown, do not update CommandStatus
            if (CommandState::Unknown == commandStatus.commandState)
            {
                updateCommandStatus = false; 
            }
        }
        else
        {
            // Add new CommandStatus
            tempCommandStatus.reset(new CommandStatus());
            commandStatusBuffer[curIndexCommandBuffer] = tempCommandStatus;
            commmandMap[commandStatus.commandId] = std::weak_ptr<CommandStatus>(commandStatusBuffer[curIndexCommandBuffer]);
            curIndexCommandBuffer = (curIndexCommandBuffer + 1) % COMMANDSTATUS_CACHE_MAX;
        }
        
        if (updateCommandStatus)
        {
            tempCommandStatus->commandId = commandStatus.commandId;
            tempCommandStatus->commandState = commandStatus.commandState;
            tempCommandStatus->extendedResultCode = commandStatus.extendedResultCode;
            tempCommandStatus->resultCode = commandStatus.resultCode;
            tempCommandStatus->textResult = commandStatus.textResult;
            
            lastCommandStatus = commandStatus;
            if (updateCommandIdToBeRefreshed)
            {
                commandIdToRefresh = commandStatus.commandId;
            }
        }
    }
}

int CommandRunner::GetMaxPayloadSizeInBytes()
{
    return maxPayloadSizeInBytes;
}

void CommandRunner::WaitForCommandResults()
{
    if (!commandArgumentsBuffer.empty() && commandWorkerThread.joinable())
    {
        commandWorkerThread.join();
    }
}