// Copyright (c) Microsoft. All rights reserved.
#ifndef MODULESMANAGER_H
#define MODULESMANAGER_H

#include <chrono>
#include <ctime>
#include <future>
#include <map>
#include <memory>
#include <mutex>
#include <queue>
#include <vector>
#include <unordered_map>
#include <ManagementModule.h>
#include <Logging.h>

#define MODULESMANAGER_LOGFILE "/var/log/osconfig_platform.log"
#define MODULESMANAGER_ROLLEDLOGFILE "/var/log/osconfig_platform.bak"

namespace Tests
{
    class ModuleManagerTests_ModuleCleanup_Test;
    class ModuleManagerTests;
} // namespace Tests

class ModulesManagerLog
{
public:
    static OSCONFIG_LOG_HANDLE Get()
    {
        return m_log;
    }

    static void OpenLog()
    {
        m_log = ::OpenLog(MODULESMANAGER_LOGFILE, MODULESMANAGER_ROLLEDLOGFILE, NULL);
    }

    static void CloseLog()
    {
        ::CloseLog(&m_log);
    }

    static OSCONFIG_LOG_HANDLE m_log;
};

class ModulesManager
{
public:
    ModulesManager(std::string clientName);
    ~ModulesManager();

    // Set the default cleanup timespan in seconds for Management Modules (MMs), unloads the MM if Lifespan is "Short" after
    void SetDefaultCleanupTimespan(unsigned int timespan);
    // Loads Management Modules (MMs) into the ModuleLoader from the default path (/usr/lib/osconfig)
    int LoadModules();
    // Loads Management Modules (MMs) into the ModuleLoader from the given path
    int LoadModules(std::string modulePath);
    // Perform an MpiSet operation
    int MpiSet(const char *componentName, const char *propertyName, const char *payload, const int payloadSizeBytes);
    // Perform an MpiGet operation
    int MpiGet(const char *componentName, const char *propertyName, char **payload, int *payloadSizeBytes);
    // Retreives the client of the ModulesManager
    std::string GetClientName();
    void UnloadAllModules();
    void UnloadModules();
    void SetMaxPayloadSize(unsigned int maxSize);
    void DoWork();

private:
    struct ModuleMetadata
    {
        std::shared_ptr<ManagementModule> module;
        std::chrono::system_clock::time_point lastOperation;
        bool operationInProgress;
    };

    int MpiSetInternal(const char *componentName, const char *propertyName, const char *payload, const int payloadSizeBytes);
    int MpiGetInternal(const char *componentName, const char *propertyName, char **payload, int *payloadSizeBytes);
    ModuleMetadata* GetModuleMetadata(const char *componentName);
    void ScheduleUnloadModule(ModuleMetadata &mm);
    
    // Module mapping componentName <-> ModuleMetadata
    std::map<std::string, ModuleMetadata> modMap;
    // Vector of modules to unload
    std::vector<ModuleMetadata> modulesToUnload;
    std::hash<std::string> hashString;
    
    // Timespan in seconds in order to unload loaded MMs, eg. unload module after x secs
    unsigned int cleanupTimespan;
    // The name of the client using the module manager
    std::string clientName;
    // Hash of the previously reported payload
    std::unordered_map<std::string, size_t> payloadHashMap;
    // The maximum payload size
    int maxPayloadSizeBytes;

    friend class Tests::ModuleManagerTests;
    friend class Tests::ModuleManagerTests_ModuleCleanup_Test;
};

#endif // MODULESMANAGER_H